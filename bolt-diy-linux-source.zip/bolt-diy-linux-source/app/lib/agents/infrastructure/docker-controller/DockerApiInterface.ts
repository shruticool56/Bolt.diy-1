/**
 * DockerApiInterface.ts
 * 
 * This module provides an interface to the Docker Engine API for the AI agent,
 * allowing it to autonomously control Docker containers, particularly minimal Ubuntu images.
 */

import axios from 'axios';
import * as stream from 'stream';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

export interface ContainerOptions {
  name?: string;
  cmd?: string[];
  env?: Record<string, string>;
  volumes?: Record<string, string>;
  ports?: Record<string, string>;
  workingDir?: string;
  autoRemove?: boolean;
  networkMode?: string;
  privileged?: boolean;
}

export interface ExecOptions {
  cmd: string[];
  attachStdout?: boolean;
  attachStderr?: boolean;
  tty?: boolean;
  workingDir?: string;
  env?: Record<string, string>;
}

export interface ContainerInfo {
  id: string;
  name: string;
  image: string;
  state: string;
  status: string;
  created: string;
}

/**
 * DockerApiInterface class provides methods to interact with Docker Engine API
 * for container management and command execution.
 */
export class DockerApiInterface {
  private socketPath: string;
  private apiVersion: string;

  /**
   * Constructor for DockerApiInterface
   * @param socketPath Path to the Docker socket (default: /var/run/docker.sock)
   * @param apiVersion Docker API version to use (default: v1.41)
   */
  constructor(socketPath = '/var/run/docker.sock', apiVersion = 'v1.41') {
    this.socketPath = socketPath;
    this.apiVersion = apiVersion;
  }

  /**
   * Creates an axios instance configured for Docker API
   */
  private createApiClient() {
    return axios.create({
      socketPath: this.socketPath,
      baseURL: `http://${this.apiVersion}`,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  /**
   * Checks if Docker is available and running
   * @returns Promise<boolean> True if Docker is available
   */
  async isDockerAvailable(): Promise<boolean> {
    try {
      const { stdout } = await execAsync('docker version --format "{{.Server.Version}}"');
      return !!stdout.trim();
    } catch (error) {
      console.error('Docker is not available:', error);
      return false;
    }
  }

  /**
   * Pulls a Docker image
   * @param image Image name and tag (e.g., 'ubuntu:latest')
   * @returns Promise<boolean> True if pull was successful
   */
  async pullImage(image: string): Promise<boolean> {
    try {
      console.log(`Pulling Docker image: ${image}`);
      await execAsync(`docker pull ${image}`);
      return true;
    } catch (error) {
      console.error(`Failed to pull image ${image}:`, error);
      return false;
    }
  }

  /**
   * Lists available Docker images
   * @returns Promise<string[]> List of image IDs
   */
  async listImages(): Promise<string[]> {
    try {
      const { stdout } = await execAsync('docker images --format "{{.Repository}}:{{.Tag}}"');
      return stdout.trim().split('\n').filter(Boolean);
    } catch (error) {
      console.error('Failed to list images:', error);
      return [];
    }
  }

  /**
   * Creates a new Docker container
   * @param image Image name to use
   * @param options Container configuration options
   * @returns Promise<string> Container ID if successful
   */
  async createContainer(image: string, options: ContainerOptions = {}): Promise<string> {
    try {
      const client = this.createApiClient();
      
      // Prepare container configuration
      const config: any = {
        Image: image,
        Tty: true,
        OpenStdin: true,
        AttachStdin: true,
        AttachStdout: true,
        AttachStderr: true,
      };
      
      if (options.cmd) {
        config.Cmd = options.cmd;
      }
      
      if (options.env) {
        config.Env = Object.entries(options.env).map(([key, value]) => `${key}=${value}`);
      }
      
      if (options.workingDir) {
        config.WorkingDir = options.workingDir;
      }
      
      // Prepare host configuration
      const hostConfig: any = {};
      
      if (options.volumes) {
        config.Volumes = {};
        hostConfig.Binds = [];
        
        Object.entries(options.volumes).forEach(([host, container]) => {
          config.Volumes[container] = {};
          hostConfig.Binds.push(`${host}:${container}`);
        });
      }
      
      if (options.ports) {
        config.ExposedPorts = {};
        hostConfig.PortBindings = {};
        
        Object.entries(options.ports).forEach(([host, container]) => {
          const [containerPort, proto = 'tcp'] = container.split('/');
          const key = `${containerPort}/${proto}`;
          
          config.ExposedPorts[key] = {};
          hostConfig.PortBindings[key] = [{ HostPort: host }];
        });
      }
      
      if (options.autoRemove) {
        hostConfig.AutoRemove = true;
      }
      
      if (options.networkMode) {
        hostConfig.NetworkMode = options.networkMode;
      }
      
      if (options.privileged) {
        hostConfig.Privileged = true;
      }
      
      config.HostConfig = hostConfig;
      
      // Create the container
      const response = await client.post('/containers/create', config, {
        params: options.name ? { name: options.name } : undefined,
      });
      
      return response.data.Id;
    } catch (error: unknown) {
      console.error('Failed to create container:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to create container: ${errorMessage}`);
    }
  }

  /**
   * Starts a Docker container
   * @param containerId Container ID to start
   * @returns Promise<boolean> True if container was started successfully
   */
  async startContainer(containerId: string): Promise<boolean> {
    try {
      const client = this.createApiClient();
      await client.post(`/containers/${containerId}/start`);
      return true;
    } catch (error) {
      console.error(`Failed to start container ${containerId}:`, error);
      return false;
    }
  }

  /**
   * Stops a Docker container
   * @param containerId Container ID to stop
   * @param timeout Timeout in seconds before killing the container
   * @returns Promise<boolean> True if container was stopped successfully
   */
  async stopContainer(containerId: string, timeout = 10): Promise<boolean> {
    try {
      const client = this.createApiClient();
      await client.post(`/containers/${containerId}/stop`, null, {
        params: { t: timeout },
      });
      return true;
    } catch (error) {
      console.error(`Failed to stop container ${containerId}:`, error);
      return false;
    }
  }

  /**
   * Removes a Docker container
   * @param containerId Container ID to remove
   * @param force Force removal of running container
   * @returns Promise<boolean> True if container was removed successfully
   */
  async removeContainer(containerId: string, force = false): Promise<boolean> {
    try {
      const client = this.createApiClient();
      await client.delete(`/containers/${containerId}`, {
        params: { force },
      });
      return true;
    } catch (error) {
      console.error(`Failed to remove container ${containerId}:`, error);
      return false;
    }
  }

  /**
   * Lists all Docker containers
   * @param all Include stopped containers
   * @returns Promise<ContainerInfo[]> List of container information
   */
  async listContainers(all = false): Promise<ContainerInfo[]> {
    try {
      const client = this.createApiClient();
      const response = await client.get('/containers/json', {
        params: { all },
      });
      
      return response.data.map((container: any) => ({
        id: container.Id,
        name: container.Names[0].replace(/^\//, ''),
        image: container.Image,
        state: container.State,
        status: container.Status,
        created: new Date(container.Created * 1000).toISOString(),
      }));
    } catch (error) {
      console.error('Failed to list containers:', error);
      return [];
    }
  }

  /**
   * Executes a command in a running container
   * @param containerId Container ID
   * @param options Execution options
   * @returns Promise<string> Execution ID
   */
  async execCommand(containerId: string, options: ExecOptions): Promise<string> {
    try {
      const client = this.createApiClient();
      
      // Create exec instance
      const execConfig: Record<string, any> = {
        AttachStdout: options.attachStdout !== false,
        AttachStderr: options.attachStderr !== false,
        Tty: options.tty !== false,
        Cmd: options.cmd,
      };
      
      if (options.workingDir) {
        execConfig['WorkingDir'] = options.workingDir;
      }
      
      if (options.env) {
        execConfig['Env'] = Object.entries(options.env).map(([key, value]) => `${key}=${value}`);
      }
      
      const response = await client.post(`/containers/${containerId}/exec`, execConfig);
      return response.data.Id;
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Failed to create exec instance for container ${containerId}:`, error);
      throw new Error(`Failed to create exec instance: ${errorMessage}`);
    }
  }

  /**
   * Starts an exec instance and returns the output
   * @param execId Execution ID
   * @returns Promise<string> Command output
   */
  async startExec(execId: string): Promise<string> {
    try {
      const client = this.createApiClient();
      
      const response = await client.post(`/exec/${execId}/start`, {
        Detach: false,
        Tty: true,
      }, {
        responseType: 'stream',
      });
      
      return new Promise<string>((resolve, reject) => {
        let output = '';
        const responseStream = response.data as stream.Readable;
        
        responseStream.on('data', (chunk) => {
          output += chunk.toString();
        });
        
        responseStream.on('end', () => {
          resolve(output);
        });
        
        responseStream.on('error', (err) => {
          reject(err);
        });
      });
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Failed to start exec instance ${execId}:`, error);
      throw new Error(`Failed to start exec instance: ${errorMessage}`);
    }
  }

  /**
   * Executes a command in a container and returns the output
   * @param containerId Container ID
   * @param cmd Command to execute
   * @param workingDir Working directory
   * @returns Promise<string> Command output
   */
  async execInContainer(containerId: string, cmd: string[], workingDir?: string): Promise<string> {
    try {
      const execId = await this.execCommand(containerId, {
        cmd,
        workingDir,
        attachStdout: true,
        attachStderr: true,
      });
      
      return await this.startExec(execId);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Failed to execute command in container ${containerId}:`, error);
      throw new Error(`Failed to execute command: ${errorMessage}`);
    }
  }

  /**
   * Copies a file from the host to a container
   * @param containerId Container ID
   * @param sourcePath Source path on host
   * @param destPath Destination path in container
   * @returns Promise<boolean> True if copy was successful
   */
  async copyToContainer(containerId: string, sourcePath: string, destPath: string): Promise<boolean> {
    try {
      // Create a tar archive of the file
      const fileName = path.basename(sourcePath);
      const tarPath = path.join('/tmp', `${fileName}.tar`);
      
      await execAsync(`tar -cf ${tarPath} -C ${path.dirname(sourcePath)} ${fileName}`);
      
      // Read the tar file
      const tarContent = fs.readFileSync(tarPath);
      
      // Copy to container
      const client = this.createApiClient();
      await client.put(`/containers/${containerId}/archive`, tarContent, {
        params: { path: destPath },
        headers: { 'Content-Type': 'application/x-tar' },
      });
      
      // Clean up
      fs.unlinkSync(tarPath);
      
      return true;
    } catch (error) {
      console.error(`Failed to copy file to container ${containerId}:`, error);
      return false;
    }
  }

  /**
   * Copies a file from a container to the host
   * @param containerId Container ID
   * @param sourcePath Source path in container
   * @param destPath Destination path on host
   * @returns Promise<boolean> True if copy was successful
   */
  async copyFromContainer(containerId: string, sourcePath: string, destPath: string): Promise<boolean> {
    try {
      // Ensure destination directory exists
      const destDir = path.dirname(destPath);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      
      // Get archive from container
      const client = this.createApiClient();
      const response = await client.get(`/containers/${containerId}/archive`, {
        params: { path: sourcePath },
        responseType: 'stream',
      });
      
      // Create temporary tar file
      const tarPath = path.join('/tmp', `container_extract_${Date.now()}.tar`);
      const writeStream = fs.createWriteStream(tarPath);
      
      await new Promise<void>((resolve, reject) => {
        const responseStream = response.data as stream.Readable;
        responseStream.pipe(writeStream);
        
        writeStream.on('finish', resolve);
        writeStream.on('error', reject);
      });
      
      // Extract the file
      await execAsync(`tar -xf ${tarPath} -C ${destDir}`);
      
      // Clean up
      fs.unlinkSync(tarPath);
      
      return true;
    } catch (error) {
      console.error(`Failed to copy file from container ${containerId}:`, error);
      return false;
    }
  }

  /**
   * Creates and starts a container in one operation
   * @param image Image name
   * @param options Container options
   * @returns Promise<string> Container ID
   */
  async runContainer(image: string, options: ContainerOptions = {}): Promise<string> {
    const containerId = await this.createContainer(image, options);
    const started = await this.startContainer(containerId);
    
    if (!started) {
      throw new Error(`Failed to start container ${containerId}`);
    }
    
    return containerId;
  }

  /**
   * Checks if a container exists
   * @param nameOrId Container name or ID
   * @returns Promise<boolean> True if container exists
   */
  async containerExists(nameOrId: string): Promise<boolean> {
    try {
      const client = this.createApiClient();
      await client.get(`/containers/${nameOrId}/json`);
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Gets container logs
   * @param containerId Container ID
   * @param tail Number of lines to return from the end
   * @returns Promise<string> Container logs
   */
  async getContainerLogs(containerId: string, tail = 100): Promise<string> {
    try {
      const client = this.createApiClient();
      const response = await client.get(`/containers/${containerId}/logs`, {
        params: {
          stdout: true,
          stderr: true,
          tail: tail.toString(),
        },
        responseType: 'stream',
      });
      
      return new Promise<string>((resolve, reject) => {
        let logs = '';
        const responseStream = response.data as stream.Readable;
        
        responseStream.on('data', (chunk) => {
          // Docker API prepends each line with 8 bytes of header
          // First byte is stream type (1 = stdout, 2 = stderr)
          // Next 3 bytes are padding (zeros)
          // Last 4 bytes are length (uint32)
          // We need to strip these headers
          let data = chunk;
          if (data.length > 8) {
            // Check if this is a header
            if (data[0] <= 2 && data[1] === 0 && data[2] === 0 && data[3] === 0) {
              // Strip the header
              data = data.slice(8);
            }
          }
          logs += data.toString();
        });
        
        responseStream.on('end', () => {
          resolve(logs);
        });
        
        responseStream.on('error', (err) => {
          reject(err);
        });
      });
    } catch (error) {
      console.error(`Failed to get logs for container ${containerId}:`, error);
      return '';
    }
  }
}

export default DockerApiInterface;
