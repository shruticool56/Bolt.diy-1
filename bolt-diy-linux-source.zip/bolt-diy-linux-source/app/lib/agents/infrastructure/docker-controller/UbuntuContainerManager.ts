/**
 * UbuntuContainerManager.ts
 * 
 * This module provides specialized management for minimal Ubuntu containers,
 * allowing the AI agent to autonomously control and operate within Ubuntu environments.
 */

import DockerApiInterface, { ContainerOptions } from './DockerApiInterface.js';
import * as fs from 'fs';
import * as path from 'path';
import { promisify } from 'util';
import { exec } from 'child_process';

const execAsync = promisify(exec);
const writeFileAsync = promisify(fs.writeFile);
const mkdirAsync = promisify(fs.mkdir);

export interface UbuntuContainerConfig {
  name?: string;
  tag?: string;
  workingDir?: string;
  sharedVolumes?: Record<string, string>;
  environmentVars?: Record<string, string>;
  ports?: Record<string, string>;
  initScript?: string;
  autoRemove?: boolean;
  privileged?: boolean;
}

/**
 * UbuntuContainerManager class provides specialized management for Ubuntu containers
 */
export class UbuntuContainerManager {
  private docker: DockerApiInterface;
  private containerId: string | null = null;
  private containerName: string;
  private imageName: string;
  private config: UbuntuContainerConfig;
  private initialized: boolean = false;
  private initScriptPath: string;

  /**
   * Constructor for UbuntuContainerManager
   * @param config Configuration for the Ubuntu container
   * @param docker Optional DockerApiInterface instance
   */
  constructor(config: UbuntuContainerConfig = {}, docker?: DockerApiInterface) {
    this.docker = docker || new DockerApiInterface();
    
    // Ensure name is always defined
    const containerName = config.name || `ubuntu-sandbox-${Date.now()}`;
    
    this.config = {
      name: containerName,
      tag: config.tag || 'latest',
      workingDir: config.workingDir || '/workspace',
      sharedVolumes: config.sharedVolumes || {},
      environmentVars: config.environmentVars || {},
      ports: config.ports || {},
      initScript: config.initScript || this.getDefaultInitScript(),
      autoRemove: config.autoRemove !== undefined ? config.autoRemove : false,
      privileged: config.privileged !== undefined ? config.privileged : false,
    };
    
    this.containerName = containerName;
    this.imageName = `ubuntu:${this.config.tag}`;
    this.initScriptPath = `/tmp/ubuntu-init-${Date.now()}.sh`;
  }

  /**
   * Provides a default initialization script for Ubuntu containers
   * @returns Default initialization script content
   */
  private getDefaultInitScript(): string {
    return `#!/bin/bash
# Default initialization script for minimal Ubuntu container

# Update package lists
apt-get update

# Install minimal essential tools
apt-get install -y --no-install-recommends \\
  ca-certificates \\
  curl \\
  wget \\
  git \\
  python3-minimal \\
  python3-pip \\
  nano \\
  vim \\
  less \\
  net-tools \\
  iputils-ping \\
  sudo

# Create workspace directory if it doesn't exist
mkdir -p ${this.config.workingDir}

# Clean up
apt-get clean
rm -rf /var/lib/apt/lists/*

echo "Container initialized and ready for use"
`;
  }

  /**
   * Checks if Docker is available
   * @returns Promise<boolean> True if Docker is available
   */
  async isDockerAvailable(): Promise<boolean> {
    return this.docker.isDockerAvailable();
  }

  /**
   * Initializes the Ubuntu container environment
   * @returns Promise<boolean> True if initialization was successful
   */
  async initialize(): Promise<boolean> {
    try {
      // Check if Docker is available
      const dockerAvailable = await this.isDockerAvailable();
      if (!dockerAvailable) {
        console.error('Docker is not available. Cannot initialize Ubuntu container.');
        return false;
      }

      // Check if the Ubuntu image exists, pull if not
      const images = await this.docker.listImages();
      if (!images.includes(this.imageName)) {
        console.log(`Ubuntu image ${this.imageName} not found. Pulling...`);
        const pulled = await this.docker.pullImage(this.imageName);
        if (!pulled) {
          console.error(`Failed to pull Ubuntu image ${this.imageName}`);
          return false;
        }
      }

      // Check if container already exists
      const containerExists = await this.docker.containerExists(this.containerName);
      if (containerExists) {
        console.log(`Container ${this.containerName} already exists. Reusing...`);
        const containers = await this.docker.listContainers(true);
        const container = containers.find(c => c.name === this.containerName);
        
        if (container) {
          this.containerId = container.id;
          
          // Start the container if it's not running
          if (container.state !== 'running') {
            console.log(`Starting container ${this.containerName}...`);
            await this.docker.startContainer(this.containerId);
          }
          
          this.initialized = true;
          return true;
        }
      }

      // Create initialization script
      const initScript = this.config.initScript || this.getDefaultInitScript();
      await writeFileAsync(this.initScriptPath, initScript, { mode: 0o755 });

      // Prepare shared volumes
      const volumes = { ...this.config.sharedVolumes };
      
      // Ensure workspace directory exists
      if (this.config.workingDir) {
        const hostWorkspace = `/tmp/ubuntu-workspace-${Date.now()}`;
        await mkdirAsync(hostWorkspace, { recursive: true });
        volumes[hostWorkspace] = this.config.workingDir;
      }

      // Create and start the container
      console.log(`Creating Ubuntu container ${this.containerName}...`);
      const containerOptions: ContainerOptions = {
        name: this.containerName,
        cmd: ['/bin/bash'],
        env: this.config.environmentVars,
        volumes,
        ports: this.config.ports,
        workingDir: this.config.workingDir,
        autoRemove: this.config.autoRemove,
        privileged: this.config.privileged,
      };

      this.containerId = await this.docker.runContainer(this.imageName, containerOptions);
      console.log(`Ubuntu container created with ID: ${this.containerId}`);

      // Copy and execute initialization script
      const scriptDestPath = '/tmp/init.sh';
      await this.docker.copyToContainer(this.containerId, this.initScriptPath, '/tmp');
      
      console.log('Running initialization script...');
      const output = await this.docker.execInContainer(this.containerId, ['bash', scriptDestPath]);
      console.log('Initialization output:', output);

      // Clean up
      fs.unlinkSync(this.initScriptPath);
      
      this.initialized = true;
      return true;
    } catch (error) {
      console.error('Failed to initialize Ubuntu container:', error);
      return false;
    }
  }

  /**
   * Executes a command in the Ubuntu container
   * @param command Command to execute
   * @param workingDir Working directory (defaults to container's working dir)
   * @returns Promise<string> Command output
   */
  async executeCommand(command: string[], workingDir?: string): Promise<string> {
    if (!this.initialized || !this.containerId) {
      const initialized = await this.initialize();
      if (!initialized) {
        throw new Error('Failed to initialize Ubuntu container');
      }
    }

    // At this point, this.containerId is guaranteed to be non-null
    if (!this.containerId) {
      throw new Error('Container ID is unexpectedly null after initialization');
    }

    return this.docker.execInContainer(
      this.containerId,
      command,
      workingDir || this.config.workingDir
    );
  }

  /**
   * Executes a shell script in the Ubuntu container
   * @param scriptContent Shell script content
   * @param workingDir Working directory
   * @returns Promise<string> Script output
   */
  async executeScript(scriptContent: string, workingDir?: string): Promise<string> {
    if (!this.initialized || !this.containerId) {
      const initialized = await this.initialize();
      if (!initialized) {
        throw new Error('Failed to initialize Ubuntu container');
      }
    }

    // At this point, this.containerId is guaranteed to be non-null
    if (!this.containerId) {
      throw new Error('Container ID is unexpectedly null after initialization');
    }

    // Create temporary script file
    const scriptPath = `/tmp/script-${Date.now()}.sh`;
    await writeFileAsync(scriptPath, scriptContent, { mode: 0o755 });

    // Copy script to container
    const containerScriptPath = '/tmp/script.sh';
    await this.docker.copyToContainer(this.containerId, scriptPath, '/tmp');

    // Execute script
    const output = await this.docker.execInContainer(
      this.containerId,
      ['bash', containerScriptPath],
      workingDir || this.config.workingDir
    );

    // Clean up
    fs.unlinkSync(scriptPath);

    return output;
  }

  /**
   * Copies a file from host to the Ubuntu container
   * @param sourcePath Source path on host
   * @param destPath Destination path in container
   * @returns Promise<boolean> True if copy was successful
   */
  async copyToContainer(sourcePath: string, destPath: string): Promise<boolean> {
    if (!this.initialized || !this.containerId) {
      const initialized = await this.initialize();
      if (!initialized) {
        throw new Error('Failed to initialize Ubuntu container');
      }
    }

    // At this point, this.containerId is guaranteed to be non-null
    if (!this.containerId) {
      throw new Error('Container ID is unexpectedly null after initialization');
    }

    return this.docker.copyToContainer(this.containerId, sourcePath, destPath);
  }

  /**
   * Copies a file from the Ubuntu container to host
   * @param sourcePath Source path in container
   * @param destPath Destination path on host
   * @returns Promise<boolean> True if copy was successful
   */
  async copyFromContainer(sourcePath: string, destPath: string): Promise<boolean> {
    if (!this.initialized || !this.containerId) {
      const initialized = await this.initialize();
      if (!initialized) {
        throw new Error('Failed to initialize Ubuntu container');
      }
    }

    // At this point, this.containerId is guaranteed to be non-null
    if (!this.containerId) {
      throw new Error('Container ID is unexpectedly null after initialization');
    }

    return this.docker.copyFromContainer(this.containerId, sourcePath, destPath);
  }

  /**
   * Installs packages in the Ubuntu container
   * @param packages Array of package names to install
   * @returns Promise<string> Installation output
   */
  async installPackages(packages: string[]): Promise<string> {
    if (!this.initialized || !this.containerId) {
      const initialized = await this.initialize();
      if (!initialized) {
        throw new Error('Failed to initialize Ubuntu container');
      }
    }

    // At this point, this.containerId is guaranteed to be non-null
    if (!this.containerId) {
      throw new Error('Container ID is unexpectedly null after initialization');
    }

    const packageList = packages.join(' ');
    return this.executeCommand([
      'bash', 
      '-c', 
      `apt-get update && apt-get install -y --no-install-recommends ${packageList} && apt-get clean && rm -rf /var/lib/apt/lists/*`
    ]);
  }

  /**
   * Gets container logs
   * @param tail Number of lines to return from the end
   * @returns Promise<string> Container logs
   */
  async getLogs(tail = 100): Promise<string> {
    if (!this.containerId) {
      return 'Container not initialized';
    }

    return this.docker.getContainerLogs(this.containerId, tail);
  }

  /**
   * Stops the Ubuntu container
   * @returns Promise<boolean> True if container was stopped successfully
   */
  async stop(): Promise<boolean> {
    if (!this.containerId) {
      return true; // Already stopped
    }

    return this.docker.stopContainer(this.containerId);
  }

  /**
   * Removes the Ubuntu container
   * @param force Force removal of running container
   * @returns Promise<boolean> True if container was removed successfully
   */
  async remove(force = false): Promise<boolean> {
    if (!this.containerId) {
      return true; // Already removed
    }

    if (force) {
      return this.docker.removeContainer(this.containerId, true);
    }

    // Stop first, then remove
    await this.stop();
    return this.docker.removeContainer(this.containerId);
  }

  /**
   * Gets the container ID
   * @returns Container ID or null if not initialized
   */
  getContainerId(): string | null {
    return this.containerId;
  }

  /**
   * Gets the container name
   * @returns Container name
   */
  getContainerName(): string {
    return this.containerName;
  }

  /**
   * Checks if the container is initialized
   * @returns True if container is initialized
   */
  isInitialized(): boolean {
    return this.initialized;
  }
}

export default UbuntuContainerManager;
