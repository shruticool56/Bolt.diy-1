/**
 * index.ts
 * 
 * Main module for Docker integration functionality
 * Exports all Docker-related modules using ES module syntax
 */

// Re-export all Docker modules with ES module syntax
export { default as DockerApiInterface } from './DockerApiInterface.js';
export { default as UbuntuContainerManager } from './UbuntuContainerManager.js';
export { default as EnvironmentSelector, EnvironmentType } from './EnvironmentSelector.js';
export { default as TaskExecutionBridge } from './TaskExecutionBridge.js';

// Export types
export type { ContainerOptions, ExecOptions, ContainerInfo } from './DockerApiInterface.js';
export type { UbuntuContainerConfig } from './UbuntuContainerManager.js';
export type { TaskRequirements, EnvironmentPreference } from './EnvironmentSelector.js';
export type { TaskResult } from './TaskExecutionBridge.js';
