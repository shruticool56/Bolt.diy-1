/**
 * EnvironmentSelector.ts
 * 
 * This module provides decision-making logic for selecting between
 * Node.js and Ubuntu environments based on task requirements.
 */

import UbuntuContainerManager from './UbuntuContainerManager.js';

export interface TaskRequirements {
  type: string;
  requiresUbuntu?: boolean;
  requiresNodeJs?: boolean;
  resourceIntensive?: boolean;
  packages?: string[];
  description?: string;
}

export enum EnvironmentType {
  NODEJS = 'nodejs',
  UBUNTU = 'ubuntu',
}

export interface EnvironmentPreference {
  taskType: string;
  preferredEnvironment: EnvironmentType;
  reason: string;
}

/**
 * EnvironmentSelector class provides logic for selecting the appropriate
 * environment (Node.js or Ubuntu) based on task requirements and user preferences.
 */
export class EnvironmentSelector {
  private ubuntuManager: UbuntuContainerManager;
  private preferences: EnvironmentPreference[] = [];
  
  /**
   * Constructor for EnvironmentSelector
   * @param ubuntuManager UbuntuContainerManager instance
   */
  constructor(ubuntuManager?: UbuntuContainerManager) {
    this.ubuntuManager = ubuntuManager || new UbuntuContainerManager();
    
    // Initialize with some default preferences
    this.preferences = [
      {
        taskType: 'web_development',
        preferredEnvironment: EnvironmentType.NODEJS,
        reason: 'Node.js environment is optimized for web development tasks',
      },
      {
        taskType: 'system_administration',
        preferredEnvironment: EnvironmentType.UBUNTU,
        reason: 'Ubuntu environment is better suited for system administration tasks',
      },
      {
        taskType: 'data_processing',
        preferredEnvironment: EnvironmentType.NODEJS,
        reason: 'Node.js environment has better performance for data processing tasks',
      },
    ];
  }
  
  /**
   * Selects the appropriate environment based on task requirements
   * @param requirements Task requirements
   * @returns Selected environment type
   */
  async selectEnvironment(requirements: TaskRequirements): Promise<EnvironmentType> {
    // If explicitly requires Ubuntu, use Ubuntu
    if (requirements.requiresUbuntu) {
      console.log(`Task explicitly requires Ubuntu environment: ${requirements.description}`);
      return EnvironmentType.UBUNTU;
    }
    
    // If explicitly requires Node.js, use Node.js
    if (requirements.requiresNodeJs) {
      console.log(`Task explicitly requires Node.js environment: ${requirements.description}`);
      return EnvironmentType.NODEJS;
    }
    
    // Check user preferences for this task type
    const preference = this.preferences.find(p => p.taskType === requirements.type);
    if (preference) {
      console.log(`Using preferred environment ${preference.preferredEnvironment} for task type ${requirements.type}: ${preference.reason}`);
      return preference.preferredEnvironment;
    }
    
    // Make decision based on task type and requirements
    switch (requirements.type) {
      case 'file_system_operations':
      case 'package_installation':
      case 'system_monitoring':
      case 'network_operations':
      case 'security_testing':
        console.log(`Selected Ubuntu environment for task type: ${requirements.type}`);
        return EnvironmentType.UBUNTU;
        
      case 'web_development':
      case 'javascript_execution':
      case 'typescript_compilation':
      case 'npm_operations':
      case 'frontend_building':
        console.log(`Selected Node.js environment for task type: ${requirements.type}`);
        return EnvironmentType.NODEJS;
        
      default:
        // For unknown task types, default to Node.js as it's the primary environment
        console.log(`Defaulting to Node.js environment for unknown task type: ${requirements.type}`);
        return EnvironmentType.NODEJS;
    }
  }
  
  /**
   * Adds or updates a user preference for task environment
   * @param preference Environment preference to add or update
   */
  addPreference(preference: EnvironmentPreference): void {
    // Remove existing preference for this task type if it exists
    this.preferences = this.preferences.filter(p => p.taskType !== preference.taskType);
    
    // Add the new preference
    this.preferences.push(preference);
    console.log(`Added environment preference: ${preference.taskType} -> ${preference.preferredEnvironment}`);
  }
  
  /**
   * Gets all current environment preferences
   * @returns Array of environment preferences
   */
  getPreferences(): EnvironmentPreference[] {
    return [...this.preferences];
  }
  
  /**
   * Prepares the selected environment for task execution
   * @param environment Environment type to prepare
   * @param requirements Task requirements
   * @returns Promise<boolean> True if environment was prepared successfully
   */
  async prepareEnvironment(environment: EnvironmentType, requirements: TaskRequirements): Promise<boolean> {
    if (environment === EnvironmentType.UBUNTU) {
      // Initialize Ubuntu container if not already initialized
      if (!this.ubuntuManager.isInitialized()) {
        console.log('Initializing Ubuntu container...');
        const initialized = await this.ubuntuManager.initialize();
        if (!initialized) {
          console.error('Failed to initialize Ubuntu container');
          return false;
        }
      }
      
      // Install required packages if specified
      if (requirements.packages && requirements.packages.length > 0) {
        console.log(`Installing required packages: ${requirements.packages.join(', ')}`);
        try {
          await this.ubuntuManager.installPackages(requirements.packages);
        } catch (error) {
          console.error('Failed to install packages:', error);
          return false;
        }
      }
      
      return true;
    } else {
      // Node.js environment is always ready in the current setup
      return true;
    }
  }
  
  /**
   * Gets the Ubuntu container manager
   * @returns UbuntuContainerManager instance
   */
  getUbuntuManager(): UbuntuContainerManager {
    return this.ubuntuManager;
  }
}

export default EnvironmentSelector;
