/**
 * TaskExecutionBridge.ts
 * 
 * This module provides a bridge for executing agent tasks in different environments,
 * translating high-level tasks into appropriate container operations.
 */

import { EnvironmentSelector, EnvironmentType, TaskRequirements } from './EnvironmentSelector.js';
import UbuntuContainerManager from './UbuntuContainerManager.js';
import * as fs from 'fs';
import * as path from 'path';
import { promisify } from 'util';

const writeFileAsync = promisify(fs.writeFile);
const readFileAsync = promisify(fs.readFile);
const mkdirAsync = promisify(fs.mkdir);

export interface TaskResult {
  success: boolean;
  output: string;
  environment: EnvironmentType;
  error?: string;
}

/**
 * TaskExecutionBridge class provides methods to execute tasks in the appropriate environment
 */
export class TaskExecutionBridge {
  private environmentSelector: EnvironmentSelector;
  
  /**
   * Constructor for TaskExecutionBridge
   * @param environmentSelector EnvironmentSelector instance
   */
  constructor(environmentSelector?: EnvironmentSelector) {
    this.environmentSelector = environmentSelector || new EnvironmentSelector();
  }
  
  /**
   * Executes a command in the appropriate environment
   * @param command Command to execute
   * @param requirements Task requirements
   * @returns Promise<TaskResult> Task execution result
   */
  async executeCommand(command: string[], requirements: TaskRequirements): Promise<TaskResult> {
    try {
      // Select the appropriate environment
      const environment = await this.environmentSelector.selectEnvironment(requirements);
      
      // Prepare the environment
      const prepared = await this.environmentSelector.prepareEnvironment(environment, requirements);
      if (!prepared) {
        return {
          success: false,
          output: '',
          environment,
          error: 'Failed to prepare environment',
        };
      }
      
      // Execute the command in the selected environment
      if (environment === EnvironmentType.UBUNTU) {
        const ubuntuManager = this.environmentSelector.getUbuntuManager();
        const output = await ubuntuManager.executeCommand(command);
        
        return {
          success: true,
          output,
          environment,
        };
      } else {
        // For Node.js environment, execute command using child_process
        const { exec } = require('child_process');
        const execAsync = promisify(exec);
        
        const { stdout, stderr } = await execAsync(command.join(' '));
        const output = stdout + (stderr ? `\nError: ${stderr}` : '');
        
        return {
          success: !stderr,
          output,
          environment,
          error: stderr || undefined,
        };
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        output: '',
        environment: EnvironmentType.NODEJS, // Default
        error: errorMessage,
      };
    }
  }
  
  /**
   * Executes a script in the appropriate environment
   * @param scriptContent Script content
   * @param scriptType Script type (e.g., 'bash', 'python', 'node')
   * @param requirements Task requirements
   * @returns Promise<TaskResult> Task execution result
   */
  async executeScript(
    scriptContent: string,
    scriptType: 'bash' | 'python' | 'node',
    requirements: TaskRequirements
  ): Promise<TaskResult> {
    try {
      // Select the appropriate environment
      const environment = await this.environmentSelector.selectEnvironment(requirements);
      
      // Prepare the environment
      const prepared = await this.environmentSelector.prepareEnvironment(environment, requirements);
      if (!prepared) {
        return {
          success: false,
          output: '',
          environment,
          error: 'Failed to prepare environment',
        };
      }
      
      // Create temporary script file
      const tempDir = '/tmp/agent-scripts';
      if (!fs.existsSync(tempDir)) {
        await mkdirAsync(tempDir, { recursive: true });
      }
      
      const scriptExtension = scriptType === 'bash' ? 'sh' : 
                             scriptType === 'python' ? 'py' : 'js';
      const scriptPath = path.join(tempDir, `script-${Date.now()}.${scriptExtension}`);
      await writeFileAsync(scriptPath, scriptContent, { mode: 0o755 });
      
      // Execute the script in the selected environment
      if (environment === EnvironmentType.UBUNTU) {
        const ubuntuManager = this.environmentSelector.getUbuntuManager();
        
        // Copy script to container
        const containerScriptPath = `/tmp/script.${scriptExtension}`;
        await ubuntuManager.copyToContainer(scriptPath, containerScriptPath);
        
        // Execute script based on type
        let command: string[];
        switch (scriptType) {
          case 'bash':
            command = ['bash', containerScriptPath];
            break;
          case 'python':
            command = ['python3', containerScriptPath];
            break;
          case 'node':
            // Ensure Node.js is installed in Ubuntu container if needed
            if (!requirements.packages?.includes('nodejs')) {
              await ubuntuManager.installPackages(['nodejs']);
            }
            command = ['node', containerScriptPath];
            break;
        }
        
        const output = await ubuntuManager.executeCommand(command);
        
        // Clean up
        fs.unlinkSync(scriptPath);
        
        return {
          success: true,
          output,
          environment,
        };
      } else {
        // For Node.js environment, execute script using child_process
        const { exec } = require('child_process');
        const execAsync = promisify(exec);
        
        let command: string;
        switch (scriptType) {
          case 'bash':
            command = `bash ${scriptPath}`;
            break;
          case 'python':
            command = `python3 ${scriptPath}`;
            break;
          case 'node':
            command = `node ${scriptPath}`;
            break;
        }
        
        const { stdout, stderr } = await execAsync(command);
        const output = stdout + (stderr ? `\nError: ${stderr}` : '');
        
        // Clean up
        fs.unlinkSync(scriptPath);
        
        return {
          success: !stderr,
          output,
          environment,
          error: stderr || undefined,
        };
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        output: '',
        environment: EnvironmentType.NODEJS, // Default
        error: errorMessage,
      };
    }
  }
  
  /**
   * Transfers a file between host and container
   * @param sourcePath Source path
   * @param destPath Destination path
   * @param direction 'to_container' or 'from_container'
   * @param requirements Task requirements
   * @returns Promise<TaskResult> Task execution result
   */
  async transferFile(
    sourcePath: string,
    destPath: string,
    direction: 'to_container' | 'from_container',
    requirements: TaskRequirements
  ): Promise<TaskResult> {
    try {
      // For file transfers, we need to ensure we're using the Ubuntu environment
      requirements.requiresUbuntu = true;
      
      // Select and prepare the environment
      const environment = await this.environmentSelector.selectEnvironment(requirements);
      const prepared = await this.environmentSelector.prepareEnvironment(environment, requirements);
      
      if (!prepared || environment !== EnvironmentType.UBUNTU) {
        return {
          success: false,
          output: '',
          environment,
          error: 'Failed to prepare Ubuntu environment for file transfer',
        };
      }
      
      const ubuntuManager = this.environmentSelector.getUbuntuManager();
      let success: boolean;
      
      if (direction === 'to_container') {
        success = await ubuntuManager.copyToContainer(sourcePath, destPath);
      } else {
        success = await ubuntuManager.copyFromContainer(sourcePath, destPath);
      }
      
      return {
        success,
        output: success ? `File transfer successful: ${direction === 'to_container' ? 'to' : 'from'} container` : '',
        environment,
        error: success ? undefined : 'File transfer failed',
      };
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        output: '',
        environment: EnvironmentType.UBUNTU,
        error: errorMessage,
      };
    }
  }
  
  /**
   * Installs packages in the Ubuntu environment
   * @param packages Array of package names to install
   * @returns Promise<TaskResult> Task execution result
   */
  async installUbuntuPackages(packages: string[]): Promise<TaskResult> {
    try {
      const requirements: TaskRequirements = {
        type: 'package_installation',
        requiresUbuntu: true,
        packages,
      };
      
      // Select and prepare the environment
      const environment = await this.environmentSelector.selectEnvironment(requirements);
      const prepared = await this.environmentSelector.prepareEnvironment(environment, requirements);
      
      if (!prepared || environment !== EnvironmentType.UBUNTU) {
        return {
          success: false,
          output: '',
          environment,
          error: 'Failed to prepare Ubuntu environment for package installation',
        };
      }
      
      const ubuntuManager = this.environmentSelector.getUbuntuManager();
      const output = await ubuntuManager.installPackages(packages);
      
      return {
        success: true,
        output,
        environment,
      };
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        output: '',
        environment: EnvironmentType.UBUNTU,
        error: errorMessage,
      };
    }
  }
  
  /**
   * Gets the environment selector
   * @returns EnvironmentSelector instance
   */
  getEnvironmentSelector(): EnvironmentSelector {
    return this.environmentSelector;
  }
}

export default TaskExecutionBridge;
