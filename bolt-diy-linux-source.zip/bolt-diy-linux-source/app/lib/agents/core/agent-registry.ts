/**
 * Agent Registry Implementation for Autonomous Cognition Core
 * 
 * Provides centralized registration and discovery of agents in the system.
 */

import { Agent, AgentCapability, AgentStatus } from './types';
import { memorySystem } from './memory';

/**
 * Agent Registry for the Autonomous Cognition Core
 * 
 * Manages agent registration, discovery, and capability advertisement.
 */
class AgentRegistry {
  private static instance: AgentRegistry;
  private agents: Map<string, {
    id: string;
    name: string;
    description: string;
    capabilities: AgentCapability[];
    status: AgentStatus;
    lastUpdated: number;
  }> = new Map();
  
  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the agent registry
   */
  public static getInstance(): AgentRegistry {
    if (!AgentRegistry.instance) {
      AgentRegistry.instance = new AgentRegistry();
    }
    return AgentRegistry.instance;
  }

  /**
   * Register an agent with the registry
   * 
   * @param agent The agent to register
   * @returns true if registration was successful
   */
  public registerAgent(agent: Agent): boolean {
    const now = Date.now();
    
    this.agents.set(agent.id, {
      id: agent.id,
      name: agent.name,
      description: agent.description,
      capabilities: agent.capabilities,
      status: agent.status,
      lastUpdated: now
    });
    
    // Store in memory for context awareness
    memorySystem.storeLongTerm({
      type: 'knowledge',
      content: {
        type: 'agent_registered',
        agentId: agent.id,
        name: agent.name,
        description: agent.description,
        capabilities: agent.capabilities.map(c => ({
          id: c.id,
          name: c.name,
          description: c.description
        }))
      },
      tags: ['agent', 'registered', agent.id],
      importance: 60,
      createdAt: now,
      metadata: {}
    });
    
    return true;
  }

  /**
   * Unregister an agent from the registry
   * 
   * @param agentId ID of the agent to unregister
   * @returns true if agent was found and unregistered
   */
  public unregisterAgent(agentId: string): boolean {
    const result = this.agents.delete(agentId);
    
    if (result) {
      // Store in memory for context awareness
      memorySystem.storeShortTerm({
        type: 'context',
        content: {
          type: 'agent_unregistered',
          agentId
        },
        tags: ['agent', 'unregistered', agentId],
        importance: 60,
        createdAt: Date.now(),
        metadata: {}
      });
    }
    
    return result;
  }

  /**
   * Update agent status in the registry
   * 
   * @param agentId ID of the agent to update
   * @param status New status for the agent
   * @returns true if agent was found and updated
   */
  public updateAgentStatus(agentId: string, status: AgentStatus): boolean {
    const agent = this.agents.get(agentId);
    if (!agent) {
      return false;
    }
    
    agent.status = status;
    agent.lastUpdated = Date.now();
    
    return true;
  }

  /**
   * Get an agent by ID
   * 
   * @param agentId ID of the agent to retrieve
   * @returns Agent information or null if not found
   */
  public getAgent(agentId: string): {
    id: string;
    name: string;
    description: string;
    capabilities: AgentCapability[];
    status: AgentStatus;
    lastUpdated: number;
  } | null {
    return this.agents.get(agentId) || null;
  }

  /**
   * Get all registered agents
   * 
   * @returns Array of all registered agents
   */
  public getAllAgents(): Array<{
    id: string;
    name: string;
    description: string;
    capabilities: AgentCapability[];
    status: AgentStatus;
    lastUpdated: number;
  }> {
    return Array.from(this.agents.values());
  }

  /**
   * Find agents by capability
   * 
   * @param capabilityId ID of the capability to search for
   * @returns Array of agents that provide the capability
   */
  public findAgentsByCapability(capabilityId: string): Array<{
    id: string;
    name: string;
    description: string;
    capability: AgentCapability;
    status: AgentStatus;
  }> {
    const results = [];
    
    for (const agent of this.agents.values()) {
      const capability = agent.capabilities.find(c => c.id === capabilityId);
      
      if (capability) {
        results.push({
          id: agent.id,
          name: agent.name,
          description: agent.description,
          capability,
          status: agent.status
        });
      }
    }
    
    return results;
  }

  /**
   * Find agents by status
   * 
   * @param status Status to search for
   * @returns Array of agents with the specified status
   */
  public findAgentsByStatus(status: AgentStatus): Array<{
    id: string;
    name: string;
    description: string;
    capabilities: AgentCapability[];
    status: AgentStatus;
    lastUpdated: number;
  }> {
    return Array.from(this.agents.values())
      .filter(agent => agent.status === status);
  }
}

export const agentRegistry = AgentRegistry.getInstance();
