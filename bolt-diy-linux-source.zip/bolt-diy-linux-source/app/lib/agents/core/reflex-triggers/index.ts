/**
 * SentienceAI Cognitive Kernel - Reflex Triggers
 * 
 * This module implements the Reflex Triggers:
 * - Automatically activates when failures surpass a threshold
 * - Detects recurring bugs and patterns
 * - Identifies consistent shortcomings from feedback
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal, JournalEntryType } from '../execution-journal';
import { FeedbackInterpreterAgent, FeedbackType } from '../../supervisory/feedback-interpreter';
import { CodeSelfEditor, CodeChangeRequest } from '../code-self-editor';

export interface TriggerRule {
  id: string;
  name: string;
  description: string;
  type: 'error_threshold' | 'recurring_bug' | 'feedback_pattern' | 'performance_degradation';
  conditions: {
    metric: string;
    operator: '>' | '<' | '>=' | '<=' | '==' | '!=';
    value: any;
    timeWindow?: number; // Time window in milliseconds
  }[];
  action: {
    type: 'code_change_request' | 'notification' | 'system_restart' | 'custom';
    params: any;
  };
  enabled: boolean;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface TriggerEvent {
  id: string;
  timestamp: number;
  ruleId: string;
  taskId: string;
  matchedConditions: any[];
  actionTaken: any;
  result: 'success' | 'failure';
  metadata: any;
}

export class ReflexTriggers extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private feedbackInterpreter: FeedbackInterpreterAgent;
  private codeSelfEditor: CodeSelfEditor;
  private rules: Map<string, TriggerRule> = new Map();
  private events: Map<string, TriggerEvent[]> = new Map();
  private monitoringInterval: NodeJS.Timeout | null = null;
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    feedbackInterpreter?: FeedbackInterpreterAgent,
    codeSelfEditor?: CodeSelfEditor
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.feedbackInterpreter = feedbackInterpreter || new FeedbackInterpreterAgent();
    this.codeSelfEditor = codeSelfEditor || new CodeSelfEditor();
    
    // Initialize default rules
    this.initializeDefaultRules();
  }

  /**
   * Initializes default trigger rules
   */
  private initializeDefaultRules(): void {
    const defaultRules: TriggerRule[] = [
      {
        id: uuidv4(),
        name: 'High Error Rate',
        description: 'Triggers when error rate exceeds 10% in the last hour',
        type: 'error_threshold',
        conditions: [
          {
            metric: 'error_rate',
            operator: '>',
            value: 0.1,
            timeWindow: 3600000 // 1 hour
          }
        ],
        action: {
          type: 'code_change_request',
          params: {
            type: 'fix',
            priority: 'high',
            reason: 'High error rate detected'
          }
        },
        enabled: true,
        priority: 'high'
      },
      {
        id: uuidv4(),
        name: 'Recurring Same Error',
        description: 'Triggers when the same error occurs 3 times in 10 minutes',
        type: 'recurring_bug',
        conditions: [
          {
            metric: 'error_recurrence',
            operator: '>=',
            value: 3,
            timeWindow: 600000 // 10 minutes
          }
        ],
        action: {
          type: 'code_change_request',
          params: {
            type: 'fix',
            priority: 'critical',
            reason: 'Recurring error detected'
          }
        },
        enabled: true,
        priority: 'critical'
      },
      {
        id: uuidv4(),
        name: 'Consistent Negative Feedback',
        description: 'Triggers when negative feedback exceeds 30% in the last day',
        type: 'feedback_pattern',
        conditions: [
          {
            metric: 'negative_feedback_rate',
            operator: '>',
            value: 0.3,
            timeWindow: 86400000 // 24 hours
          }
        ],
        action: {
          type: 'code_change_request',
          params: {
            type: 'enhance',
            priority: 'medium',
            reason: 'Consistent negative feedback'
          }
        },
        enabled: true,
        priority: 'medium'
      },
      {
        id: uuidv4(),
        name: 'Performance Degradation',
        description: 'Triggers when response time increases by 50% over baseline',
        type: 'performance_degradation',
        conditions: [
          {
            metric: 'response_time_increase',
            operator: '>',
            value: 0.5 // 50% increase
          }
        ],
        action: {
          type: 'code_change_request',
          params: {
            type: 'optimize',
            priority: 'high',
            reason: 'Performance degradation detected'
          }
        },
        enabled: true,
        priority: 'high'
      }
    ];
    
    for (const rule of defaultRules) {
      this.rules.set(rule.id, rule);
    }
  }

  /**
   * Starts monitoring for trigger conditions
   */
  public startMonitoring(intervalMs: number = 60000): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
    
    this.monitoringInterval = setInterval(() => {
      this.checkAllRules().catch(err => {
        console.error('Error checking trigger rules:', err);
      });
    }, intervalMs);
    
    this.emit('monitoringStarted', { intervalMs });
  }

  /**
   * Stops monitoring
   */
  public stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      
      this.emit('monitoringStopped');
    }
  }

  /**
   * Checks all enabled rules
   */
  public async checkAllRules(): Promise<void> {
    const enabledRules = Array.from(this.rules.values()).filter(rule => rule.enabled);
    
    for (const rule of enabledRules) {
      try {
        await this.checkRule(rule);
      } catch (error) {
        console.error(`Error checking rule ${rule.id}:`, error);
      }
    }
  }

  /**
   * Checks a specific rule
   */
  public async checkRule(rule: TriggerRule): Promise<boolean> {
    // Get active tasks
    const activeTasks = await this.getActiveTasks();
    
    for (const taskId of activeTasks) {
      const conditionResults = await this.evaluateRuleConditions(rule, taskId);
      
      // If all conditions are met, trigger the action
      if (conditionResults.every(result => result.met)) {
        await this.triggerAction(rule, taskId, conditionResults);
        return true;
      }
    }
    
    return false;
  }

  /**
   * Gets active tasks
   */
  private async getActiveTasks(): Promise<string[]> {
    // In a real implementation, this would retrieve actual active tasks
    // For now, return a placeholder
    return ['default_task'];
  }

  /**
   * Evaluates rule conditions for a task
   */
  private async evaluateRuleConditions(
    rule: TriggerRule,
    taskId: string
  ): Promise<{ condition: any; met: boolean; value: any }[]> {
    const results: { condition: any; met: boolean; value: any }[] = [];
    
    for (const condition of rule.conditions) {
      const { metric, operator, value, timeWindow } = condition;
      
      // Get the current value for the metric
      const currentValue = await this.getMetricValue(metric, taskId, timeWindow);
      
      // Evaluate the condition
      let met = false;
      switch (operator) {
        case '>':
          met = currentValue > value;
          break;
        case '<':
          met = currentValue < value;
          break;
        case '>=':
          met = currentValue >= value;
          break;
        case '<=':
          met = currentValue <= value;
          break;
        case '==':
          met = currentValue == value;
          break;
        case '!=':
          met = currentValue != value;
          break;
      }
      
      results.push({
        condition,
        met,
        value: currentValue
      });
    }
    
    return results;
  }

  /**
   * Gets the current value for a metric
   */
  private async getMetricValue(
    metric: string,
    taskId: string,
    timeWindow?: number
  ): Promise<any> {
    const now = Date.now();
    const startTime = timeWindow ? now - timeWindow : 0;
    
    switch (metric) {
      case 'error_rate':
        return await this.calculateErrorRate(taskId, startTime);
        
      case 'error_recurrence':
        return await this.calculateErrorRecurrence(taskId, startTime);
        
      case 'negative_feedback_rate':
        return await this.calculateNegativeFeedbackRate(taskId, startTime);
        
      case 'response_time_increase':
        return await this.calculateResponseTimeIncrease(taskId);
        
      default:
        throw new Error(`Unknown metric: ${metric}`);
    }
  }

  /**
   * Calculates error rate for a task
   */
  private async calculateErrorRate(taskId: string, startTime: number): Promise<number> {
    const entries = this.executionJournal.getTaskEntries(taskId);
    
    // Filter entries by time window
    const recentEntries = entries.filter(entry => entry.timestamp >= startTime);
    
    if (recentEntries.length === 0) {
      return 0;
    }
    
    // Count error entries
    const errorEntries = recentEntries.filter(entry => entry.type === JournalEntryType.ERROR);
    
    return errorEntries.length / recentEntries.length;
  }

  /**
   * Calculates error recurrence for a task
   */
  private async calculateErrorRecurrence(taskId: string, startTime: number): Promise<number> {
    const entries = this.executionJournal.getTaskEntries(taskId);
    
    // Filter error entries by time window
    const recentErrorEntries = entries
      .filter(entry => 
        entry.type === JournalEntryType.ERROR && 
        entry.timestamp >= startTime
      );
    
    if (recentErrorEntries.length === 0) {
      return 0;
    }
    
    // Count occurrences of each error message
    const errorCounts: Record<string, number> = {};
    
    for (const entry of recentErrorEntries) {
      const errorMessage = entry.data?.message || 'unknown_error';
      errorCounts[errorMessage] = (errorCounts[errorMessage] || 0) + 1;
    }
    
    // Return the highest recurrence count
    return Math.max(...Object.values(errorCounts));
  }

  /**
   * Calculates negative feedback rate for a task
   */
  private async calculateNegativeFeedbackRate(taskId: string, startTime: number): Promise<number> {
    const feedbackSignals = await this.feedbackInterpreter.getTaskFeedback(taskId);
    
    // Filter signals by time window
    const recentSignals = feedbackSignals.filter(signal => signal.timestamp >= startTime);
    
    if (recentSignals.length === 0) {
      return 0;
    }
    
    // Count negative feedback signals
    const negativeSignals = recentSignals.filter(signal => 
      signal.type === FeedbackType.EXPLICIT_NEGATIVE || 
      signal.type === FeedbackType.IMPLICIT_NEGATIVE
    );
    
    return negativeSignals.length / recentSignals.length;
  }

  /**
   * Calculates response time increase for a task
   */
  private async calculateResponseTimeIncrease(taskId: string): Promise<number> {
    // In a real implementation, this would calculate the actual increase
    // For now, return a placeholder
    return 0.1; // 10% increase
  }

  /**
   * Triggers an action based on a rule
   */
  private async triggerAction(
    rule: TriggerRule,
    taskId: string,
    conditionResults: any[]
  ): Promise<void> {
    const { type, params } = rule.action;
    let actionResult: any = null;
    let success = false;
    
    try {
      switch (type) {
        case 'code_change_request':
          actionResult = await this.triggerCodeChangeRequest(rule, taskId, params);
          success = !!actionResult;
          break;
          
        case 'notification':
          actionResult = await this.triggerNotification(rule, taskId, params);
          success = true;
          break;
          
        case 'system_restart':
          actionResult = await this.triggerSystemRestart(params);
          success = true;
          break;
          
        case 'custom':
          actionResult = await this.triggerCustomAction(rule, taskId, params);
          success = !!actionResult;
          break;
      }
      
      // Create trigger event
      const event: TriggerEvent = {
        id: uuidv4(),
        timestamp: Date.now(),
        ruleId: rule.id,
        taskId,
        matchedConditions: conditionResults,
        actionTaken: {
          type,
          params,
          result: actionResult
        },
        result: success ? 'success' : 'failure',
        metadata: {}
      };
      
      // Store in memory
      if (!this.events.has(taskId)) {
        this.events.set(taskId, []);
      }
      this.events.get(taskId)!.push(event);
      
      // Persist to storage
      await this.persistTriggerEvent(event);
      
      // Log the event
      await this.executionJournal.logInfo(
        taskId,
        `Trigger rule activated: ${rule.name}`,
        { rule, event }
      );
      
      this.emit('triggerActivated', event);
    } catch (error) {
      // Log the error
      await this.executionJournal.logError(
        taskId,
        error
      );
      
      this.emit('triggerFailed', {
        ruleId: rule.id,
        taskId,
        error
      });
    }
  }

  /**
   * Triggers a code change request
   */
  private async triggerCodeChangeRequest(
    rule: TriggerRule,
    taskId: string,
    params: any
  ): Promise<CodeChangeRequest | null> {
    // Determine the file path
    // In a real implementation, this would analyze the errors to find the relevant file
    const filePath = params.filePath || this.determineFilePath(taskId, rule);
    
    if (!filePath) {
      throw new Error('Could not determine file path for code change request');
    }
    
    // Create the change request
    return this.codeSelfEditor.createChangeRequest(
      taskId,
      filePath,
      params.reason || rule.description,
      params.type || 'fix',
      params.priority || rule.priority,
      {
        triggerRule: rule.id,
        conditions: rule.conditions
      }
    );
  }

  /**
   * Determines the file path for a code change request
   */
  private determineFilePath(taskId: string, rule: TriggerRule): string | null {
    // In a real implementation, this would analyze errors and task context
    // For now, return a placeholder
    return '/path/to/file.ts';
  }

  /**
   * Triggers a notification
   */
  private async triggerNotification(
    rule: TriggerRule,
    taskId: string,
    params: any
  ): Promise<any> {
    // In a real implementation, this would send an actual notification
    // For now, just log it
    await this.executionJournal.logInfo(
      taskId,
      `Notification: ${params.message || rule.description}`,
      { rule, params }
    );
    
    return { sent: true };
  }

  /**
   * Triggers a system restart
   */
  private async triggerSystemRestart(params: any): Promise<any> {
    // In a real implementation, this would restart the system
    // For now, just log it
    console.log('System restart triggered:', params);
    
    return { restarted: true };
  }

  /**
   * Triggers a custom action
   */
  private async triggerCustomAction(
    rule: TriggerRule,
    taskId: string,
    params: any
  ): Promise<any> {
    // In a real implementation, this would execute a custom action
    // For now, just log it
    await this.executionJournal.logInfo(
      taskId,
      `Custom action: ${params.action || 'unknown'}`,
      { rule, params }
    );
    
    return { executed: true };
  }

  /**
   * Persists a trigger event to storage
   */
  private async persistTriggerEvent(event: TriggerEvent): Promise<void> {
    await this.memoryManager.storeMemory({
      id: event.id,
      type: MemoryType.LONG_TERM,
      key: `trigger_event:${event.taskId}:${event.id}`,
      value: event,
      metadata: {
        taskId: event.taskId,
        ruleId: event.ruleId,
        result: event.result
      },
      timestamp: event.timestamp
    });
  }

  /**
   * Adds a trigger rule
   */
  public addRule(rule: TriggerRule): void {
    this.rules.set(rule.id, rule);
    this.emit('ruleAdded', rule);
  }

  /**
   * Updates a trigger rule
   */
  public updateRule(ruleId: string, updates: Partial<TriggerRule>): boolean {
    const rule = this.rules.get(ruleId);
    if (!rule) {
      return false;
    }
    
    const updatedRule = { ...rule, ...updates };
    this.rules.set(ruleId, updatedRule);
    
    this.emit('ruleUpdated', updatedRule);
    return true;
  }

  /**
   * Removes a trigger rule
   */
  public removeRule(ruleId: string): boolean {
    const removed = this.rules.delete(ruleId);
    
    if (removed) {
      this.emit('ruleRemoved', ruleId);
    }
    
    return removed;
  }

  /**
   * Gets all trigger rules
   */
  public getRules(): TriggerRule[] {
    return Array.from(this.rules.values());
  }

  /**
   * Gets a trigger rule by ID
   */
  public getRule(ruleId: string): TriggerRule | undefined {
    return this.rules.get(ruleId);
  }

  /**
   * Gets all trigger events for a task
   */
  public getTaskEvents(taskId: string): TriggerEvent[] {
    return this.events.get(taskId) || [];
  }
}

export default ReflexTriggers;
