/**
 * SentienceAI Cognitive Kernel - Meta-Controller Agent
 * 
 * This module implements the Meta-Controller Agent:
 * - Supervises all agent interactions
 * - Coordinates multi-agent workflows
 * - Triggers self-improvement when criteria match
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal } from '../execution-journal';
import { SharedMemoryBus, Message, MessageType } from '../shared-memory-bus';
import { CognitiveLoop, CognitiveState } from '../cognitive-loop';

export interface AgentDefinition {
  id: string;
  name: string;
  type: string;
  capabilities: string[];
  status: 'active' | 'inactive' | 'busy' | 'error';
  metadata: any;
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  description: string;
  steps: {
    id: string;
    agentType: string;
    action: string;
    inputs: any;
    outputs: string[];
    dependencies: string[];
    timeout: number;
  }[];
  triggers: {
    type: 'event' | 'schedule' | 'condition';
    config: any;
  }[];
  metadata: any;
}

export interface WorkflowExecution {
  id: string;
  workflowId: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'aborted';
  startTime: number;
  endTime?: number;
  stepResults: {
    stepId: string;
    agentId: string;
    status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
    startTime?: number;
    endTime?: number;
    result?: any;
    error?: any;
  }[];
  variables: Record<string, any>;
  metadata: any;
}

export class MetaControllerAgent extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private sharedMemoryBus: SharedMemoryBus;
  private cognitiveLoop: CognitiveLoop;
  private agents: Map<string, AgentDefinition> = new Map();
  private workflows: Map<string, WorkflowDefinition> = new Map();
  private executions: Map<string, WorkflowExecution> = new Map();
  private subscriptions: string[] = [];
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    sharedMemoryBus?: SharedMemoryBus,
    cognitiveLoop?: CognitiveLoop
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.sharedMemoryBus = sharedMemoryBus || SharedMemoryBus.getInstance();
    this.cognitiveLoop = cognitiveLoop || CognitiveLoop.getInstance();
    
    // Initialize subscriptions
    this.initializeSubscriptions();
  }

  /**
   * Initializes message bus subscriptions
   */
  private initializeSubscriptions(): void {
    // Subscribe to agent registration messages
    const agentRegSub = this.sharedMemoryBus.subscribe(
      'meta-controller',
      'agent:register',
      this.handleAgentRegistration.bind(this)
    );
    this.subscriptions.push(agentRegSub.id);
    
    // Subscribe to agent status updates
    const agentStatusSub = this.sharedMemoryBus.subscribe(
      'meta-controller',
      'agent:status',
      this.handleAgentStatusUpdate.bind(this)
    );
    this.subscriptions.push(agentStatusSub.id);
    
    // Subscribe to workflow execution requests
    const workflowExecSub = this.sharedMemoryBus.subscribe(
      'meta-controller',
      'workflow:execute',
      this.handleWorkflowExecutionRequest.bind(this)
    );
    this.subscriptions.push(workflowExecSub.id);
    
    // Subscribe to cognitive loop state transitions
    this.cognitiveLoop.on('stateTransition', this.handleCognitiveStateTransition.bind(this));
  }

  /**
   * Handles agent registration messages
   */
  private handleAgentRegistration(message: Message): void {
    const { sender, payload } = message;
    
    // Extract agent definition from payload
    const agentDef: AgentDefinition = {
      id: payload.id || sender,
      name: payload.name,
      type: payload.type,
      capabilities: payload.capabilities || [],
      status: 'active',
      metadata: payload.metadata || {}
    };
    
    // Register the agent
    this.registerAgent(agentDef);
    
    // Send acknowledgment
    this.sharedMemoryBus.respond(message, 'meta-controller', {
      success: true,
      message: `Agent ${agentDef.name} registered successfully`
    });
  }

  /**
   * Handles agent status update messages
   */
  private handleAgentStatusUpdate(message: Message): void {
    const { sender, payload } = message;
    
    // Update agent status
    const agent = this.agents.get(sender);
    if (agent) {
      agent.status = payload.status;
      this.agents.set(sender, agent);
      
      this.emit('agentStatusUpdated', agent);
    }
  }

  /**
   * Handles workflow execution requests
   */
  private handleWorkflowExecutionRequest(message: Message): void {
    const { sender, payload } = message;
    
    // Get the workflow
    const workflow = this.workflows.get(payload.workflowId);
    if (!workflow) {
      this.sharedMemoryBus.respond(message, 'meta-controller', null, {
        error: `Workflow ${payload.workflowId} not found`
      });
      return;
    }
    
    // Execute the workflow
    this.executeWorkflow(workflow.id, payload.inputs || {})
      .then(execution => {
        this.sharedMemoryBus.respond(message, 'meta-controller', {
          success: true,
          executionId: execution.id
        });
      })
      .catch(error => {
        this.sharedMemoryBus.respond(message, 'meta-controller', null, {
          error: `Failed to execute workflow: ${error.message}`
        });
      });
  }

  /**
   * Handles cognitive state transitions
   */
  private handleCognitiveStateTransition(
    oldState: CognitiveState,
    newState: CognitiveState,
    context: any
  ): void {
    // Check for self-improvement triggers
    if (newState === CognitiveState.EVALUATE) {
      this.checkSelfImprovementTriggers(context);
    }
  }

  /**
   * Checks if self-improvement should be triggered
   */
  private checkSelfImprovementTriggers(context: any): void {
    // This is a simplified implementation
    // In a real system, this would use more sophisticated criteria
    
    // Check for recurring errors
    const errorCount = context.evaluations.filter((e: any) => e.metrics?.errorCount > 0).length;
    if (errorCount >= 3) {
      this.triggerSelfImprovement('recurring_errors', context);
      return;
    }
    
    // Check for performance degradation
    const latestEval = context.evaluations[context.evaluations.length - 1];
    if (latestEval?.metrics?.executionTime > 5000) {
      this.triggerSelfImprovement('performance_degradation', context);
      return;
    }
  }

  /**
   * Triggers self-improvement
   */
  private triggerSelfImprovement(reason: string, context: any): void {
    // Log the trigger
    this.executionJournal.logInfo(
      context.taskId,
      `Self-improvement triggered: ${reason}`,
      { reason, context }
    );
    
    // Broadcast event
    this.sharedMemoryBus.broadcast(
      'meta-controller',
      'system:self-improvement',
      {
        reason,
        taskId: context.taskId,
        timestamp: Date.now()
      }
    );
    
    this.emit('selfImprovementTriggered', { reason, context });
  }

  /**
   * Registers an agent
   */
  public registerAgent(agent: AgentDefinition): void {
    this.agents.set(agent.id, agent);
    
    // Log the registration
    this.executionJournal.logInfo(
      'system',
      `Agent registered: ${agent.name} (${agent.type})`,
      { agent }
    );
    
    this.emit('agentRegistered', agent);
  }

  /**
   * Unregisters an agent
   */
  public unregisterAgent(agentId: string): boolean {
    const agent = this.agents.get(agentId);
    if (!agent) {
      return false;
    }
    
    const removed = this.agents.delete(agentId);
    
    if (removed) {
      // Log the unregistration
      this.executionJournal.logInfo(
        'system',
        `Agent unregistered: ${agent.name} (${agent.type})`,
        { agent }
      );
      
      this.emit('agentUnregistered', agent);
    }
    
    return removed;
  }

  /**
   * Registers a workflow
   */
  public registerWorkflow(workflow: WorkflowDefinition): void {
    this.workflows.set(workflow.id, workflow);
    
    // Log the registration
    this.executionJournal.logInfo(
      'system',
      `Workflow registered: ${workflow.name}`,
      { workflow }
    );
    
    this.emit('workflowRegistered', workflow);
  }

  /**
   * Unregisters a workflow
   */
  public unregisterWorkflow(workflowId: string): boolean {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return false;
    }
    
    const removed = this.workflows.delete(workflowId);
    
    if (removed) {
      // Log the unregistration
      this.executionJournal.logInfo(
        'system',
        `Workflow unregistered: ${workflow.name}`,
        { workflow }
      );
      
      this.emit('workflowUnregistered', workflow);
    }
    
    return removed;
  }

  /**
   * Executes a workflow
   */
  public async executeWorkflow(
    workflowId: string,
    inputs: Record<string, any> = {}
  ): Promise<WorkflowExecution> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      throw new Error(`Workflow ${workflowId} not found`);
    }
    
    // Create execution
    const execution: WorkflowExecution = {
      id: uuidv4(),
      workflowId,
      status: 'pending',
      startTime: Date.now(),
      stepResults: workflow.steps.map(step => ({
        stepId: step.id,
        agentId: '',
        status: 'pending'
      })),
      variables: { ...inputs },
      metadata: {}
    };
    
    // Store execution
    this.executions.set(execution.id, execution);
    
    // Log the execution start
    this.executionJournal.logInfo(
      'system',
      `Workflow execution started: ${workflow.name}`,
      { workflow, execution }
    );
    
    this.emit('workflowExecutionStarted', execution);
    
    // Start execution
    execution.status = 'running';
    
    try {
      // Execute steps
      await this.executeWorkflowSteps(execution);
      
      // Mark as completed
      execution.status = 'completed';
      execution.endTime = Date.now();
      
      // Log the execution completion
      this.executionJournal.logInfo(
        'system',
        `Workflow execution completed: ${workflow.name}`,
        { workflow, execution }
      );
      
      this.emit('workflowExecutionCompleted', execution);
    } catch (error) {
      // Mark as failed
      execution.status = 'failed';
      execution.endTime = Date.now();
      execution.metadata.error = error;
      
      // Log the execution failure
      this.executionJournal.logError(
        'system',
        error
      );
      
      this.emit('workflowExecutionFailed', execution, error);
    }
    
    // Update execution
    this.executions.set(execution.id, execution);
    
    return execution;
  }

  /**
   * Executes workflow steps
   */
  private async executeWorkflowSteps(execution: WorkflowExecution): Promise<void> {
    const workflow = this.workflows.get(execution.workflowId);
    if (!workflow) {
      throw new Error(`Workflow ${execution.workflowId} not found`);
    }
    
    // Get steps with dependencies resolved
    const steps = this.sortStepsByDependencies(workflow.steps);
    
    // Execute steps in order
    for (const step of steps) {
      // Check if dependencies are satisfied
      const dependencies = step.dependencies || [];
      const dependenciesSatisfied = dependencies.every(depId => {
        const depResult = execution.stepResults.find(r => r.stepId === depId);
        return depResult && depResult.status === 'completed';
      });
      
      if (!dependenciesSatisfied) {
        // Skip this step
        const stepResult = execution.stepResults.find(r => r.stepId === step.id);
        if (stepResult) {
          stepResult.status = 'skipped';
        }
        continue;
      }
      
      // Find an agent of the required type
      const agent = this.findAvailableAgent(step.agentType);
      if (!agent) {
        throw new Error(`No available agent of type ${step.agentType}`);
      }
      
      // Update step result
      const stepResult = execution.stepResults.find(r => r.stepId === step.id);
      if (stepResult) {
        stepResult.agentId = agent.id;
        stepResult.status = 'running';
        stepResult.startTime = Date.now();
      }
      
      try {
        // Prepare inputs
        const stepInputs = this.prepareStepInputs(step, execution);
        
        // Execute step
        const result = await this.executeStep(agent, step, stepInputs);
        
        // Update variables with outputs
        for (const outputVar of step.outputs) {
          execution.variables[outputVar] = result[outputVar];
        }
        
        // Update step result
        if (stepResult) {
          stepResult.status = 'completed';
          stepResult.endTime = Date.now();
          stepResult.result = result;
        }
      } catch (error) {
        // Update step result
        if (stepResult) {
          stepResult.status = 'failed';
          stepResult.endTime = Date.now();
          stepResult.error = error;
        }
        
        throw error;
      }
    }
  }

  /**
   * Sorts steps by dependencies
   */
  private sortStepsByDependencies(steps: any[]): any[] {
    // This is a simplified topological sort
    const result: any[] = [];
    const visited = new Set<string>();
    const temp = new Set<string>();
    
    const visit = (step: any) => {
      if (temp.has(step.id)) {
        throw new Error(`Circular dependency detected in workflow steps`);
      }
      
      if (visited.has(step.id)) {
        return;
      }
      
      temp.add(step.id);
      
      const dependencies = step.dependencies || [];
      for (const depId of dependencies) {
        const depStep = steps.find(s => s.id === depId);
        if (depStep) {
          visit(depStep);
        }
      }
      
      temp.delete(step.id);
      visited.add(step.id);
      result.push(step);
    };
    
    for (const step of steps) {
      if (!visited.has(step.id)) {
        visit(step);
      }
    }
    
    return result;
  }

  /**
   * Finds an available agent of a specific type
   */
  private findAvailableAgent(agentType: string): AgentDefinition | null {
    for (const agent of this.agents.values()) {
      if (agent.type === agentType && agent.status === 'active') {
        return agent;
      }
    }
    
    return null;
  }

  /**
   * Prepares inputs for a workflow step
   */
  private prepareStepInputs(step: any, execution: WorkflowExecution): any {
    const inputs: any = {};
    
    // Copy specified inputs from step definition
    for (const [key, value] of Object.entries(step.inputs)) {
      if (typeof value === 'string' && value.startsWith('$')) {
        // Variable reference
        const varName = value.substring(1);
        inputs[key] = execution.variables[varName];
      } else {
        // Literal value
        inputs[key] = value;
      }
    }
    
    return inputs;
  }

  /**
   * Executes a workflow step
   */
  private async executeStep(
    agent: AgentDefinition,
    step: any,
    inputs: any
  ): Promise<any> {
    // Send request to agent
    const response = await this.sharedMemoryBus.request(
      'meta-controller',
      agent.id,
      `agent:execute`,
      {
        action: step.action,
        inputs
      },
      step.timeout || 30000
    );
    
    return response.payload;
  }

  /**
   * Gets all registered agents
   */
  public getAgents(): AgentDefinition[] {
    return Array.from(this.agents.values());
  }

  /**
   * Gets an agent by ID
   */
  public getAgent(agentId: string): AgentDefinition | undefined {
    return this.agents.get(agentId);
  }

  /**
   * Gets all registered workflows
   */
  public getWorkflows(): WorkflowDefinition[] {
    return Array.from(this.workflows.values());
  }

  /**
   * Gets a workflow by ID
   */
  public getWorkflow(workflowId: string): WorkflowDefinition | undefined {
    return this.workflows.get(workflowId);
  }

  /**
   * Gets all workflow executions
   */
  public getExecutions(): WorkflowExecution[] {
    return Array.from(this.executions.values());
  }

  /**
   * Gets a workflow execution by ID
   */
  public getExecution(executionId: string): WorkflowExecution | undefined {
    return this.executions.get(executionId);
  }

  /**
   * Gets executions for a workflow
   */
  public getWorkflowExecutions(workflowId: string): WorkflowExecution[] {
    return this.getExecutions().filter(exec => exec.workflowId === workflowId);
  }

  /**
   * Aborts a workflow execution
   */
  public abortExecution(executionId: string): boolean {
    const execution = this.executions.get(executionId);
    if (!execution || execution.status !== 'running') {
      return false;
    }
    
    execution.status = 'aborted';
    execution.endTime = Date.now();
    
    this.executions.set(executionId, execution);
    
    // Log the abortion
    this.executionJournal.logInfo(
      'system',
      `Workflow execution aborted: ${executionId}`,
      { execution }
    );
    
    this.emit('workflowExecutionAborted', execution);
    
    return true;
  }
}

export default MetaControllerAgent;
