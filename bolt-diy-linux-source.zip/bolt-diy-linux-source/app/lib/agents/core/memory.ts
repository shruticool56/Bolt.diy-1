/**
 * Memory System Implementation for Autonomous Cognition Core
 * 
 * Provides short-term, long-term, and episodic memory capabilities for agents.
 */

import { MemoryItem, MemoryItemType } from './types';

/**
 * Memory System for the Autonomous Cognition Core
 * 
 * Manages different types of memory (short-term, long-term, episodic) with
 * efficient storage, retrieval, and forgetting mechanisms.
 */
class MemorySystem {
  private static instance: MemorySystem;
  private shortTermMemory: Map<string, MemoryItem> = new Map();
  private longTermMemory: Map<string, MemoryItem> = new Map();
  private episodicMemory: Map<string, MemoryItem[]> = new Map();
  
  // Memory configuration
  private readonly SHORT_TERM_CLEANUP_INTERVAL = 60000; // 1 minute
  private readonly MAX_SHORT_TERM_ITEMS = 1000;
  private readonly MAX_LONG_TERM_ITEMS = 10000;
  private readonly MAX_EPISODIC_SEQUENCES = 100;
  private readonly MAX_EPISODIC_ITEMS_PER_SEQUENCE = 1000;

  private constructor() {
    // Start periodic cleanup of short-term memory
    setInterval(() => this.cleanupShortTermMemory(), this.SHORT_TERM_CLEANUP_INTERVAL);
  }

  /**
   * Get the singleton instance of the memory system
   */
  public static getInstance(): MemorySystem {
    if (!MemorySystem.instance) {
      MemorySystem.instance = new MemorySystem();
    }
    return MemorySystem.instance;
  }

  /**
   * Store an item in short-term memory
   * 
   * @param item The memory item to store
   * @returns The ID of the stored item
   */
  public storeShortTerm(item: Omit<MemoryItem, 'id'>): string {
    const id = `stm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const memoryItem: MemoryItem = {
      ...item,
      id,
      expiresAt: item.expiresAt || Date.now() + 3600000 // Default 1 hour expiry
    };
    
    this.shortTermMemory.set(id, memoryItem);
    
    // Enforce maximum size by removing oldest items
    if (this.shortTermMemory.size > this.MAX_SHORT_TERM_ITEMS) {
      const oldestKey = Array.from(this.shortTermMemory.keys())[0];
      this.shortTermMemory.delete(oldestKey);
    }
    
    return id;
  }

  /**
   * Store an item in long-term memory
   * 
   * @param item The memory item to store
   * @returns The ID of the stored item
   */
  public storeLongTerm(item: Omit<MemoryItem, 'id'>): string {
    const id = `ltm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const memoryItem: MemoryItem = {
      ...item,
      id
    };
    
    this.longTermMemory.set(id, memoryItem);
    
    // Enforce maximum size by removing least important items
    if (this.longTermMemory.size > this.MAX_LONG_TERM_ITEMS) {
      let leastImportantKey = '';
      let leastImportance = Infinity;
      
      for (const [key, value] of this.longTermMemory.entries()) {
        if (value.importance < leastImportance) {
          leastImportance = value.importance;
          leastImportantKey = key;
        }
      }
      
      if (leastImportantKey) {
        this.longTermMemory.delete(leastImportantKey);
      }
    }
    
    return id;
  }

  /**
   * Store an item in episodic memory
   * 
   * @param sequenceId The ID of the episode sequence
   * @param item The memory item to store
   * @returns The ID of the stored item
   */
  public storeEpisodic(sequenceId: string, item: Omit<MemoryItem, 'id'>): string {
    const id = `epm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const memoryItem: MemoryItem = {
      ...item,
      id
    };
    
    // Create sequence if it doesn't exist
    if (!this.episodicMemory.has(sequenceId)) {
      this.episodicMemory.set(sequenceId, []);
      
      // Enforce maximum number of sequences
      if (this.episodicMemory.size > this.MAX_EPISODIC_SEQUENCES) {
        const oldestKey = Array.from(this.episodicMemory.keys())[0];
        this.episodicMemory.delete(oldestKey);
      }
    }
    
    // Add item to sequence
    const sequence = this.episodicMemory.get(sequenceId)!;
    sequence.push(memoryItem);
    
    // Enforce maximum items per sequence
    if (sequence.length > this.MAX_EPISODIC_ITEMS_PER_SEQUENCE) {
      sequence.shift(); // Remove oldest item
    }
    
    return id;
  }

  /**
   * Retrieve an item from any memory store by ID
   * 
   * @param id The ID of the memory item
   * @returns The memory item or null if not found
   */
  public retrieveById(id: string): MemoryItem | null {
    // Check short-term memory
    if (this.shortTermMemory.has(id)) {
      const item = this.shortTermMemory.get(id)!;
      
      // Check if expired
      if (item.expiresAt && item.expiresAt < Date.now()) {
        this.shortTermMemory.delete(id);
        return null;
      }
      
      return item;
    }
    
    // Check long-term memory
    if (this.longTermMemory.has(id)) {
      return this.longTermMemory.get(id)!;
    }
    
    // Check episodic memory (less efficient)
    for (const sequence of this.episodicMemory.values()) {
      const item = sequence.find(item => item.id === id);
      if (item) {
        return item;
      }
    }
    
    return null;
  }

  /**
   * Search memory by tags
   * 
   * @param tags Array of tags to search for (AND logic)
   * @param options Search options
   * @returns Array of matching memory items
   */
  public searchByTags(
    tags: string[],
    options: {
      memoryTypes?: MemoryItemType[];
      limit?: number;
      minImportance?: number;
    } = {}
  ): MemoryItem[] {
    const results: MemoryItem[] = [];
    const { memoryTypes, limit = 100, minImportance = 0 } = options;
    
    // Helper function to check if an item matches the search criteria
    const matchesCriteria = (item: MemoryItem): boolean => {
      // Check memory type filter
      if (memoryTypes && !memoryTypes.includes(item.type)) {
        return false;
      }
      
      // Check importance filter
      if (item.importance < minImportance) {
        return false;
      }
      
      // Check if all tags are present
      return tags.every(tag => item.tags.includes(tag));
    };
    
    // Search short-term memory
    for (const item of this.shortTermMemory.values()) {
      // Skip expired items
      if (item.expiresAt && item.expiresAt < Date.now()) {
        continue;
      }
      
      if (matchesCriteria(item)) {
        results.push(item);
        if (results.length >= limit) {
          return results;
        }
      }
    }
    
    // Search long-term memory
    for (const item of this.longTermMemory.values()) {
      if (matchesCriteria(item)) {
        results.push(item);
        if (results.length >= limit) {
          return results;
        }
      }
    }
    
    // Search episodic memory
    for (const sequence of this.episodicMemory.values()) {
      for (const item of sequence) {
        if (matchesCriteria(item)) {
          results.push(item);
          if (results.length >= limit) {
            return results;
          }
        }
      }
    }
    
    return results;
  }

  /**
   * Search memory by content
   * 
   * @param query Search query string or regular expression
   * @param options Search options
   * @returns Array of matching memory items
   */
  public searchByContent(
    query: string | RegExp,
    options: {
      memoryTypes?: MemoryItemType[];
      limit?: number;
      minImportance?: number;
    } = {}
  ): MemoryItem[] {
    const results: MemoryItem[] = [];
    const { memoryTypes, limit = 100, minImportance = 0 } = options;
    const regex = typeof query === 'string' ? new RegExp(query, 'i') : query;
    
    // Helper function to check if an item matches the search criteria
    const matchesCriteria = (item: MemoryItem): boolean => {
      // Check memory type filter
      if (memoryTypes && !memoryTypes.includes(item.type)) {
        return false;
      }
      
      // Check importance filter
      if (item.importance < minImportance) {
        return false;
      }
      
      // Check content match
      const contentStr = typeof item.content === 'string'
        ? item.content
        : JSON.stringify(item.content);
      
      return regex.test(contentStr);
    };
    
    // Search all memory stores
    for (const item of this.shortTermMemory.values()) {
      // Skip expired items
      if (item.expiresAt && item.expiresAt < Date.now()) {
        continue;
      }
      
      if (matchesCriteria(item)) {
        results.push(item);
        if (results.length >= limit) {
          return results;
        }
      }
    }
    
    for (const item of this.longTermMemory.values()) {
      if (matchesCriteria(item)) {
        results.push(item);
        if (results.length >= limit) {
          return results;
        }
      }
    }
    
    for (const sequence of this.episodicMemory.values()) {
      for (const item of sequence) {
        if (matchesCriteria(item)) {
          results.push(item);
          if (results.length >= limit) {
            return results;
          }
        }
      }
    }
    
    return results;
  }

  /**
   * Get an entire episodic memory sequence
   * 
   * @param sequenceId The ID of the episode sequence
   * @returns Array of memory items in the sequence or empty array if not found
   */
  public getEpisodicSequence(sequenceId: string): MemoryItem[] {
    return this.episodicMemory.get(sequenceId) || [];
  }

  /**
   * Remove an item from memory
   * 
   * @param id The ID of the memory item to remove
   * @returns true if the item was found and removed, false otherwise
   */
  public removeItem(id: string): boolean {
    // Try to remove from short-term memory
    if (this.shortTermMemory.delete(id)) {
      return true;
    }
    
    // Try to remove from long-term memory
    if (this.longTermMemory.delete(id)) {
      return true;
    }
    
    // Try to remove from episodic memory
    for (const [sequenceId, sequence] of this.episodicMemory.entries()) {
      const index = sequence.findIndex(item => item.id === id);
      if (index !== -1) {
        sequence.splice(index, 1);
        
        // Remove empty sequences
        if (sequence.length === 0) {
          this.episodicMemory.delete(sequenceId);
        }
        
        return true;
      }
    }
    
    return false;
  }

  /**
   * Clean up expired items from short-term memory
   */
  private cleanupShortTermMemory(): void {
    const now = Date.now();
    
    for (const [id, item] of this.shortTermMemory.entries()) {
      if (item.expiresAt && item.expiresAt < now) {
        this.shortTermMemory.delete(id);
      }
    }
  }
}

export const memorySystem = MemorySystem.getInstance();
