/**
 * Goal Decomposer Implementation for Autonomous Cognition Core
 * 
 * Breaks complex tasks into manageable subgoals with hierarchical structure.
 */

import { Goal, GoalPriority, GoalStatus } from './types';
import { memorySystem } from './memory';

/**
 * Goal Decomposer for the Autonomous Cognition Core
 * 
 * Responsible for breaking down complex goals into manageable subgoals,
 * managing goal hierarchies, and tracking goal dependencies.
 */
class GoalDecomposer {
  private static instance: GoalDecomposer;
  private goals: Map<string, Goal> = new Map();
  
  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the goal decomposer
   */
  public static getInstance(): GoalDecomposer {
    if (!GoalDecomposer.instance) {
      GoalDecomposer.instance = new GoalDecomposer();
    }
    return GoalDecomposer.instance;
  }

  /**
   * Create a new top-level goal
   * 
   * @param description Description of the goal
   * @param priority Priority level of the goal
   * @param metadata Additional metadata for the goal
   * @returns The created goal object
   */
  public createGoal(
    description: string,
    priority: GoalPriority = GoalPriority.MEDIUM,
    metadata: Record<string, any> = {}
  ): Goal {
    const now = Date.now();
    const goal: Goal = {
      id: `goal_${now}_${Math.random().toString(36).substr(2, 9)}`,
      description,
      priority,
      status: GoalStatus.PENDING,
      subGoals: [],
      createdAt: now,
      updatedAt: now,
      metadata
    };
    
    this.goals.set(goal.id, goal);
    
    // Store in memory system for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'goal_created',
        goal: { ...goal, subGoals: [] } // Avoid circular references
      },
      tags: ['goal', 'created', goal.id],
      importance: this.getPriorityImportance(priority),
      createdAt: now,
      metadata: {}
    });
    
    return goal;
  }

  /**
   * Add a subgoal to an existing goal
   * 
   * @param parentGoalId ID of the parent goal
   * @param description Description of the subgoal
   * @param priority Priority level of the subgoal (defaults to parent's priority)
   * @param metadata Additional metadata for the subgoal
   * @returns The created subgoal or null if parent not found
   */
  public addSubGoal(
    parentGoalId: string,
    description: string,
    priority?: GoalPriority,
    metadata: Record<string, any> = {}
  ): Goal | null {
    const parentGoal = this.goals.get(parentGoalId);
    if (!parentGoal) {
      return null;
    }
    
    const now = Date.now();
    const subGoal: Goal = {
      id: `goal_${now}_${Math.random().toString(36).substr(2, 9)}`,
      description,
      priority: priority || parentGoal.priority,
      status: GoalStatus.PENDING,
      parentGoalId,
      subGoals: [],
      createdAt: now,
      updatedAt: now,
      metadata
    };
    
    // Add to parent's subgoals
    parentGoal.subGoals.push(subGoal);
    parentGoal.updatedAt = now;
    
    // Store in goals map for direct access
    this.goals.set(subGoal.id, subGoal);
    
    // Store in memory system for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'subgoal_created',
        subGoal: { ...subGoal, subGoals: [] }, // Avoid circular references
        parentGoalId
      },
      tags: ['goal', 'subgoal', 'created', subGoal.id, parentGoalId],
      importance: this.getPriorityImportance(subGoal.priority),
      createdAt: now,
      metadata: {}
    });
    
    return subGoal;
  }

  /**
   * Get a goal by ID
   * 
   * @param goalId ID of the goal to retrieve
   * @returns The goal object or null if not found
   */
  public getGoal(goalId: string): Goal | null {
    return this.goals.get(goalId) || null;
  }

  /**
   * Get all top-level goals
   * 
   * @returns Array of top-level goals
   */
  public getTopLevelGoals(): Goal[] {
    return Array.from(this.goals.values())
      .filter(goal => !goal.parentGoalId);
  }

  /**
   * Get all subgoals for a specific goal
   * 
   * @param goalId ID of the parent goal
   * @returns Array of subgoals or empty array if parent not found
   */
  public getSubGoals(goalId: string): Goal[] {
    const goal = this.goals.get(goalId);
    return goal ? goal.subGoals : [];
  }

  /**
   * Update the status of a goal
   * 
   * @param goalId ID of the goal to update
   * @param status New status for the goal
   * @returns Updated goal or null if not found
   */
  public updateGoalStatus(goalId: string, status: GoalStatus): Goal | null {
    const goal = this.goals.get(goalId);
    if (!goal) {
      return null;
    }
    
    const now = Date.now();
    const oldStatus = goal.status;
    goal.status = status;
    goal.updatedAt = now;
    
    // Update completedAt timestamp if completed
    if (status === GoalStatus.COMPLETED && !goal.completedAt) {
      goal.completedAt = now;
    }
    
    // Store in memory system for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'goal_status_updated',
        goalId,
        oldStatus,
        newStatus: status
      },
      tags: ['goal', 'status', 'updated', goalId],
      importance: this.getPriorityImportance(goal.priority),
      createdAt: now,
      metadata: {}
    });
    
    // Check if all subgoals are completed to auto-complete parent
    this.checkParentGoalCompletion(goal);
    
    return goal;
  }

  /**
   * Update goal metadata
   * 
   * @param goalId ID of the goal to update
   * @param metadata Metadata to merge with existing metadata
   * @returns Updated goal or null if not found
   */
  public updateGoalMetadata(
    goalId: string,
    metadata: Record<string, any>
  ): Goal | null {
    const goal = this.goals.get(goalId);
    if (!goal) {
      return null;
    }
    
    goal.metadata = { ...goal.metadata, ...metadata };
    goal.updatedAt = Date.now();
    
    return goal;
  }

  /**
   * Delete a goal and all its subgoals
   * 
   * @param goalId ID of the goal to delete
   * @returns true if goal was found and deleted, false otherwise
   */
  public deleteGoal(goalId: string): boolean {
    const goal = this.goals.get(goalId);
    if (!goal) {
      return false;
    }
    
    // Recursively delete all subgoals
    for (const subGoal of goal.subGoals) {
      this.deleteGoal(subGoal.id);
    }
    
    // Remove from parent's subgoals if it's a subgoal
    if (goal.parentGoalId) {
      const parentGoal = this.goals.get(goal.parentGoalId);
      if (parentGoal) {
        const index = parentGoal.subGoals.findIndex(sg => sg.id === goalId);
        if (index !== -1) {
          parentGoal.subGoals.splice(index, 1);
          parentGoal.updatedAt = Date.now();
        }
      }
    }
    
    // Remove from goals map
    this.goals.delete(goalId);
    
    // Store in memory system for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'goal_deleted',
        goalId
      },
      tags: ['goal', 'deleted', goalId],
      importance: 50, // Medium importance
      createdAt: Date.now(),
      metadata: {}
    });
    
    return true;
  }

  /**
   * Check if all subgoals of a goal are completed and update parent status if needed
   * 
   * @param goal The goal to check
   */
  private checkParentGoalCompletion(goal: Goal): void {
    if (!goal.parentGoalId) {
      return; // Not a subgoal
    }
    
    const parentGoal = this.goals.get(goal.parentGoalId);
    if (!parentGoal) {
      return; // Parent not found
    }
    
    // Check if all subgoals are completed
    const allCompleted = parentGoal.subGoals.every(
      sg => sg.status === GoalStatus.COMPLETED
    );
    
    if (allCompleted && parentGoal.status !== GoalStatus.COMPLETED) {
      this.updateGoalStatus(parentGoal.id, GoalStatus.COMPLETED);
    }
  }

  /**
   * Convert priority to numeric importance value
   * 
   * @param priority Goal priority
   * @returns Numeric importance value (0-100)
   */
  private getPriorityImportance(priority: GoalPriority): number {
    switch (priority) {
      case GoalPriority.LOW:
        return 25;
      case GoalPriority.MEDIUM:
        return 50;
      case GoalPriority.HIGH:
        return 75;
      case GoalPriority.CRITICAL:
        return 100;
      default:
        return 50;
    }
  }
}

export const goalDecomposer = GoalDecomposer.getInstance();
