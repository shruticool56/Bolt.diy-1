/**
 * SentienceAI Cognitive Kernel - Context Stitching Engine
 * 
 * This module implements the Context Stitching Engine:
 * - Links logs, code traces, and user input
 * - Provides accurate context for code decisions
 * - Enables coherent reasoning across different data sources
 */

import { EventEmitter } from 'events';
import { ExecutionJournal, JournalEntry, JournalEntryType } from '../execution-journal';
import { MemoryManager, MemoryType } from '../memory';

export interface ContextFragment {
  id: string;
  source: string;
  content: any;
  timestamp: number;
  metadata: any;
  relevanceScore?: number;
}

export interface StitchedContext {
  id: string;
  taskId: string;
  timestamp: number;
  fragments: ContextFragment[];
  summary: string;
  metadata: any;
}

export class ContextStitchingEngine extends EventEmitter {
  private executionJournal: ExecutionJournal;
  private memoryManager: MemoryManager;
  private contextCache: Map<string, StitchedContext> = new Map();
  
  constructor(executionJournal?: ExecutionJournal, memoryManager?: MemoryManager) {
    super();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.memoryManager = memoryManager || new MemoryManager();
  }

  /**
   * Stitches context from various sources for a specific task
   */
  public async stitchContext(
    taskId: string,
    options: {
      includeJournal?: boolean;
      includeMemory?: boolean;
      includeUserInput?: boolean;
      includeCodeTraces?: boolean;
      maxFragments?: number;
      recency?: number; // Time window in milliseconds
    } = {}
  ): Promise<StitchedContext> {
    const {
      includeJournal = true,
      includeMemory = true,
      includeUserInput = true,
      includeCodeTraces = true,
      maxFragments = 50,
      recency = 3600000 // Default to last hour
    } = options;
    
    // Collect fragments from different sources
    const fragments: ContextFragment[] = [];
    
    // Get journal entries if requested
    if (includeJournal) {
      const journalFragments = await this.getJournalFragments(taskId, recency);
      fragments.push(...journalFragments);
    }
    
    // Get memory records if requested
    if (includeMemory) {
      const memoryFragments = await this.getMemoryFragments(taskId, recency);
      fragments.push(...memoryFragments);
    }
    
    // Get user input if requested
    if (includeUserInput) {
      const userInputFragments = await this.getUserInputFragments(taskId, recency);
      fragments.push(...userInputFragments);
    }
    
    // Get code traces if requested
    if (includeCodeTraces) {
      const codeTraceFragments = await this.getCodeTraceFragments(taskId, recency);
      fragments.push(...codeTraceFragments);
    }
    
    // Sort fragments by relevance and recency
    const scoredFragments = this.scoreAndSortFragments(fragments);
    
    // Limit to max fragments
    const selectedFragments = scoredFragments.slice(0, maxFragments);
    
    // Generate a summary
    const summary = await this.generateContextSummary(selectedFragments);
    
    // Create the stitched context
    const stitchedContext: StitchedContext = {
      id: `context_${taskId}_${Date.now()}`,
      taskId,
      timestamp: Date.now(),
      fragments: selectedFragments,
      summary,
      metadata: {
        fragmentCount: selectedFragments.length,
        sources: this.getSourceCounts(selectedFragments)
      }
    };
    
    // Cache the context
    this.contextCache.set(stitchedContext.id, stitchedContext);
    
    this.emit('contextStitched', stitchedContext);
    return stitchedContext;
  }

  /**
   * Gets fragments from the execution journal
   */
  private async getJournalFragments(
    taskId: string,
    recency: number
  ): Promise<ContextFragment[]> {
    const entries = this.executionJournal.getTaskEntries(taskId);
    const recentTime = Date.now() - recency;
    
    return entries
      .filter(entry => entry.timestamp >= recentTime)
      .map(entry => this.journalEntryToFragment(entry));
  }

  /**
   * Converts a journal entry to a context fragment
   */
  private journalEntryToFragment(entry: JournalEntry): ContextFragment {
    return {
      id: entry.id,
      source: 'journal',
      content: entry.data,
      timestamp: entry.timestamp,
      metadata: {
        type: entry.type,
        ...entry.metadata
      }
    };
  }

  /**
   * Gets fragments from memory
   */
  private async getMemoryFragments(
    taskId: string,
    recency: number
  ): Promise<ContextFragment[]> {
    const memories = await this.memoryManager.queryMemory({
      metadata: { taskId },
      unexpiredOnly: true
    });
    
    const recentTime = Date.now() - recency;
    
    return memories
      .filter(memory => memory.timestamp >= recentTime)
      .map(memory => ({
        id: memory.id,
        source: 'memory',
        content: memory.value,
        timestamp: memory.timestamp,
        metadata: {
          type: memory.type,
          key: memory.key,
          ...memory.metadata
        }
      }));
  }

  /**
   * Gets user input fragments
   */
  private async getUserInputFragments(
    taskId: string,
    recency: number
  ): Promise<ContextFragment[]> {
    // In a real implementation, this would retrieve user inputs from a dedicated store
    // For now, we'll use journal entries of type INFO that contain user input
    const entries = this.executionJournal.getTaskEntriesByType(
      taskId,
      JournalEntryType.INFO
    );
    
    const recentTime = Date.now() - recency;
    
    return entries
      .filter(entry => 
        entry.timestamp >= recentTime && 
        entry.data && 
        entry.data.message && 
        entry.data.message.startsWith('User input:')
      )
      .map(entry => ({
        id: entry.id,
        source: 'user_input',
        content: entry.data.message.substring('User input:'.length).trim(),
        timestamp: entry.timestamp,
        metadata: {
          ...entry.metadata
        }
      }));
  }

  /**
   * Gets code trace fragments
   */
  private async getCodeTraceFragments(
    taskId: string,
    recency: number
  ): Promise<ContextFragment[]> {
    // In a real implementation, this would retrieve code traces from a dedicated store
    // For now, we'll use journal entries of type INFO that contain code traces
    const entries = this.executionJournal.getTaskEntriesByType(
      taskId,
      JournalEntryType.INFO
    );
    
    const recentTime = Date.now() - recency;
    
    return entries
      .filter(entry => 
        entry.timestamp >= recentTime && 
        entry.data && 
        entry.data.message && 
        entry.data.message.startsWith('Code trace:')
      )
      .map(entry => ({
        id: entry.id,
        source: 'code_trace',
        content: entry.data.message.substring('Code trace:'.length).trim(),
        timestamp: entry.timestamp,
        metadata: {
          ...entry.metadata
        }
      }));
  }

  /**
   * Scores and sorts fragments by relevance and recency
   */
  private scoreAndSortFragments(fragments: ContextFragment[]): ContextFragment[] {
    // Calculate a relevance score for each fragment
    // This is a simplified scoring algorithm
    const now = Date.now();
    const scoredFragments = fragments.map(fragment => {
      // Recency score: 0-1 based on how recent the fragment is (within the last hour)
      const recencyScore = Math.max(0, Math.min(1, 1 - (now - fragment.timestamp) / 3600000));
      
      // Source score: different weights for different sources
      let sourceScore = 0;
      switch (fragment.source) {
        case 'user_input':
          sourceScore = 1.0; // Highest priority
          break;
        case 'code_trace':
          sourceScore = 0.9;
          break;
        case 'journal':
          sourceScore = 0.8;
          break;
        case 'memory':
          sourceScore = 0.7;
          break;
        default:
          sourceScore = 0.5;
      }
      
      // Type score: different weights for different entry types
      let typeScore = 0.5;
      if (fragment.metadata && fragment.metadata.type) {
        switch (fragment.metadata.type) {
          case JournalEntryType.ERROR:
            typeScore = 1.0; // Errors are important
            break;
          case JournalEntryType.EVALUATION:
            typeScore = 0.9;
            break;
          case JournalEntryType.MODIFICATION:
            typeScore = 0.9;
            break;
          case JournalEntryType.LEARNING:
            typeScore = 0.8;
            break;
          case JournalEntryType.PLAN:
            typeScore = 0.7;
            break;
          default:
            typeScore = 0.5;
        }
      }
      
      // Combined score
      const relevanceScore = (recencyScore * 0.4) + (sourceScore * 0.4) + (typeScore * 0.2);
      
      return {
        ...fragment,
        relevanceScore
      };
    });
    
    // Sort by relevance score (descending)
    return scoredFragments.sort((a, b) => 
      (b.relevanceScore || 0) - (a.relevanceScore || 0)
    );
  }

  /**
   * Generates a summary of the context
   */
  private async generateContextSummary(fragments: ContextFragment[]): Promise<string> {
    // In a real implementation, this would use an LLM to generate a summary
    // For now, we'll create a simple summary
    
    const sourceCount = this.getSourceCounts(fragments);
    const sourceCountStr = Object.entries(sourceCount)
      .map(([source, count]) => `${source}: ${count}`)
      .join(', ');
    
    return `Context contains ${fragments.length} fragments (${sourceCountStr}).`;
  }

  /**
   * Gets counts of fragments by source
   */
  private getSourceCounts(fragments: ContextFragment[]): Record<string, number> {
    const counts: Record<string, number> = {};
    
    for (const fragment of fragments) {
      const source = fragment.source;
      counts[source] = (counts[source] || 0) + 1;
    }
    
    return counts;
  }

  /**
   * Gets a cached context by ID
   */
  public getCachedContext(contextId: string): StitchedContext | undefined {
    return this.contextCache.get(contextId);
  }

  /**
   * Clears the context cache
   */
  public clearCache(): void {
    this.contextCache.clear();
    this.emit('cacheCleared');
  }
}

export default ContextStitchingEngine;
