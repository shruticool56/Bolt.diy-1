/**
 * SentienceAI Cognitive Kernel - Autonomous Experience Logger
 * 
 * This module implements the Autonomous Experience Logger:
 * - Logs successes/failures, response latencies, execution contexts
 * - Creates task snapshots before and after code changes
 * - Enables comparative evaluation of system performance
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal, TaskSnapshot } from '../execution-journal';

export interface ExperienceRecord {
  id: string;
  timestamp: number;
  type: 'success' | 'failure' | 'latency' | 'context' | 'snapshot';
  taskId: string;
  data: any;
  metadata: any;
}

export interface TaskComparison {
  id: string;
  timestamp: number;
  beforeSnapshotId: string;
  afterSnapshotId: string;
  metrics: {
    executionTimeChange: number;
    memoryUsageChange: number;
    successRateChange: number;
    errorCountChange: number;
    [key: string]: any;
  };
  analysis: string;
}

export class AutonomousExperienceLogger extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private experiences: Map<string, ExperienceRecord[]> = new Map();
  private comparisons: Map<string, TaskComparison[]> = new Map();
  
  constructor(memoryManager?: MemoryManager, executionJournal?: ExecutionJournal) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    
    // Set up event listeners for automatic logging
    this.setupEventListeners();
  }

  /**
   * Sets up event listeners for automatic logging
   */
  private setupEventListeners(): void {
    // Listen for task completion events
    this.executionJournal.on('entryCreated', async (entry) => {
      if (entry.type === 'task_completion') {
        await this.logSuccess(entry.taskId, entry.data);
      } else if (entry.type === 'error') {
        await this.logFailure(entry.taskId, entry.data);
      }
    });
    
    // Listen for snapshot creation events
    this.executionJournal.on('snapshotCreated', async (snapshot) => {
      await this.logSnapshot(snapshot.taskId, snapshot);
    });
  }

  /**
   * Logs a success experience
   */
  public async logSuccess(taskId: string, data: any): Promise<ExperienceRecord> {
    return this.createExperienceRecord('success', taskId, data);
  }

  /**
   * Logs a failure experience
   */
  public async logFailure(taskId: string, data: any): Promise<ExperienceRecord> {
    return this.createExperienceRecord('failure', taskId, data);
  }

  /**
   * Logs a latency experience
   */
  public async logLatency(taskId: string, operationName: string, durationMs: number): Promise<ExperienceRecord> {
    return this.createExperienceRecord('latency', taskId, {
      operationName,
      durationMs
    });
  }

  /**
   * Logs an execution context
   */
  public async logContext(taskId: string, context: any): Promise<ExperienceRecord> {
    return this.createExperienceRecord('context', taskId, context);
  }

  /**
   * Logs a task snapshot
   */
  public async logSnapshot(taskId: string, snapshot: TaskSnapshot): Promise<ExperienceRecord> {
    return this.createExperienceRecord('snapshot', taskId, snapshot);
  }

  /**
   * Creates and stores an experience record
   */
  private async createExperienceRecord(
    type: 'success' | 'failure' | 'latency' | 'context' | 'snapshot',
    taskId: string,
    data: any,
    metadata: any = {}
  ): Promise<ExperienceRecord> {
    const record: ExperienceRecord = {
      id: uuidv4(),
      timestamp: Date.now(),
      type,
      taskId,
      data,
      metadata: {
        ...metadata,
        recordType: type
      }
    };
    
    // Store in memory
    if (!this.experiences.has(taskId)) {
      this.experiences.set(taskId, []);
    }
    this.experiences.get(taskId)!.push(record);
    
    // Persist to storage
    await this.persistExperienceRecord(record);
    
    this.emit('experienceLogged', record);
    return record;
  }

  /**
   * Persists an experience record to storage
   */
  private async persistExperienceRecord(record: ExperienceRecord): Promise<void> {
    await this.memoryManager.storeMemory({
      id: record.id,
      type: MemoryType.LONG_TERM,
      key: `experience:${record.taskId}:${record.type}:${record.id}`,
      value: record,
      metadata: {
        experienceType: record.type,
        taskId: record.taskId,
        ...record.metadata
      },
      timestamp: record.timestamp
    });
  }

  /**
   * Creates a task snapshot before a code change
   */
  public async createBeforeSnapshot(taskId: string, context: any): Promise<TaskSnapshot> {
    const snapshot = await this.executionJournal.createSnapshot(
      taskId,
      'before_change',
      context
    );
    
    await this.logSnapshot(taskId, snapshot);
    
    this.emit('beforeSnapshotCreated', snapshot);
    return snapshot;
  }

  /**
   * Creates a task snapshot after a code change
   */
  public async createAfterSnapshot(taskId: string, context: any): Promise<TaskSnapshot> {
    const snapshot = await this.executionJournal.createSnapshot(
      taskId,
      'after_change',
      context
    );
    
    await this.logSnapshot(taskId, snapshot);
    
    this.emit('afterSnapshotCreated', snapshot);
    return snapshot;
  }

  /**
   * Compares before and after snapshots to evaluate a change
   */
  public async compareSnapshots(
    beforeSnapshot: TaskSnapshot,
    afterSnapshot: TaskSnapshot
  ): Promise<TaskComparison> {
    // Calculate metric changes
    const metricChanges = {
      executionTimeChange: afterSnapshot.metrics.executionTime - beforeSnapshot.metrics.executionTime,
      memoryUsageChange: afterSnapshot.metrics.memoryUsage - beforeSnapshot.metrics.memoryUsage,
      successRateChange: afterSnapshot.metrics.successRate - beforeSnapshot.metrics.successRate,
      errorCountChange: afterSnapshot.metrics.errorCount - beforeSnapshot.metrics.errorCount
    };
    
    // Generate analysis
    const analysis = this.generateChangeAnalysis(beforeSnapshot, afterSnapshot, metricChanges);
    
    const comparison: TaskComparison = {
      id: uuidv4(),
      timestamp: Date.now(),
      beforeSnapshotId: beforeSnapshot.id,
      afterSnapshotId: afterSnapshot.id,
      metrics: metricChanges,
      analysis
    };
    
    // Store in memory
    if (!this.comparisons.has(beforeSnapshot.taskId)) {
      this.comparisons.set(beforeSnapshot.taskId, []);
    }
    this.comparisons.get(beforeSnapshot.taskId)!.push(comparison);
    
    // Persist to storage
    await this.persistComparison(comparison, beforeSnapshot.taskId);
    
    this.emit('comparisonCreated', comparison);
    return comparison;
  }

  /**
   * Generates an analysis of changes between snapshots
   */
  private generateChangeAnalysis(
    beforeSnapshot: TaskSnapshot,
    afterSnapshot: TaskSnapshot,
    metricChanges: any
  ): string {
    // In a real implementation, this would use more sophisticated analysis
    // For now, generate a simple analysis
    
    const parts: string[] = [];
    
    // Execution time analysis
    if (metricChanges.executionTimeChange < 0) {
      parts.push(`Execution time improved by ${Math.abs(metricChanges.executionTimeChange)}ms.`);
    } else if (metricChanges.executionTimeChange > 0) {
      parts.push(`Execution time increased by ${metricChanges.executionTimeChange}ms.`);
    } else {
      parts.push('Execution time remained unchanged.');
    }
    
    // Memory usage analysis
    if (metricChanges.memoryUsageChange < 0) {
      parts.push(`Memory usage decreased by ${Math.abs(metricChanges.memoryUsageChange)} bytes.`);
    } else if (metricChanges.memoryUsageChange > 0) {
      parts.push(`Memory usage increased by ${metricChanges.memoryUsageChange} bytes.`);
    } else {
      parts.push('Memory usage remained unchanged.');
    }
    
    // Success rate analysis
    if (metricChanges.successRateChange > 0) {
      parts.push(`Success rate improved by ${(metricChanges.successRateChange * 100).toFixed(2)}%.`);
    } else if (metricChanges.successRateChange < 0) {
      parts.push(`Success rate decreased by ${Math.abs(metricChanges.successRateChange * 100).toFixed(2)}%.`);
    } else {
      parts.push('Success rate remained unchanged.');
    }
    
    // Error count analysis
    if (metricChanges.errorCountChange < 0) {
      parts.push(`Error count decreased by ${Math.abs(metricChanges.errorCountChange)}.`);
    } else if (metricChanges.errorCountChange > 0) {
      parts.push(`Error count increased by ${metricChanges.errorCountChange}.`);
    } else {
      parts.push('Error count remained unchanged.');
    }
    
    // Overall assessment
    if (
      metricChanges.executionTimeChange <= 0 &&
      metricChanges.memoryUsageChange <= 0 &&
      metricChanges.successRateChange >= 0 &&
      metricChanges.errorCountChange <= 0
    ) {
      parts.push('Overall: The change resulted in improvements across all metrics.');
    } else if (
      metricChanges.executionTimeChange >= 0 &&
      metricChanges.memoryUsageChange >= 0 &&
      metricChanges.successRateChange <= 0 &&
      metricChanges.errorCountChange >= 0
    ) {
      parts.push('Overall: The change resulted in degradation across all metrics.');
    } else {
      parts.push('Overall: The change had mixed effects on system performance.');
    }
    
    return parts.join(' ');
  }

  /**
   * Persists a comparison to storage
   */
  private async persistComparison(comparison: TaskComparison, taskId: string): Promise<void> {
    await this.memoryManager.storeMemory({
      id: comparison.id,
      type: MemoryType.LONG_TERM,
      key: `comparison:${taskId}:${comparison.id}`,
      value: comparison,
      metadata: {
        taskId,
        beforeSnapshotId: comparison.beforeSnapshotId,
        afterSnapshotId: comparison.afterSnapshotId
      },
      timestamp: comparison.timestamp
    });
  }

  /**
   * Gets all experience records for a task
   */
  public getTaskExperiences(taskId: string): ExperienceRecord[] {
    return this.experiences.get(taskId) || [];
  }

  /**
   * Gets all comparisons for a task
   */
  public getTaskComparisons(taskId: string): TaskComparison[] {
    return this.comparisons.get(taskId) || [];
  }

  /**
   * Gets experiences of a specific type for a task
   */
  public getTaskExperiencesByType(
    taskId: string,
    type: 'success' | 'failure' | 'latency' | 'context' | 'snapshot'
  ): ExperienceRecord[] {
    const experiences = this.experiences.get(taskId) || [];
    return experiences.filter(exp => exp.type === type);
  }

  /**
   * Gets all snapshots for a task
   */
  public async getTaskSnapshots(taskId: string): Promise<TaskSnapshot[]> {
    const experiences = this.getTaskExperiencesByType(taskId, 'snapshot');
    return experiences.map(exp => exp.data as TaskSnapshot);
  }
}

export default AutonomousExperienceLogger;
