/**
 * Core Module Integration Test
 * 
 * This file validates the functionality and interoperability of the
 * Autonomous Cognition Core modules.
 */

import { 
  AgentStatus, 
  AgentMessageType, 
  AgentMessagePriority,
  GoalPriority,
  MemoryItemType
} from './types';
import { agentEventBus } from './event-bus';
import { memorySystem } from './memory';
import { goalDecomposer } from './goal-decomposer';
import { feedbackLoop } from './feedback-loop';
import { universalPlanner } from './planner';
import { metaCognitionAgent } from './meta-cognition';
import { agentRegistry } from './agent-registry';

/**
 * Run integration tests for the Autonomous Cognition Core
 */
async function testCoreModules() {
  console.log('Starting Autonomous Cognition Core integration tests...');
  
  try {
    // Test 1: Agent Registry and Event Bus
    console.log('\nTest 1: Agent Registry and Event Bus');
    await testAgentRegistryAndEventBus();
    
    // Test 2: Memory System
    console.log('\nTest 2: Memory System');
    testMemorySystem();
    
    // Test 3: Goal Decomposer
    console.log('\nTest 3: Goal Decomposer');
    testGoalDecomposer();
    
    // Test 4: Universal Planner
    console.log('\nTest 4: Universal Planner');
    await testUniversalPlanner();
    
    // Test 5: Feedback Loop
    console.log('\nTest 5: Feedback Loop');
    testFeedbackLoop();
    
    // Test 6: Meta-Cognition Agent
    console.log('\nTest 6: Meta-Cognition Agent');
    await testMetaCognitionAgent();
    
    // Test 7: End-to-End Core Workflow
    console.log('\nTest 7: End-to-End Core Workflow');
    await testEndToEndWorkflow();
    
    console.log('\nAll tests completed successfully!');
  } catch (error) {
    console.error('Test failed:', error);
  }
}

/**
 * Test Agent Registry and Event Bus
 */
async function testAgentRegistryAndEventBus() {
  // Register a test agent
  const testAgent = {
    id: 'test_agent',
    name: 'Test Agent',
    description: 'Agent for testing purposes',
    capabilities: [
      {
        id: 'test_capability',
        name: 'Test Capability',
        description: 'A capability for testing',
        parameters: []
      }
    ],
    status: AgentStatus.IDLE,
    initialize: async () => {},
    shutdown: async () => {},
    handleMessage: async () => null
  };
  
  const registered = agentRegistry.registerAgent(testAgent);
  console.log(`Agent registered: ${registered}`);
  
  // Verify agent is in registry
  const retrievedAgent = agentRegistry.getAgent('test_agent');
  console.log(`Agent retrieved: ${retrievedAgent?.id === 'test_agent'}`);
  
  // Test event bus
  return new Promise<void>((resolve) => {
    // Subscribe to test messages
    const subscriptionId = agentEventBus.subscribe(
      'test_subscriber',
      { type: AgentMessageType.EVENT },
      async (message) => {
        console.log(`Message received: ${message.content.text}`);
        
        // Unsubscribe after receiving message
        agentEventBus.unsubscribe(subscriptionId);
        
        // Unregister test agent
        const unregistered = agentRegistry.unregisterAgent('test_agent');
        console.log(`Agent unregistered: ${unregistered}`);
        
        resolve();
      }
    );
    
    // Publish test message
    agentEventBus.publish({
      id: `msg_${Date.now()}`,
      timestamp: Date.now(),
      sender: 'test_sender',
      recipient: null, // broadcast
      type: AgentMessageType.EVENT,
      content: {
        text: 'Test message'
      },
      priority: AgentMessagePriority.NORMAL
    });
  });
}

/**
 * Test Memory System
 */
function testMemorySystem() {
  // Test short-term memory
  const stmId = memorySystem.storeShortTerm({
    type: MemoryItemType.FACT,
    content: 'This is a short-term memory test',
    tags: ['test', 'short-term'],
    importance: 50,
    createdAt: Date.now(),
    metadata: {}
  });
  console.log(`Short-term memory stored: ${stmId}`);
  
  // Test long-term memory
  const ltmId = memorySystem.storeLongTerm({
    type: MemoryItemType.KNOWLEDGE,
    content: 'This is a long-term memory test',
    tags: ['test', 'long-term'],
    importance: 70,
    createdAt: Date.now(),
    metadata: {}
  });
  console.log(`Long-term memory stored: ${ltmId}`);
  
  // Test episodic memory
  const epmId = memorySystem.storeEpisodic('test_sequence', {
    type: MemoryItemType.EXPERIENCE,
    content: 'This is an episodic memory test',
    tags: ['test', 'episodic'],
    importance: 60,
    createdAt: Date.now(),
    metadata: {}
  });
  console.log(`Episodic memory stored: ${epmId}`);
  
  // Test retrieval
  const stmItem = memorySystem.retrieveById(stmId);
  console.log(`Short-term memory retrieved: ${stmItem !== null}`);
  
  // Test search by tags
  const tagResults = memorySystem.searchByTags(['test']);
  console.log(`Tag search results: ${tagResults.length}`);
  
  // Test search by content
  const contentResults = memorySystem.searchByContent('memory test');
  console.log(`Content search results: ${contentResults.length}`);
}

/**
 * Test Goal Decomposer
 */
function testGoalDecomposer() {
  // Create a top-level goal
  const goal = goalDecomposer.createGoal(
    'Test the Autonomous Cognition Core',
    GoalPriority.HIGH
  );
  console.log(`Goal created: ${goal.id}`);
  
  // Add subgoals
  const subGoal1 = goalDecomposer.addSubGoal(
    goal.id,
    'Test the Memory System',
    GoalPriority.MEDIUM
  );
  console.log(`Subgoal 1 created: ${subGoal1?.id}`);
  
  const subGoal2 = goalDecomposer.addSubGoal(
    goal.id,
    'Test the Event Bus',
    GoalPriority.MEDIUM
  );
  console.log(`Subgoal 2 created: ${subGoal2?.id}`);
  
  // Update goal status
  if (subGoal1) {
    const updatedSubGoal = goalDecomposer.updateGoalStatus(
      subGoal1.id,
      GoalStatus.COMPLETED
    );
    console.log(`Subgoal 1 updated: ${updatedSubGoal?.status === GoalStatus.COMPLETED}`);
  }
  
  // Get subgoals
  const subGoals = goalDecomposer.getSubGoals(goal.id);
  console.log(`Subgoals retrieved: ${subGoals.length}`);
  
  // Get top-level goals
  const topGoals = goalDecomposer.getTopLevelGoals();
  console.log(`Top-level goals retrieved: ${topGoals.length}`);
}

/**
 * Test Universal Planner
 */
async function testUniversalPlanner() {
  // Register test agent with planner
  universalPlanner.registerAgent(
    'test_planner_agent',
    'Test Planner Agent',
    [
      {
        id: 'test_action',
        name: 'Test Action',
        description: 'A test action'
      }
    ]
  );
  console.log('Test agent registered with planner');
  
  // Create a goal for planning
  const goal = goalDecomposer.createGoal(
    'Test the Universal Planner',
    GoalPriority.HIGH
  );
  console.log(`Planning goal created: ${goal.id}`);
  
  // Create a plan
  const plan = universalPlanner.createPlan(goal.id);
  console.log(`Plan created: ${plan?.id}`);
  
  if (plan) {
    // Add plan steps
    const step1 = universalPlanner.addPlanStep(
      plan.id,
      'Initialize test environment',
      'test_planner_agent',
      'test_action',
      { param1: 'value1' }
    );
    console.log(`Plan step 1 added: ${step1?.id}`);
    
    const step2 = universalPlanner.addPlanStep(
      plan.id,
      'Execute test action',
      'test_planner_agent',
      'test_action',
      { param2: 'value2' },
      step1 ? [step1.id] : []
    );
    console.log(`Plan step 2 added: ${step2?.id}`);
    
    // Start the plan
    const startedPlan = universalPlanner.startPlan(plan.id);
    console.log(`Plan started: ${startedPlan?.status === PlanStatus.IN_PROGRESS}`);
    
    // Simulate step completion
    if (step1) {
      const updatedPlan = universalPlanner.updateStepStatus(
        plan.id,
        step1.id,
        PlanStepStatus.COMPLETED,
        { result: 'success' }
      );
      console.log(`Step 1 completed: ${updatedPlan?.steps.find(s => s.id === step1.id)?.status === PlanStepStatus.COMPLETED}`);
    }
  }
}

/**
 * Test Feedback Loop
 */
function testFeedbackLoop() {
  // Record feedback
  const feedback1 = feedbackLoop.recordFeedback(
    'test_agent',
    'test_action_1',
    true,
    80,
    'Action completed successfully'
  );
  console.log(`Feedback 1 recorded: ${feedback1.id}`);
  
  const feedback2 = feedbackLoop.recordFeedback(
    'test_agent',
    'test_action_2',
    false,
    -30,
    'Action failed due to timeout'
  );
  console.log(`Feedback 2 recorded: ${feedback2.id}`);
  
  // Get agent feedback
  const agentFeedback = feedbackLoop.getAgentFeedback('test_agent');
  console.log(`Agent feedback retrieved: ${agentFeedback.length}`);
  
  // Get action feedback
  const actionFeedback = feedbackLoop.getActionFeedback('test_action_1');
  console.log(`Action feedback retrieved: ${actionFeedback.length}`);
  
  // Get agent performance
  const performance = feedbackLoop.getAgentPerformance('test_agent');
  console.log(`Agent performance retrieved: success rate = ${performance.successRate}`);
}

/**
 * Test Meta-Cognition Agent
 */
async function testMetaCognitionAgent() {
  // Initialize meta-cognition agent
  await metaCognitionAgent.initialize();
  console.log(`Meta-cognition agent initialized: ${metaCognitionAgent.status === AgentStatus.IDLE}`);
  
  // Register with agent registry
  agentRegistry.registerAgent(metaCognitionAgent);
  console.log('Meta-cognition agent registered');
  
  // Test message handling
  const response = await metaCognitionAgent.handleMessage({
    id: `msg_${Date.now()}`,
    timestamp: Date.now(),
    sender: 'test_sender',
    recipient: metaCognitionAgent.id,
    type: AgentMessageType.REQUEST,
    content: {
      capability: 'monitor_performance'
    },
    priority: AgentMessagePriority.NORMAL
  });
  
  console.log(`Meta-cognition agent response received: ${response !== null}`);
  
  // Shutdown meta-cognition agent
  await metaCognitionAgent.shutdown();
  console.log(`Meta-cognition agent shutdown: ${metaCognitionAgent.status === AgentStatus.SHUTDOWN}`);
}

/**
 * Test End-to-End Core Workflow
 */
async function testEndToEndWorkflow() {
  // Initialize meta-cognition agent
  await metaCognitionAgent.initialize();
  
  // Register agents
  const testAgent1 = {
    id: 'workflow_agent_1',
    name: 'Workflow Test Agent 1',
    description: 'Agent for testing end-to-end workflow',
    capabilities: [
      {
        id: 'workflow_capability_1',
        name: 'Workflow Test Capability 1',
        description: 'A capability for testing workflow',
        parameters: []
      }
    ],
    status: AgentStatus.IDLE,
    initialize: async () => {},
    shutdown: async () => {},
    handleMessage: async (message) => {
      if (
        message.type === AgentMessageType.COMMAND &&
        message.content.command === 'execute_step'
      ) {
        // Simulate successful step execution
        setTimeout(() => {
          universalPlanner.updateStepStatus(
            message.content.planId,
            message.content.stepId,
            PlanStepStatus.COMPLETED,
            { result: 'success' }
          );
          
          // Record positive feedback
          feedbackLoop.recordFeedback(
            'workflow_agent_1',
            message.content.stepId,
            true,
            90,
            'Step executed successfully'
          );
        }, 100);
        
        return {
          id: `msg_${Date.now()}`,
          timestamp: Date.now(),
          sender: 'workflow_agent_1',
          recipient: message.sender,
          type: AgentMessageType.RESPONSE,
          content: { status: 'executing' },
          correlationId: message.id,
          priority: message.priority
        };
      }
      return null;
    }
  };
  
  const testAgent2 = {
    id: 'workflow_agent_2',
    name: 'Workflow Test Agent 2',
    description: 'Agent for testing end-to-end workflow',
    capabilities: [
      {
        id: 'workflow_capability_2',
        name: 'Workflow Test Capability 2',
        description: 'A capability for testing workflow',
        parameters: []
      }
    ],
    status: AgentStatus.IDLE,
    initialize: async () => {},
    shutdown: async () => {},
    handleMessage: async (message) => {
      if (
        message.type === AgentMessageType.COMMAND &&
        message.content.command === 'execute_step'
      ) {
        // Simulate successful step execution
        setTimeout(() => {
          universalPlanner.updateStepStatus(
            message.content.planId,
            message.content.stepId,
            PlanStepStatus.COMPLETED,
            { result: 'success' }
          );
          
          // Record positive feedback
          feedbackLoop.recordFeedback(
            'workflow_agent_2',
            message.content.stepId,
            true,
            85,
            'Step executed successfully'
          );
        }, 200);
        
        return {
          id: `msg_${Date.now()}`,
          timestamp: Date.now(),
          sender: 'workflow_agent_2',
          recipient: message.sender,
          type: AgentMessageType.RESPONSE,
          content: { status: 'executing' },
          correlationId: message.id,
          priority: message.priority
        };
      }
      return null;
    }
  };
  
  agentRegistry.registerAgent(testAgent1);
  agentRegistry.registerAgent(testAgent2);
  
  // Register agents with planner
  universalPlanner.registerAgent(
    'workflow_agent_1',
    'Workflow Test Agent 1',
    [
      {
        id: 'workflow_capability_1',
        name: 'Workflow Test Capability 1',
        description: 'A capability for testing workflow'
      }
    ]
  );
  
  universalPlanner.registerAgent(
    'workflow_agent_2',
    'Workflow Test Agent 2',
    [
      {
        id: 'workflow_capability_2',
        name: 'Workflow Test Capability 2',
        description: 'A capability for testing workflow'
      }
    ]
  );
  
  // Create a workflow goal
  const workflowGoal = goalDecomposer.createGoal(
    'Test end-to-end workflow',
    GoalPriority.HIGH
  );
  
  // Add subgoals
  const subGoal1 = goalDecomposer.addSubGoal(
    workflowGoal.id,
    'Complete first part of workflow',
    GoalPriority.MEDIUM
  );
  
  const subGoal2 = goalDecomposer.addSubGoal(
    workflowGoal.id,
    'Complete second part of workflow',
    GoalPriority.MEDIUM
  );
  
  // Create a plan
  const workflowPlan = universalPlanner.createPlan(workflowGoal.id);
  
  if (workflowPlan && subGoal1 && subGoal2) {
    // Add plan steps
    const step1 = universalPlanner.addPlanStep(
      workflowPlan.id,
      'Execute first workflow task',
      'workflow_agent_1',
      'workflow_capability_1',
      { task: 'first_task' }
    );
    
    const step2 = universalPlanner.addPlanStep(
      workflowPlan.id,
      'Execute second workflow task',
      'workflow_agent_2',
      'workflow_capability_2',
      { task: 'second_task' },
      step1 ? [step1.id] : []
    );
    
    // Start the plan
    universalPlanner.startPlan(workflowPlan.id);
    
    // Wait for plan to complete
    return new Promise<void>((resolve) => {
      const checkInterval = setInterval(() => {
        const plan = universalPlanner.getPlan(workflowPlan.id);
        
        if (plan && (
          plan.status === PlanStatus.COMPLETED ||
          plan.status === PlanStatus.FAILED
        )) {
          clearInterval(checkInterval);
          
          console.log(`Workflow plan completed: ${plan.status === PlanStatus.COMPLETED}`);
          
          // Check goal status
          const goal = goalDecomposer.getGoal(workflowGoal.id);
          console.log(`Workflow goal status: ${goal?.status}`);
          
          // Get agent performance
          const agent1Performance = feedbackLoop.getAgentPerformance('workflow_agent_1');
          const agent2Performance = feedbackLoop.getAgentPerformance('workflow_agent_2');
          
          console.log(`Agent 1 success rate: ${agent1Performance.successRate}`);
          console.log(`Agent 2 success rate: ${agent2Performance.successRate}`);
          
          resolve();
        }
      }, 100);
    });
  }
}

// Export the test function
export { testCoreModules };
