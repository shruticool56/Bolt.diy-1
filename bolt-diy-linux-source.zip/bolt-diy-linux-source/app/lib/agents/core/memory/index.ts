/**
 * SentienceAI Cognitive Kernel - Memory Manager
 * 
 * This module implements the Experience Memory system:
 * - Persistent vector and symbolic memory (SQLite + Chroma/FAISS)
 * - Memory indexing and retrieval mechanisms
 * - Short-term, long-term, and episodic memory
 */

import { EventEmitter } from 'events';
import * as sqlite3 from 'sqlite3';
import * as path from 'path';
import * as fs from 'fs';

export enum MemoryType {
  SHORT_TERM = 'short_term',
  LONG_TERM = 'long_term',
  EPISODIC = 'episodic',
  VECTOR = 'vector',
  SYMBOLIC = 'symbolic'
}

export interface MemoryRecord {
  id: string;
  type: MemoryType;
  key: string;
  value: any;
  metadata: any;
  timestamp: number;
  expiration?: number; // Optional expiration timestamp for short-term memories
}

export interface VectorRecord extends MemoryRecord {
  vector: number[]; // Vector embedding
  dimensions: number;
}

export interface SymbolicRecord extends MemoryRecord {
  relations: { [key: string]: string[] }; // Symbolic relations
}

export interface MemoryQueryOptions {
  type?: MemoryType;
  key?: string;
  keyPattern?: string;
  metadata?: any;
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  expiredOnly?: boolean;
  unexpiredOnly?: boolean;
}

export interface VectorQueryOptions extends MemoryQueryOptions {
  vector: number[];
  dimensions: number;
  similarityThreshold?: number;
  maxResults?: number;
}

export interface SymbolicQueryOptions extends MemoryQueryOptions {
  relations: { [key: string]: string[] };
  matchAll?: boolean;
}

export class MemoryManager extends EventEmitter {
  private db: sqlite3.Database;
  private dbPath: string;
  private initialized: boolean = false;
  
  constructor(dbPath?: string) {
    super();
    this.dbPath = dbPath || path.join(process.cwd(), 'data', 'memory.db');
  }

  /**
   * Initializes the memory system
   */
  public async initialize(): Promise<void> {
    if (this.initialized) return;
    
    // Ensure directory exists
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    return new Promise<void>((resolve, reject) => {
      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          reject(err);
          return;
        }
        
        this.createTables()
          .then(() => {
            this.initialized = true;
            this.emit('initialized');
            resolve();
          })
          .catch(reject);
      });
    });
  }

  /**
   * Creates the necessary database tables
   */
  private async createTables(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      // Create main memory table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS memory (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL,
          key TEXT NOT NULL,
          value TEXT NOT NULL,
          metadata TEXT,
          timestamp INTEGER NOT NULL,
          expiration INTEGER
        )
      `, (err) => {
        if (err) {
          reject(err);
          return;
        }
        
        // Create vector memory table
        this.db.run(`
          CREATE TABLE IF NOT EXISTS vector_memory (
            id TEXT PRIMARY KEY,
            vector BLOB NOT NULL,
            dimensions INTEGER NOT NULL,
            FOREIGN KEY (id) REFERENCES memory (id) ON DELETE CASCADE
          )
        `, (err) => {
          if (err) {
            reject(err);
            return;
          }
          
          // Create symbolic memory table
          this.db.run(`
            CREATE TABLE IF NOT EXISTS symbolic_memory (
              id TEXT PRIMARY KEY,
              relations TEXT NOT NULL,
              FOREIGN KEY (id) REFERENCES memory (id) ON DELETE CASCADE
            )
          `, (err) => {
            if (err) {
              reject(err);
              return;
            }
            
            // Create indexes
            this.db.run(`
              CREATE INDEX IF NOT EXISTS idx_memory_type ON memory (type);
              CREATE INDEX IF NOT EXISTS idx_memory_key ON memory (key);
              CREATE INDEX IF NOT EXISTS idx_memory_timestamp ON memory (timestamp);
              CREATE INDEX IF NOT EXISTS idx_memory_expiration ON memory (expiration);
            `, (err) => {
              if (err) {
                reject(err);
                return;
              }
              
              resolve();
            });
          });
        });
      });
    });
  }

  /**
   * Stores a memory record
   */
  public async storeMemory(record: MemoryRecord): Promise<string> {
    if (!this.initialized) await this.initialize();
    
    return new Promise<string>((resolve, reject) => {
      const { id, type, key, value, metadata, timestamp, expiration } = record;
      
      this.db.run(
        `INSERT OR REPLACE INTO memory 
         (id, type, key, value, metadata, timestamp, expiration) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          type,
          key,
          JSON.stringify(value),
          JSON.stringify(metadata || {}),
          timestamp,
          expiration || null
        ],
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          
          this.emit('memoryStored', record);
          resolve(id);
        }
      );
    });
  }

  /**
   * Stores a vector memory record
   */
  public async storeVectorMemory(record: VectorRecord): Promise<string> {
    if (!this.initialized) await this.initialize();
    
    // First store the base memory record
    const baseId = await this.storeMemory({
      ...record,
      type: MemoryType.VECTOR
    });
    
    return new Promise<string>((resolve, reject) => {
      const { vector, dimensions } = record;
      
      // Store the vector-specific data
      this.db.run(
        `INSERT OR REPLACE INTO vector_memory 
         (id, vector, dimensions) 
         VALUES (?, ?, ?)`,
        [
          baseId,
          Buffer.from(new Float32Array(vector).buffer),
          dimensions
        ],
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          
          this.emit('vectorMemoryStored', record);
          resolve(baseId);
        }
      );
    });
  }

  /**
   * Stores a symbolic memory record
   */
  public async storeSymbolicMemory(record: SymbolicRecord): Promise<string> {
    if (!this.initialized) await this.initialize();
    
    // First store the base memory record
    const baseId = await this.storeMemory({
      ...record,
      type: MemoryType.SYMBOLIC
    });
    
    return new Promise<string>((resolve, reject) => {
      const { relations } = record;
      
      // Store the symbolic-specific data
      this.db.run(
        `INSERT OR REPLACE INTO symbolic_memory 
         (id, relations) 
         VALUES (?, ?)`,
        [
          baseId,
          JSON.stringify(relations)
        ],
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          
          this.emit('symbolicMemoryStored', record);
          resolve(baseId);
        }
      );
    });
  }

  /**
   * Retrieves a memory record by ID
   */
  public async getMemory(id: string): Promise<MemoryRecord | null> {
    if (!this.initialized) await this.initialize();
    
    return new Promise<MemoryRecord | null>((resolve, reject) => {
      this.db.get(
        `SELECT * FROM memory WHERE id = ?`,
        [id],
        (err, row) => {
          if (err) {
            reject(err);
            return;
          }
          
          if (!row) {
            resolve(null);
            return;
          }
          
          try {
            const record: MemoryRecord = {
              id: row.id,
              type: row.type as MemoryType,
              key: row.key,
              value: JSON.parse(row.value),
              metadata: JSON.parse(row.metadata),
              timestamp: row.timestamp,
              expiration: row.expiration
            };
            
            resolve(record);
          } catch (e) {
            reject(e);
          }
        }
      );
    });
  }

  /**
   * Queries memory records based on options
   */
  public async queryMemory(options: MemoryQueryOptions = {}): Promise<MemoryRecord[]> {
    if (!this.initialized) await this.initialize();
    
    const {
      type,
      key,
      keyPattern,
      metadata,
      limit = 100,
      offset = 0,
      sortBy = 'timestamp',
      sortDirection = 'desc',
      expiredOnly = false,
      unexpiredOnly = false
    } = options;
    
    let query = `SELECT * FROM memory WHERE 1=1`;
    const params: any[] = [];
    
    if (type) {
      query += ` AND type = ?`;
      params.push(type);
    }
    
    if (key) {
      query += ` AND key = ?`;
      params.push(key);
    }
    
    if (keyPattern) {
      query += ` AND key LIKE ?`;
      params.push(keyPattern);
    }
    
    if (metadata) {
      // This is a simplified approach; in a real implementation,
      // you would need more sophisticated JSON querying
      query += ` AND json_extract(metadata, '$.${Object.keys(metadata)[0]}') = ?`;
      params.push(Object.values(metadata)[0]);
    }
    
    const now = Date.now();
    
    if (expiredOnly) {
      query += ` AND expiration IS NOT NULL AND expiration < ?`;
      params.push(now);
    }
    
    if (unexpiredOnly) {
      query += ` AND (expiration IS NULL OR expiration >= ?)`;
      params.push(now);
    }
    
    query += ` ORDER BY ${sortBy} ${sortDirection === 'asc' ? 'ASC' : 'DESC'}`;
    query += ` LIMIT ? OFFSET ?`;
    params.push(limit, offset);
    
    return new Promise<MemoryRecord[]>((resolve, reject) => {
      this.db.all(query, params, (err, rows) => {
        if (err) {
          reject(err);
          return;
        }
        
        try {
          const records: MemoryRecord[] = rows.map(row => ({
            id: row.id,
            type: row.type as MemoryType,
            key: row.key,
            value: JSON.parse(row.value),
            metadata: JSON.parse(row.metadata),
            timestamp: row.timestamp,
            expiration: row.expiration
          }));
          
          resolve(records);
        } catch (e) {
          reject(e);
        }
      });
    });
  }

  /**
   * Stores learnings from the cognitive cycle
   */
  public async storeLearnings(taskId: string, learnings: any): Promise<string> {
    const record: MemoryRecord = {
      id: `learning_${taskId}_${Date.now()}`,
      type: MemoryType.LONG_TERM,
      key: `learning:${taskId}`,
      value: learnings,
      metadata: {
        source: 'cognitive_cycle',
        taskId
      },
      timestamp: Date.now()
    };
    
    return this.storeMemory(record);
  }

  /**
   * Retrieves learnings for a specific task
   */
  public async getTaskLearnings(taskId: string): Promise<any[]> {
    const records = await this.queryMemory({
      type: MemoryType.LONG_TERM,
      keyPattern: `learning:${taskId}%`,
      sortBy: 'timestamp',
      sortDirection: 'asc'
    });
    
    return records.map(record => record.value);
  }

  /**
   * Cleans up expired memories
   */
  public async cleanupExpiredMemories(): Promise<number> {
    if (!this.initialized) await this.initialize();
    
    return new Promise<number>((resolve, reject) => {
      const now = Date.now();
      
      this.db.run(
        `DELETE FROM memory WHERE expiration IS NOT NULL AND expiration < ?`,
        [now],
        function(err) {
          if (err) {
            reject(err);
            return;
          }
          
          resolve(this.changes);
        }
      );
    });
  }

  /**
   * Closes the database connection
   */
  public async close(): Promise<void> {
    if (!this.initialized) return;
    
    return new Promise<void>((resolve, reject) => {
      this.db.close((err) => {
        if (err) {
          reject(err);
          return;
        }
        
        this.initialized = false;
        this.emit('closed');
        resolve();
      });
    });
  }
}

export default MemoryManager;
