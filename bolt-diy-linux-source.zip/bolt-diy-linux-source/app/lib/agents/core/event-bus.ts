/**
 * Agent Communication Protocol - Event Bus Implementation
 * 
 * This module provides a centralized event bus for agent communication,
 * implementing the pub/sub pattern for message distribution.
 */

import { AgentMessage, AgentMessagePriority, AgentMessageType } from './types';

// Subscriber callback type
type MessageHandler = (message: AgentMessage) => Promise<void>;

// Subscription object
interface Subscription {
  id: string;
  agentId: string;
  filter: MessageFilter;
  handler: MessageHandler;
}

// Message filter for subscriptions
interface MessageFilter {
  sender?: string;
  type?: AgentMessageType;
  minPriority?: AgentMessagePriority;
}

/**
 * Agent Communication Event Bus
 * 
 * Provides centralized message routing between agents using a pub/sub pattern.
 */
class AgentEventBus {
  private static instance: AgentEventBus;
  private subscriptions: Map<string, Subscription> = new Map();
  private messageHistory: AgentMessage[] = [];
  private readonly MAX_HISTORY_SIZE = 1000;

  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the event bus
   */
  public static getInstance(): AgentEventBus {
    if (!AgentEventBus.instance) {
      AgentEventBus.instance = new AgentEventBus();
    }
    return AgentEventBus.instance;
  }

  /**
   * Publish a message to the event bus
   * 
   * @param message The message to publish
   * @returns Promise that resolves when all handlers have processed the message
   */
  public async publish(message: AgentMessage): Promise<void> {
    // Add message to history
    this.addToHistory(message);

    // Collect matching subscriptions
    const matchingSubscriptions = Array.from(this.subscriptions.values())
      .filter(sub => this.matchesFilter(message, sub.filter));

    // Process message with all matching handlers
    const handlerPromises = matchingSubscriptions.map(sub => {
      try {
        return sub.handler(message);
      } catch (error) {
        console.error(`Error in subscription handler ${sub.id}:`, error);
        return Promise.resolve();
      }
    });

    // Wait for all handlers to complete
    await Promise.all(handlerPromises);
  }

  /**
   * Subscribe to messages on the event bus
   * 
   * @param agentId The ID of the subscribing agent
   * @param filter Optional filter to restrict which messages are received
   * @param handler Callback function to handle received messages
   * @returns Subscription ID that can be used to unsubscribe
   */
  public subscribe(
    agentId: string,
    filter: MessageFilter,
    handler: MessageHandler
  ): string {
    const subscriptionId = `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    this.subscriptions.set(subscriptionId, {
      id: subscriptionId,
      agentId,
      filter,
      handler
    });
    
    return subscriptionId;
  }

  /**
   * Unsubscribe from the event bus
   * 
   * @param subscriptionId The ID returned from subscribe()
   * @returns true if successfully unsubscribed, false if subscription not found
   */
  public unsubscribe(subscriptionId: string): boolean {
    return this.subscriptions.delete(subscriptionId);
  }

  /**
   * Unsubscribe all subscriptions for a specific agent
   * 
   * @param agentId The ID of the agent
   * @returns Number of subscriptions removed
   */
  public unsubscribeAgent(agentId: string): number {
    let count = 0;
    
    for (const [id, subscription] of this.subscriptions.entries()) {
      if (subscription.agentId === agentId) {
        this.subscriptions.delete(id);
        count++;
      }
    }
    
    return count;
  }

  /**
   * Get recent message history
   * 
   * @param limit Maximum number of messages to return
   * @param filter Optional filter to restrict which messages are returned
   * @returns Array of messages
   */
  public getHistory(limit = 100, filter?: MessageFilter): AgentMessage[] {
    const filteredHistory = filter
      ? this.messageHistory.filter(msg => this.matchesFilter(msg, filter))
      : this.messageHistory;
    
    return filteredHistory.slice(-Math.min(limit, filteredHistory.length));
  }

  /**
   * Check if a message matches a filter
   * 
   * @param message The message to check
   * @param filter The filter to apply
   * @returns true if the message matches the filter
   */
  private matchesFilter(message: AgentMessage, filter: MessageFilter): boolean {
    // Check sender filter
    if (filter.sender && message.sender !== filter.sender) {
      return false;
    }
    
    // Check message type filter
    if (filter.type && message.type !== filter.type) {
      return false;
    }
    
    // Check priority filter
    if (filter.minPriority) {
      const priorityValues = {
        [AgentMessagePriority.LOW]: 0,
        [AgentMessagePriority.NORMAL]: 1,
        [AgentMessagePriority.HIGH]: 2,
        [AgentMessagePriority.CRITICAL]: 3
      };
      
      if (priorityValues[message.priority] < priorityValues[filter.minPriority]) {
        return false;
      }
    }
    
    // All filters passed
    return true;
  }

  /**
   * Add a message to the history, maintaining maximum size
   * 
   * @param message The message to add
   */
  private addToHistory(message: AgentMessage): void {
    this.messageHistory.push(message);
    
    // Trim history if it exceeds maximum size
    if (this.messageHistory.length > this.MAX_HISTORY_SIZE) {
      this.messageHistory = this.messageHistory.slice(-this.MAX_HISTORY_SIZE);
    }
  }
}

export const agentEventBus = AgentEventBus.getInstance();
