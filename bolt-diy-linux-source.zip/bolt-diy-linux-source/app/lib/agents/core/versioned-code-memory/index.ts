/**
 * SentienceAI Cognitive Kernel - Versioned Code Memory
 * 
 * This module implements the Versioned Code Memory:
 * - Tracks all code changes with version history
 * - Provides rollback capabilities
 * - Maintains audit trail of modifications
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal } from '../execution-journal';
import { SharedMemoryBus, Message, MessageType } from '../shared-memory-bus';

export interface CodeVersion {
  id: string;
  fileId: string;
  version: number;
  content: string;
  hash: string;
  timestamp: number;
  author: string;
  message: string;
  metadata: any;
}

export interface CodeFile {
  id: string;
  path: string;
  currentVersionId: string;
  versions: string[]; // Version IDs
  createdAt: number;
  updatedAt: number;
  metadata: any;
}

export interface CodeChange {
  id: string;
  fileId: string;
  fromVersionId: string;
  toVersionId: string;
  diff: string;
  reason: string;
  timestamp: number;
  author: string;
  metadata: any;
}

export class VersionedCodeMemory extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private sharedMemoryBus: SharedMemoryBus;
  private files: Map<string, CodeFile> = new Map();
  private versions: Map<string, CodeVersion> = new Map();
  private changes: Map<string, CodeChange> = new Map();
  private subscriptions: string[] = [];
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    sharedMemoryBus?: SharedMemoryBus
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.sharedMemoryBus = sharedMemoryBus || SharedMemoryBus.getInstance();
    
    // Initialize subscriptions
    this.initializeSubscriptions();
  }

  /**
   * Initializes message bus subscriptions
   */
  private initializeSubscriptions(): void {
    // Subscribe to file change events
    const fileSub = this.sharedMemoryBus.subscribe(
      'versioned-code-memory',
      'file:changed',
      this.handleFileChanged.bind(this)
    );
    this.subscriptions.push(fileSub.id);
    
    // Subscribe to version request events
    const versionSub = this.sharedMemoryBus.subscribe(
      'versioned-code-memory',
      'version:request',
      this.handleVersionRequest.bind(this)
    );
    this.subscriptions.push(versionSub.id);
    
    // Subscribe to rollback request events
    const rollbackSub = this.sharedMemoryBus.subscribe(
      'versioned-code-memory',
      'rollback:request',
      this.handleRollbackRequest.bind(this)
    );
    this.subscriptions.push(rollbackSub.id);
  }

  /**
   * Handles file changed events
   */
  private handleFileChanged(message: Message): void {
    const { sender, payload } = message;
    
    try {
      // Track the file change
      const change = this.trackFileChange(
        payload.filePath,
        payload.content,
        sender,
        payload.message || 'File changed',
        payload.metadata || {}
      );
      
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', {
        success: true,
        fileId: change.fileId,
        versionId: change.toVersionId,
        changeId: change.id
      });
    } catch (error) {
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', null, {
        error: `Error tracking file change: ${error}`
      });
    }
  }

  /**
   * Handles version request events
   */
  private handleVersionRequest(message: Message): void {
    const { payload } = message;
    
    try {
      let version: CodeVersion | null = null;
      
      if (payload.versionId) {
        // Get specific version
        version = this.getVersion(payload.versionId);
      } else if (payload.filePath && payload.version !== undefined) {
        // Get version by file path and version number
        version = this.getFileVersionByNumber(payload.filePath, payload.version);
      } else if (payload.filePath) {
        // Get latest version
        version = this.getLatestVersion(payload.filePath);
      }
      
      if (!version) {
        this.sharedMemoryBus.respond(message, 'versioned-code-memory', null, {
          error: 'Version not found'
        });
        return;
      }
      
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', {
        version
      });
    } catch (error) {
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', null, {
        error: `Error retrieving version: ${error}`
      });
    }
  }

  /**
   * Handles rollback request events
   */
  private handleRollbackRequest(message: Message): void {
    const { sender, payload } = message;
    
    try {
      // Rollback to specified version
      const result = this.rollbackToVersion(
        payload.filePath,
        payload.versionId || payload.version,
        sender,
        payload.message || 'Rollback to previous version',
        payload.metadata || {}
      );
      
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', {
        success: true,
        fileId: result.fileId,
        versionId: result.versionId,
        changeId: result.changeId
      });
    } catch (error) {
      this.sharedMemoryBus.respond(message, 'versioned-code-memory', null, {
        error: `Error rolling back: ${error}`
      });
    }
  }

  /**
   * Tracks a file change
   */
  public trackFileChange(
    filePath: string,
    content: string,
    author: string,
    message: string,
    metadata: any = {}
  ): CodeChange {
    // Normalize file path
    const normalizedPath = this.normalizePath(filePath);
    
    // Get or create file
    let file = this.getFileByPath(normalizedPath);
    let previousVersion: CodeVersion | null = null;
    
    if (!file) {
      // Create new file
      file = this.createFile(normalizedPath, metadata);
    } else {
      // Get previous version
      const previousVersionId = file.currentVersionId;
      previousVersion = this.versions.get(previousVersionId) || null;
    }
    
    // Create new version
    const version = this.createVersion(
      file.id,
      content,
      author,
      message,
      metadata
    );
    
    // Update file
    file.currentVersionId = version.id;
    file.versions.push(version.id);
    file.updatedAt = Date.now();
    
    this.files.set(file.id, file);
    
    // Create change record
    const change = this.createChange(
      file.id,
      previousVersion ? previousVersion.id : '',
      version.id,
      this.generateDiff(previousVersion ? previousVersion.content : '', content),
      message,
      author,
      metadata
    );
    
    // Log the change
    this.executionJournal.logInfo(
      'system',
      `File ${normalizedPath} changed: ${message}`,
      { file, version, change }
    );
    
    this.emit('fileChanged', file, version, change);
    return change;
  }

  /**
   * Creates a file record
   */
  private createFile(filePath: string, metadata: any = {}): CodeFile {
    const file: CodeFile = {
      id: uuidv4(),
      path: filePath,
      currentVersionId: '',
      versions: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      metadata
    };
    
    this.files.set(file.id, file);
    this.emit('fileCreated', file);
    
    return file;
  }

  /**
   * Creates a version record
   */
  private createVersion(
    fileId: string,
    content: string,
    author: string,
    message: string,
    metadata: any = {}
  ): CodeVersion {
    // Get file
    const file = this.files.get(fileId);
    if (!file) {
      throw new Error(`File with ID ${fileId} not found`);
    }
    
    // Calculate version number
    const versionNumber = file.versions.length + 1;
    
    // Calculate content hash
    const hash = this.calculateHash(content);
    
    // Create version
    const version: CodeVersion = {
      id: uuidv4(),
      fileId,
      version: versionNumber,
      content,
      hash,
      timestamp: Date.now(),
      author,
      message,
      metadata
    };
    
    this.versions.set(version.id, version);
    
    // Persist to storage
    this.persistVersion(version).catch(err => {
      console.error('Error persisting version:', err);
    });
    
    this.emit('versionCreated', version);
    return version;
  }

  /**
   * Creates a change record
   */
  private createChange(
    fileId: string,
    fromVersionId: string,
    toVersionId: string,
    diff: string,
    reason: string,
    author: string,
    metadata: any = {}
  ): CodeChange {
    const change: CodeChange = {
      id: uuidv4(),
      fileId,
      fromVersionId,
      toVersionId,
      diff,
      reason,
      timestamp: Date.now(),
      author,
      metadata
    };
    
    this.changes.set(change.id, change);
    
    // Persist to storage
    this.persistChange(change).catch(err => {
      console.error('Error persisting change:', err);
    });
    
    this.emit('changeCreated', change);
    return change;
  }

  /**
   * Calculates a hash for content
   */
  private calculateHash(content: string): string {
    // This is a simplified hash calculation
    // In a real implementation, this would use a proper hash function
    
    let hash = 0;
    for (let i = 0; i < content.length; i++) {
      const char = content.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    
    return hash.toString(16);
  }

  /**
   * Generates a diff between two versions
   */
  private generateDiff(oldContent: string, newContent: string): string {
    // This is a simplified diff generation
    // In a real implementation, this would use a proper diff algorithm
    
    if (!oldContent) {
      return `+${newContent}`;
    }
    
    // Count lines
    const oldLines = oldContent.split('\n').length;
    const newLines = newContent.split('\n').length;
    
    return `@@ -1,${oldLines} +1,${newLines} @@\n` +
           `-${oldContent}\n` +
           `+${newContent}`;
  }

  /**
   * Persists a version to storage
   */
  private async persistVersion(version: CodeVersion): Promise<void> {
    await this.memoryManager.storeMemory({
      id: version.id,
      type: MemoryType.LONG_TERM,
      key: `code_version:${version.fileId}:${version.version}`,
      value: version,
      metadata: {
        fileId: version.fileId,
        version: version.version,
        hash: version.hash,
        author: version.author
      },
      timestamp: version.timestamp
    });
  }

  /**
   * Persists a change to storage
   */
  private async persistChange(change: CodeChange): Promise<void> {
    await this.memoryManager.storeMemory({
      id: change.id,
      type: MemoryType.LONG_TERM,
      key: `code_change:${change.fileId}:${change.id}`,
      value: change,
      metadata: {
        fileId: change.fileId,
        fromVersionId: change.fromVersionId,
        toVersionId: change.toVersionId,
        author: change.author
      },
      timestamp: change.timestamp
    });
  }

  /**
   * Normalizes a file path
   */
  private normalizePath(filePath: string): string {
    // Ensure forward slashes
    return filePath.replace(/\\/g, '/');
  }

  /**
   * Gets a file by path
   */
  public getFileByPath(filePath: string): CodeFile | null {
    const normalizedPath = this.normalizePath(filePath);
    
    for (const file of this.files.values()) {
      if (this.normalizePath(file.path) === normalizedPath) {
        return file;
      }
    }
    
    return null;
  }

  /**
   * Gets a file by ID
   */
  public getFile(fileId: string): CodeFile | null {
    return this.files.get(fileId) || null;
  }

  /**
   * Gets a version by ID
   */
  public getVersion(versionId: string): CodeVersion | null {
    return this.versions.get(versionId) || null;
  }

  /**
   * Gets the latest version of a file
   */
  public getLatestVersion(filePath: string): CodeVersion | null {
    const file = this.getFileByPath(filePath);
    if (!file || !file.currentVersionId) {
      return null;
    }
    
    return this.versions.get(file.currentVersionId) || null;
  }

  /**
   * Gets a specific version of a file by version number
   */
  public getFileVersionByNumber(filePath: string, versionNumber: number): CodeVersion | null {
    const file = this.getFileByPath(filePath);
    if (!file || versionNumber < 1 || versionNumber > file.versions.length) {
      return null;
    }
    
    const versionId = file.versions[versionNumber - 1];
    return this.versions.get(versionId) || null;
  }

  /**
   * Gets all versions of a file
   */
  public getFileVersions(filePath: string): CodeVersion[] {
    const file = this.getFileByPath(filePath);
    if (!file) {
      return [];
    }
    
    return file.versions
      .map(versionId => this.versions.get(versionId))
      .filter(Boolean) as CodeVersion[];
  }

  /**
   * Gets all changes for a file
   */
  public getFileChanges(filePath: string): CodeChange[] {
    const file = this.getFileByPath(filePath);
    if (!file) {
      return [];
    }
    
    return Array.from(this.changes.values())
      .filter(change => change.fileId === file.id);
  }

  /**
   * Rolls back a file to a specific version
   */
  public rollbackToVersion(
    filePath: string,
    versionIdOrNumber: string | number,
    author: string,
    message: string,
    metadata: any = {}
  ): { fileId: string; versionId: string; changeId: string } {
    // Get file
    const file = this.getFileByPath(filePath);
    if (!file) {
      throw new Error(`File ${filePath} not found`);
    }
    
    // Get target version
    let targetVersion: CodeVersion | null = null;
    
    if (typeof versionIdOrNumber === 'string') {
      // Get by version ID
      targetVersion = this.versions.get(versionIdOrNumber) || null;
      
      // Verify version belongs to file
      if (targetVersion && targetVersion.fileId !== file.id) {
        throw new Error(`Version ${versionIdOrNumber} does not belong to file ${filePath}`);
      }
    } else {
      // Get by version number
      targetVersion = this.getFileVersionByNumber(filePath, versionIdOrNumber);
    }
    
    if (!targetVersion) {
      throw new Error(`Version ${versionIdOrNumber} not found for file ${filePath}`);
    }
    
    // Get current version
    const currentVersion = this.versions.get(file.currentVersionId);
    if (!currentVersion) {
      throw new Error(`Current version not found for file ${filePath}`);
    }
    
    // If already at target version, do nothing
    if (currentVersion.id === targetVersion.id) {
      return {
        fileId: file.id,
        versionId: currentVersion.id,
        changeId: '' // No change needed
      };
    }
    
    // Create new version based on target version
    const rollbackMessage = `${message} (rollback from v${currentVersion.version} to v${targetVersion.version})`;
    
    const newVersion = this.createVersion(
      file.id,
      targetVersion.content,
      author,
      rollbackMessage,
      {
        ...metadata,
        rollback: {
          fromVersionId: currentVersion.id,
          toVersionId: targetVersion.id
        }
      }
    );
    
    // Update file
    file.currentVersionId = newVersion.id;
    file.versions.push(newVersion.id);
    file.updatedAt = Date.now();
    
    this.files.set(file.id, file);
    
    // Create change record
    const change = this.createChange(
      file.id,
      currentVersion.id,
      newVersion.id,
      this.generateDiff(currentVersion.content, newVersion.content),
      rollbackMessage,
      author,
      {
        ...metadata,
        rollback: {
          fromVersionId: currentVersion.id,
          toVersionId: targetVersion.id
        }
      }
    );
    
    // Log the rollback
    this.executionJournal.logInfo(
      'system',
      `File ${filePath} rolled back: ${rollbackMessage}`,
      { file, version: newVersion, change }
    );
    
    this.emit('fileRolledBack', file, newVersion, change);
    
    return {
      fileId: file.id,
      versionId: newVersion.id,
      changeId: change.id
    };
  }

  /**
   * Gets all files
   */
  public getFiles(): CodeFile[] {
    return Array.from(this.files.values());
  }

  /**
   * Gets all versions
   */
  public getVersions(): CodeVersion[] {
    return Array.from(this.versions.values());
  }

  /**
   * Gets all changes
   */
  public getChanges(): CodeChange[] {
    return Array.from(this.changes.values());
  }

  /**
   * Writes a version to disk
   */
  public async writeVersionToDisk(versionId: string): Promise<boolean> {
    const version = this.versions.get(versionId);
    if (!version) {
      throw new Error(`Version ${versionId} not found`);
    }
    
    const file = this.files.get(version.fileId);
    if (!file) {
      throw new Error(`File for version ${versionId} not found`);
    }
    
    try {
      // Ensure directory exists
      const dir = path.dirname(file.path);
      await this.ensureDirectoryExists(dir);
      
      // Write file
      await this.writeFile(file.path, version.content);
      
      return true;
    } catch (error) {
      console.error(`Error writing version ${versionId} to disk:`, error);
      return false;
    }
  }

  /**
   * Ensures a directory exists
   */
  private async ensureDirectoryExists(dir: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      fs.mkdir(dir, { recursive: true }, (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }

  /**
   * Writes a file
   */
  private async writeFile(filePath: string, content: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      fs.writeFile(filePath, content, 'utf8', (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }
}

export default VersionedCodeMemory;
