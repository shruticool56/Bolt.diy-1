/**
 * Universal Planner Implementation for Autonomous Cognition Core
 * 
 * Decomposes user tasks into executable plans for other agents.
 */

import { Plan, PlanStep, PlanStatus, PlanStepStatus, Goal, GoalStatus } from './types';
import { goalDecomposer } from './goal-decomposer';
import { memorySystem } from './memory';
import { agentEventBus } from './event-bus';
import { AgentMessageType, AgentMessagePriority } from './types';

/**
 * Universal Planner for the Autonomous Cognition Core
 * 
 * Responsible for creating and managing execution plans based on goals,
 * coordinating agent activities, and tracking plan progress.
 */
class UniversalPlanner {
  private static instance: UniversalPlanner;
  private plans: Map<string, Plan> = new Map();
  private agentRegistry: Map<string, {
    id: string;
    name: string;
    capabilities: Array<{
      id: string;
      name: string;
      description: string;
    }>;
  }> = new Map();
  
  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the universal planner
   */
  public static getInstance(): UniversalPlanner {
    if (!UniversalPlanner.instance) {
      UniversalPlanner.instance = new UniversalPlanner();
    }
    return UniversalPlanner.instance;
  }

  /**
   * Register an agent with the planner
   * 
   * @param agentId Unique identifier for the agent
   * @param name Human-readable name of the agent
   * @param capabilities Array of capabilities the agent provides
   */
  public registerAgent(
    agentId: string,
    name: string,
    capabilities: Array<{
      id: string;
      name: string;
      description: string;
    }>
  ): void {
    this.agentRegistry.set(agentId, {
      id: agentId,
      name,
      capabilities
    });
    
    // Store in memory for context awareness
    memorySystem.storeLongTerm({
      type: 'knowledge',
      content: {
        type: 'agent_registered',
        agentId,
        name,
        capabilities
      },
      tags: ['agent', 'registered', agentId],
      importance: 60,
      createdAt: Date.now(),
      metadata: {}
    });
  }

  /**
   * Unregister an agent from the planner
   * 
   * @param agentId ID of the agent to unregister
   * @returns true if agent was found and unregistered, false otherwise
   */
  public unregisterAgent(agentId: string): boolean {
    const result = this.agentRegistry.delete(agentId);
    
    if (result) {
      // Store in memory for context awareness
      memorySystem.storeShortTerm({
        type: 'context',
        content: {
          type: 'agent_unregistered',
          agentId
        },
        tags: ['agent', 'unregistered', agentId],
        importance: 60,
        createdAt: Date.now(),
        metadata: {}
      });
    }
    
    return result;
  }

  /**
   * Create a plan for a goal
   * 
   * @param goalId ID of the goal to create a plan for
   * @returns The created plan or null if goal not found
   */
  public createPlan(goalId: string): Plan | null {
    const goal = goalDecomposer.getGoal(goalId);
    if (!goal) {
      return null;
    }
    
    const now = Date.now();
    const plan: Plan = {
      id: `plan_${now}_${Math.random().toString(36).substr(2, 9)}`,
      goalId,
      steps: [],
      status: PlanStatus.PENDING,
      createdAt: now,
      updatedAt: now,
      metadata: {}
    };
    
    this.plans.set(plan.id, plan);
    
    // Update goal status
    goalDecomposer.updateGoalStatus(goalId, GoalStatus.IN_PROGRESS);
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'plan_created',
        plan: { ...plan, steps: [] }, // Avoid large objects in memory
        goalId
      },
      tags: ['plan', 'created', plan.id, goalId],
      importance: 70,
      createdAt: now,
      metadata: {}
    });
    
    return plan;
  }

  /**
   * Add a step to a plan
   * 
   * @param planId ID of the plan to add a step to
   * @param description Description of the step
   * @param agentId ID of the agent responsible for the step
   * @param capabilityId ID of the capability to use
   * @param parameters Parameters for the capability
   * @param dependsOn Array of step IDs that must complete before this one
   * @returns The created step or null if plan not found
   */
  public addPlanStep(
    planId: string,
    description: string,
    agentId: string,
    capabilityId: string,
    parameters: Record<string, any> = {},
    dependsOn: string[] = []
  ): PlanStep | null {
    const plan = this.plans.get(planId);
    if (!plan) {
      return null;
    }
    
    const now = Date.now();
    const step: PlanStep = {
      id: `step_${now}_${Math.random().toString(36).substr(2, 9)}`,
      description,
      agentId,
      capabilityId,
      parameters,
      status: this.determineInitialStepStatus(dependsOn, plan),
      dependsOn,
      createdAt: now,
      updatedAt: now
    };
    
    plan.steps.push(step);
    plan.updatedAt = now;
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'plan_step_added',
        planId,
        step
      },
      tags: ['plan', 'step', 'added', planId, step.id],
      importance: 60,
      createdAt: now,
      metadata: {}
    });
    
    return step;
  }

  /**
   * Start execution of a plan
   * 
   * @param planId ID of the plan to start
   * @returns Updated plan or null if not found
   */
  public startPlan(planId: string): Plan | null {
    const plan = this.plans.get(planId);
    if (!plan) {
      return null;
    }
    
    const now = Date.now();
    plan.status = PlanStatus.IN_PROGRESS;
    plan.updatedAt = now;
    
    // Update step statuses based on dependencies
    for (const step of plan.steps) {
      if (step.dependsOn.length === 0) {
        step.status = PlanStepStatus.IN_PROGRESS;
        step.startedAt = now;
        
        // Notify agent to execute step
        this.notifyAgentForStep(step, plan);
      }
    }
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'plan_started',
        planId
      },
      tags: ['plan', 'started', planId],
      importance: 70,
      createdAt: now,
      metadata: {}
    });
    
    return plan;
  }

  /**
   * Update the status of a plan step
   * 
   * @param planId ID of the plan containing the step
   * @param stepId ID of the step to update
   * @param status New status for the step
   * @param result Optional result data from step execution
   * @param error Optional error message if step failed
   * @returns Updated plan or null if not found
   */
  public updateStepStatus(
    planId: string,
    stepId: string,
    status: PlanStepStatus,
    result?: any,
    error?: string
  ): Plan | null {
    const plan = this.plans.get(planId);
    if (!plan) {
      return null;
    }
    
    const step = plan.steps.find(s => s.id === stepId);
    if (!step) {
      return null;
    }
    
    const now = Date.now();
    const oldStatus = step.status;
    step.status = status;
    step.updatedAt = now;
    
    // Update additional fields based on status
    if (status === PlanStepStatus.IN_PROGRESS && !step.startedAt) {
      step.startedAt = now;
    } else if (
      (status === PlanStepStatus.COMPLETED || 
       status === PlanStepStatus.FAILED ||
       status === PlanStepStatus.CANCELLED) && 
      !step.completedAt
    ) {
      step.completedAt = now;
    }
    
    // Store result or error if provided
    if (result !== undefined) {
      step.result = result;
    }
    
    if (error !== undefined) {
      step.error = error;
    }
    
    // Update plan timestamp
    plan.updatedAt = now;
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'plan_step_updated',
        planId,
        stepId,
        oldStatus,
        newStatus: status,
        hasResult: result !== undefined,
        hasError: error !== undefined
      },
      tags: ['plan', 'step', 'updated', planId, stepId],
      importance: 60,
      createdAt: now,
      metadata: {}
    });
    
    // Check if step completion unblocks other steps
    if (status === PlanStepStatus.COMPLETED) {
      this.checkDependentSteps(plan, stepId);
    }
    
    // Check if plan is complete or failed
    this.updatePlanStatus(plan);
    
    return plan;
  }

  /**
   * Get a plan by ID
   * 
   * @param planId ID of the plan to retrieve
   * @returns The plan or null if not found
   */
  public getPlan(planId: string): Plan | null {
    return this.plans.get(planId) || null;
  }

  /**
   * Get all plans for a specific goal
   * 
   * @param goalId ID of the goal
   * @returns Array of plans for the goal
   */
  public getPlansForGoal(goalId: string): Plan[] {
    return Array.from(this.plans.values())
      .filter(plan => plan.goalId === goalId);
  }

  /**
   * Get all active plans
   * 
   * @returns Array of plans with IN_PROGRESS status
   */
  public getActivePlans(): Plan[] {
    return Array.from(this.plans.values())
      .filter(plan => plan.status === PlanStatus.IN_PROGRESS);
  }

  /**
   * Cancel a plan
   * 
   * @param planId ID of the plan to cancel
   * @returns Updated plan or null if not found
   */
  public cancelPlan(planId: string): Plan | null {
    const plan = this.plans.get(planId);
    if (!plan) {
      return null;
    }
    
    const now = Date.now();
    plan.status = PlanStatus.CANCELLED;
    plan.updatedAt = now;
    
    // Cancel all in-progress and pending steps
    for (const step of plan.steps) {
      if (
        step.status === PlanStepStatus.IN_PROGRESS ||
        step.status === PlanStepStatus.PENDING ||
        step.status === PlanStepStatus.BLOCKED
      ) {
        step.status = PlanStepStatus.CANCELLED;
        step.updatedAt = now;
        
        if (!step.completedAt) {
          step.completedAt = now;
        }
      }
    }
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'plan_cancelled',
        planId
      },
      tags: ['plan', 'cancelled', planId],
      importance: 70,
      createdAt: now,
      metadata: {}
    });
    
    return plan;
  }

  /**
   * Determine the initial status for a new step based on dependencies
   * 
   * @param dependsOn Array of step IDs this step depends on
   * @param plan The plan containing the steps
   * @returns The appropriate initial status
   */
  private determineInitialStepStatus(
    dependsOn: string[],
    plan: Plan
  ): PlanStepStatus {
    if (dependsOn.length === 0) {
      return plan.status === PlanStatus.IN_PROGRESS
        ? PlanStepStatus.IN_PROGRESS
        : PlanStepStatus.PENDING;
    }
    
    // Check if any dependencies are not completed
    const hasUncompletedDependencies = dependsOn.some(depId => {
      const depStep = plan.steps.find(s => s.id === depId);
      return !depStep || depStep.status !== PlanStepStatus.COMPLETED;
    });
    
    return hasUncompletedDependencies
      ? PlanStepStatus.BLOCKED
      : (plan.status === PlanStatus.IN_PROGRESS
          ? PlanStepStatus.IN_PROGRESS
          : PlanStepStatus.PENDING);
  }

  /**
   * Check if step completion unblocks other steps
   * 
   * @param plan The plan containing the steps
   * @param completedStepId ID of the step that was completed
   */
  private checkDependentSteps(plan: Plan, completedStepId: string): void {
    const now = Date.now();
    
    for (const step of plan.steps) {
      if (
        step.status === PlanStepStatus.BLOCKED &&
        step.dependsOn.includes(completedStepId)
      ) {
        // Check if all dependencies are now completed
        const allDependenciesCompleted = step.dependsOn.every(depId => {
          const depStep = plan.steps.find(s => s.id === depId);
          return depStep && depStep.status === PlanStepStatus.COMPLETED;
        });
        
        if (allDependenciesCompleted) {
          step.status = PlanStepStatus.IN_PROGRESS;
          step.startedAt = now;
          step.updatedAt = now;
          
          // Notify agent to execute step
          this.notifyAgentForStep(step, plan);
        }
      }
    }
  }

  /**
   * Update the overall plan status based on step statuses
   * 
   * @param plan The plan to update
   */
  private updatePlanStatus(plan: Plan): void {
    if (plan.status !== PlanStatus.IN_PROGRESS) {
      return; // Only update status for in-progress plans
    }
    
    const now = Date.now();
    
    // Check if all steps are completed
    const allCompleted = plan.steps.length > 0 && 
      plan.steps.every(step => step.status === PlanStepStatus.COMPLETED);
    
    // Check if any steps failed
    const anyFailed = plan.steps.some(step => step.status === PlanStepStatus.FAILED);
    
    if (allCompleted) {
      plan.status = PlanStatus.COMPLETED;
      plan.completedAt = now;
      plan.updatedAt = now;
      
      // Update goal status
      goalDecomposer.updateGoalStatus(plan.goalId, GoalStatus.COMPLETED);
      
      // Store in memory for context awareness
      memorySystem.storeShortTerm({
        type: 'context',
        content: {
          type: 'plan_completed',
          planId: plan.id
        },
        tags: ['plan', 'completed', plan.id],
        importance: 80,
        createdAt: now,
        metadata: {}
      });
    } else if (anyFailed) {
      plan.status = PlanStatus.FAILED;
      plan.updatedAt = now;
      
      // Store in memory for context awareness
      memorySystem.storeShortTerm({
        type: 'context',
        content: {
          type: 'plan_failed',
          planId: plan.id
        },
        tags: ['plan', 'failed', plan.id],
        importance: 80,
        createdAt: now,
        metadata: {}
      });
    }
  }

  /**
   * Notify an agent to execute a step
   * 
   * @param step The step to execute
   * @param plan The plan containing the step
   */
  private notifyAgentForStep(step: PlanStep, plan: Plan): void {
    // Send message to agent via event bus
    agentEventBus.publish({
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      sender: 'universal_planner',
      recipient: step.agentId,
      type: AgentMessageType.COMMAND,
      content: {
        command: 'execute_step',
        planId: plan.id,
        stepId: step.id,
        capability: step.capabilityId,
        parameters: step.parameters,
        description: step.description
      },
      priority: AgentMessagePriority.HIGH
    });
  }
}

export const universalPlanner = UniversalPlanner.getInstance();
