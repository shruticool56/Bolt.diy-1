/**
 * Core types for the Autonomous Cognition Core and Agent Communication
 */

// Base Agent Interface
export interface Agent {
  id: string;
  name: string;
  description: string;
  capabilities: AgentCapability[];
  status: AgentStatus;
  initialize: () => Promise<void>;
  shutdown: () => Promise<void>;
  handleMessage: (message: AgentMessage) => Promise<AgentMessage | null>;
}

// Agent Capability
export interface AgentCapability {
  id: string;
  name: string;
  description: string;
  parameters: AgentCapabilityParameter[];
}

// Agent Capability Parameter
export interface AgentCapabilityParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  description: string;
  required: boolean;
  default?: any;
}

// Agent Status
export enum AgentStatus {
  INITIALIZING = 'initializing',
  IDLE = 'idle',
  BUSY = 'busy',
  ERROR = 'error',
  SHUTDOWN = 'shutdown'
}

// Agent Message
export interface AgentMessage {
  id: string;
  timestamp: number;
  sender: string;
  recipient: string | null; // null for broadcast
  type: AgentMessageType;
  content: any;
  correlationId?: string; // For request/response pattern
  priority: AgentMessagePriority;
  ttl?: number; // Time to live in milliseconds
}

// Agent Message Type
export enum AgentMessageType {
  REQUEST = 'request',
  RESPONSE = 'response',
  EVENT = 'event',
  ERROR = 'error',
  COMMAND = 'command',
  STATUS = 'status'
}

// Agent Message Priority
export enum AgentMessagePriority {
  LOW = 'low',
  NORMAL = 'normal',
  HIGH = 'high',
  CRITICAL = 'critical'
}

// Goal Interface
export interface Goal {
  id: string;
  description: string;
  priority: GoalPriority;
  status: GoalStatus;
  parentGoalId?: string;
  subGoals: Goal[];
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  metadata: Record<string, any>;
}

// Goal Priority
export enum GoalPriority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

// Goal Status
export enum GoalStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

// Plan Interface
export interface Plan {
  id: string;
  goalId: string;
  steps: PlanStep[];
  status: PlanStatus;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  metadata: Record<string, any>;
}

// Plan Step
export interface PlanStep {
  id: string;
  description: string;
  agentId: string;
  capabilityId: string;
  parameters: Record<string, any>;
  status: PlanStepStatus;
  dependsOn: string[]; // IDs of steps that must complete before this one
  createdAt: number;
  updatedAt: number;
  startedAt?: number;
  completedAt?: number;
  result?: any;
  error?: string;
}

// Plan Step Status
export enum PlanStepStatus {
  PENDING = 'pending',
  BLOCKED = 'blocked',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

// Plan Status
export enum PlanStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

// Memory Item
export interface MemoryItem {
  id: string;
  type: MemoryItemType;
  content: any;
  tags: string[];
  importance: number; // 0-100
  createdAt: number;
  expiresAt?: number; // For short-term memory
  metadata: Record<string, any>;
}

// Memory Item Type
export enum MemoryItemType {
  FACT = 'fact',
  EXPERIENCE = 'experience',
  KNOWLEDGE = 'knowledge',
  CONTEXT = 'context'
}

// Feedback Item
export interface FeedbackItem {
  id: string;
  agentId: string;
  actionId: string;
  success: boolean;
  score: number; // -100 to 100
  reason: string;
  createdAt: number;
  metadata: Record<string, any>;
}
