/**
 * SentienceAI Cognitive Kernel - Shared Memory Bus
 * 
 * This module implements the Shared Memory Bus:
 * - Provides centralized communication between agents
 * - Enables memory sharing and synchronization
 * - Supports pub/sub pattern for event distribution
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../memory';

export enum MessageType {
  REQUEST = 'request',
  RESPONSE = 'response',
  EVENT = 'event',
  COMMAND = 'command',
  STATUS = 'status',
  ERROR = 'error'
}

export interface Message {
  id: string;
  type: MessageType;
  sender: string;
  recipient?: string; // Optional for broadcasts
  topic: string;
  payload: any;
  timestamp: number;
  correlationId?: string; // For request/response pairs
  ttl?: number; // Time-to-live in milliseconds
  priority?: 'low' | 'normal' | 'high' | 'critical';
  metadata?: any;
}

export interface Subscription {
  id: string;
  agentId: string;
  topic: string;
  pattern?: boolean; // If true, topic is treated as a pattern
  callback: (message: Message) => void;
  createdAt: number;
}

export class SharedMemoryBus extends EventEmitter {
  private static instance: SharedMemoryBus;
  private memoryManager: MemoryManager;
  private subscriptions: Map<string, Subscription> = new Map();
  private messageHistory: Map<string, Message[]> = new Map();
  private historyLimit: number = 1000; // Maximum messages per topic
  
  private constructor(memoryManager?: MemoryManager) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
  }

  /**
   * Gets the singleton instance
   */
  public static getInstance(memoryManager?: MemoryManager): SharedMemoryBus {
    if (!SharedMemoryBus.instance) {
      SharedMemoryBus.instance = new SharedMemoryBus(memoryManager);
    }
    return SharedMemoryBus.instance;
  }

  /**
   * Publishes a message to the bus
   */
  public publish(message: Omit<Message, 'id' | 'timestamp'>): Message {
    const fullMessage: Message = {
      ...message,
      id: uuidv4(),
      timestamp: Date.now()
    };
    
    // Store in history
    this.storeMessage(fullMessage);
    
    // Find matching subscriptions
    const matchingSubscriptions = this.findMatchingSubscriptions(fullMessage);
    
    // Deliver to subscribers
    for (const subscription of matchingSubscriptions) {
      try {
        subscription.callback(fullMessage);
      } catch (error) {
        console.error(`Error delivering message to subscriber ${subscription.id}:`, error);
      }
    }
    
    // Emit event
    this.emit('messageSent', fullMessage);
    
    return fullMessage;
  }

  /**
   * Stores a message in history
   */
  private storeMessage(message: Message): void {
    const { topic } = message;
    
    if (!this.messageHistory.has(topic)) {
      this.messageHistory.set(topic, []);
    }
    
    const history = this.messageHistory.get(topic)!;
    
    // Add to history
    history.push(message);
    
    // Trim if exceeds limit
    if (history.length > this.historyLimit) {
      history.splice(0, history.length - this.historyLimit);
    }
    
    // Persist to storage if not ephemeral
    if (!message.ttl) {
      this.persistMessage(message).catch(err => {
        console.error('Error persisting message:', err);
      });
    }
  }

  /**
   * Persists a message to storage
   */
  private async persistMessage(message: Message): Promise<void> {
    await this.memoryManager.storeMemory({
      id: message.id,
      type: MemoryType.SHORT_TERM,
      key: `message:${message.topic}:${message.id}`,
      value: message,
      metadata: {
        type: message.type,
        sender: message.sender,
        recipient: message.recipient,
        topic: message.topic,
        correlationId: message.correlationId
      },
      timestamp: message.timestamp,
      expiration: message.ttl ? message.timestamp + message.ttl : undefined
    });
  }

  /**
   * Finds subscriptions matching a message
   */
  private findMatchingSubscriptions(message: Message): Subscription[] {
    const { topic, recipient } = message;
    const result: Subscription[] = [];
    
    for (const subscription of this.subscriptions.values()) {
      // Skip if message has a specific recipient and it's not this subscriber
      if (recipient && subscription.agentId !== recipient) {
        continue;
      }
      
      // Check if topic matches
      if (subscription.pattern) {
        // Treat topic as a pattern (simple wildcard matching)
        const pattern = subscription.topic.replace('*', '.*');
        const regex = new RegExp(`^${pattern}$`);
        if (regex.test(topic)) {
          result.push(subscription);
        }
      } else {
        // Exact topic match
        if (subscription.topic === topic) {
          result.push(subscription);
        }
      }
    }
    
    return result;
  }

  /**
   * Subscribes to messages on a topic
   */
  public subscribe(
    agentId: string,
    topic: string,
    callback: (message: Message) => void,
    pattern: boolean = false
  ): Subscription {
    const subscription: Subscription = {
      id: uuidv4(),
      agentId,
      topic,
      pattern,
      callback,
      createdAt: Date.now()
    };
    
    this.subscriptions.set(subscription.id, subscription);
    this.emit('subscriptionCreated', subscription);
    
    return subscription;
  }

  /**
   * Unsubscribes from a topic
   */
  public unsubscribe(subscriptionId: string): boolean {
    const removed = this.subscriptions.delete(subscriptionId);
    
    if (removed) {
      this.emit('subscriptionRemoved', subscriptionId);
    }
    
    return removed;
  }

  /**
   * Sends a request and waits for a response
   */
  public async request(
    sender: string,
    recipient: string,
    topic: string,
    payload: any,
    timeout: number = 5000,
    priority: 'low' | 'normal' | 'high' | 'critical' = 'normal'
  ): Promise<Message> {
    return new Promise<Message>((resolve, reject) => {
      const correlationId = uuidv4();
      
      // Set up response handler
      const responseSubscription = this.subscribe(
        sender,
        `response:${correlationId}`,
        (response) => {
          // Clean up subscription
          this.unsubscribe(responseSubscription.id);
          
          // Clear timeout
          clearTimeout(timeoutId);
          
          // Resolve with response
          resolve(response);
        }
      );
      
      // Set up timeout
      const timeoutId = setTimeout(() => {
        // Clean up subscription
        this.unsubscribe(responseSubscription.id);
        
        // Reject with timeout error
        reject(new Error(`Request timed out after ${timeout}ms`));
      }, timeout);
      
      // Send request
      this.publish({
        type: MessageType.REQUEST,
        sender,
        recipient,
        topic,
        payload,
        correlationId,
        priority,
        ttl: timeout
      });
    });
  }

  /**
   * Sends a response to a request
   */
  public respond(
    requestMessage: Message,
    sender: string,
    payload: any,
    error?: any
  ): Message {
    if (!requestMessage.correlationId) {
      throw new Error('Cannot respond to a message without a correlationId');
    }
    
    return this.publish({
      type: error ? MessageType.ERROR : MessageType.RESPONSE,
      sender,
      recipient: requestMessage.sender,
      topic: `response:${requestMessage.correlationId}`,
      payload: error || payload,
      correlationId: requestMessage.correlationId
    });
  }

  /**
   * Broadcasts an event to all subscribers
   */
  public broadcast(
    sender: string,
    topic: string,
    payload: any,
    priority: 'low' | 'normal' | 'high' | 'critical' = 'normal'
  ): Message {
    return this.publish({
      type: MessageType.EVENT,
      sender,
      topic,
      payload,
      priority
    });
  }

  /**
   * Gets message history for a topic
   */
  public getMessageHistory(topic: string): Message[] {
    return this.messageHistory.get(topic) || [];
  }

  /**
   * Gets all subscriptions
   */
  public getSubscriptions(): Subscription[] {
    return Array.from(this.subscriptions.values());
  }

  /**
   * Gets subscriptions for an agent
   */
  public getAgentSubscriptions(agentId: string): Subscription[] {
    return this.getSubscriptions().filter(sub => sub.agentId === agentId);
  }

  /**
   * Sets the history limit
   */
  public setHistoryLimit(limit: number): void {
    this.historyLimit = limit;
    
    // Trim existing histories
    for (const [topic, history] of this.messageHistory.entries()) {
      if (history.length > limit) {
        this.messageHistory.set(topic, history.slice(history.length - limit));
      }
    }
  }

  /**
   * Clears message history
   */
  public clearHistory(): void {
    this.messageHistory.clear();
    this.emit('historyCleared');
  }
}

export default SharedMemoryBus;
