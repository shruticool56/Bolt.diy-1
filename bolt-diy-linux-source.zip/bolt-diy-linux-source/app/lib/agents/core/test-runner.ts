/**
 * Core Module Integration Test Runner
 * 
 * This file executes the integration tests for the Autonomous Cognition Core.
 */

import { testCoreModules } from './integration-test';

// Run the integration tests
console.log('Starting Autonomous Cognition Core validation...');
testCoreModules()
  .then(() => {
    console.log('Validation completed successfully!');
  })
  .catch((error) => {
    console.error('Validation failed:', error);
  });
