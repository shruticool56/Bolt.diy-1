/**
 * Meta-Cognition Agent Implementation for Autonomous Cognition Core
 * 
 * Monitors and adjusts the thinking process of the agent system.
 */

import { Agent, AgentStatus, AgentMessage, AgentMessageType, AgentMessagePriority } from './types';
import { memorySystem } from './memory';
import { feedbackLoop } from './feedback-loop';
import { agentEventBus } from './event-bus';

/**
 * Meta-Cognition Agent for the Autonomous Cognition Core
 * 
 * Monitors the performance and behavior of other agents, adjusts strategies,
 * and provides self-improvement mechanisms for the overall system.
 */
class MetaCognitionAgent implements Agent {
  private static instance: MetaCognitionAgent;
  private _id: string = 'meta_cognition_agent';
  private _name: string = 'Meta-Cognition Agent';
  private _description: string = 'Monitors and adjusts the thinking process of the agent system';
  private _status: AgentStatus = AgentStatus.INITIALIZING;
  private _subscriptionId: string | null = null;
  
  // Performance monitoring
  private agentPerformance: Map<string, {
    successRate: number;
    averageResponseTime: number;
    errorRate: number;
    lastUpdated: number;
  }> = new Map();
  
  // Strategy adjustment thresholds
  private readonly PERFORMANCE_CHECK_INTERVAL = 300000; // 5 minutes
  private readonly LOW_SUCCESS_THRESHOLD = 0.6; // 60%
  private readonly HIGH_ERROR_THRESHOLD = 0.3; // 30%
  private readonly SLOW_RESPONSE_THRESHOLD = 5000; // 5 seconds
  
  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the meta-cognition agent
   */
  public static getInstance(): MetaCognitionAgent {
    if (!MetaCognitionAgent.instance) {
      MetaCognitionAgent.instance = new MetaCognitionAgent();
    }
    return MetaCognitionAgent.instance;
  }

  /**
   * Agent ID
   */
  get id(): string {
    return this._id;
  }

  /**
   * Agent name
   */
  get name(): string {
    return this._name;
  }

  /**
   * Agent description
   */
  get description(): string {
    return this._description;
  }

  /**
   * Agent capabilities
   */
  get capabilities(): any[] {
    return [
      {
        id: 'monitor_performance',
        name: 'Monitor Agent Performance',
        description: 'Monitors the performance metrics of other agents',
        parameters: []
      },
      {
        id: 'adjust_strategy',
        name: 'Adjust Agent Strategy',
        description: 'Adjusts the strategy of an agent based on performance',
        parameters: [
          {
            name: 'agentId',
            type: 'string',
            description: 'ID of the agent to adjust',
            required: true
          },
          {
            name: 'strategy',
            type: 'string',
            description: 'New strategy to apply',
            required: true
          },
          {
            name: 'parameters',
            type: 'object',
            description: 'Parameters for the strategy',
            required: false
          }
        ]
      },
      {
        id: 'analyze_thinking',
        name: 'Analyze Thinking Process',
        description: 'Analyzes the thinking process of the agent system',
        parameters: [
          {
            name: 'timeframe',
            type: 'number',
            description: 'Timeframe in milliseconds to analyze',
            required: false,
            default: 3600000 // 1 hour
          }
        ]
      }
    ];
  }

  /**
   * Agent status
   */
  get status(): AgentStatus {
    return this._status;
  }

  /**
   * Initialize the agent
   */
  public async initialize(): Promise<void> {
    // Subscribe to agent messages
    this._subscriptionId = agentEventBus.subscribe(
      this._id,
      {}, // No filter, receive all messages
      this.handleMessage.bind(this)
    );
    
    // Set up periodic performance checks
    setInterval(() => this.checkSystemPerformance(), this.PERFORMANCE_CHECK_INTERVAL);
    
    this._status = AgentStatus.IDLE;
    
    // Store in memory for context awareness
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'agent_initialized',
        agentId: this._id,
        name: this._name
      },
      tags: ['agent', 'initialized', this._id],
      importance: 70,
      createdAt: Date.now(),
      metadata: {}
    });
    
    return Promise.resolve();
  }

  /**
   * Shut down the agent
   */
  public async shutdown(): Promise<void> {
    // Unsubscribe from event bus
    if (this._subscriptionId) {
      agentEventBus.unsubscribe(this._subscriptionId);
      this._subscriptionId = null;
    }
    
    this._status = AgentStatus.SHUTDOWN;
    
    return Promise.resolve();
  }

  /**
   * Handle incoming messages
   * 
   * @param message The message to handle
   * @returns Response message or null if no response
   */
  public async handleMessage(message: AgentMessage): Promise<AgentMessage | null> {
    // Skip messages sent by this agent to avoid loops
    if (message.sender === this._id) {
      return null;
    }
    
    // Update performance metrics for the sender
    this.updateAgentPerformance(message);
    
    // Handle specific message types
    if (message.type === AgentMessageType.REQUEST && message.recipient === this._id) {
      this._status = AgentStatus.BUSY;
      
      try {
        // Handle capability requests
        if (message.content.capability === 'monitor_performance') {
          const response = this.handleMonitorPerformance();
          this._status = AgentStatus.IDLE;
          return this.createResponseMessage(message, response);
        } else if (message.content.capability === 'adjust_strategy') {
          const { agentId, strategy, parameters } = message.content.parameters;
          const response = await this.handleAdjustStrategy(agentId, strategy, parameters);
          this._status = AgentStatus.IDLE;
          return this.createResponseMessage(message, response);
        } else if (message.content.capability === 'analyze_thinking') {
          const timeframe = message.content.parameters?.timeframe || 3600000;
          const response = await this.handleAnalyzeThinking(timeframe);
          this._status = AgentStatus.IDLE;
          return this.createResponseMessage(message, response);
        }
      } catch (error) {
        this._status = AgentStatus.ERROR;
        return this.createErrorMessage(message, error instanceof Error ? error.message : String(error));
      }
    }
    
    // No response for other message types
    return null;
  }

  /**
   * Handle monitor_performance capability
   * 
   * @returns Performance metrics for all agents
   */
  private handleMonitorPerformance(): any {
    return {
      agentPerformance: Object.fromEntries(this.agentPerformance)
    };
  }

  /**
   * Handle adjust_strategy capability
   * 
   * @param agentId ID of the agent to adjust
   * @param strategy New strategy to apply
   * @param parameters Parameters for the strategy
   * @returns Result of the strategy adjustment
   */
  private async handleAdjustStrategy(
    agentId: string,
    strategy: string,
    parameters: Record<string, any> = {}
  ): Promise<any> {
    // Send strategy adjustment message to the target agent
    const response = await this.sendStrategyAdjustment(agentId, strategy, parameters);
    
    // Record the adjustment in memory
    memorySystem.storeShortTerm({
      type: 'context',
      content: {
        type: 'strategy_adjusted',
        agentId,
        strategy,
        parameters,
        success: !!response
      },
      tags: ['strategy', 'adjusted', agentId],
      importance: 70,
      createdAt: Date.now(),
      metadata: {}
    });
    
    return {
      success: !!response,
      agentId,
      strategy,
      response
    };
  }

  /**
   * Handle analyze_thinking capability
   * 
   * @param timeframe Timeframe in milliseconds to analyze
   * @returns Analysis of the thinking process
   */
  private async handleAnalyzeThinking(timeframe: number): Promise<any> {
    const now = Date.now();
    const startTime = now - timeframe;
    
    // Get relevant memory items
    const contextItems = memorySystem.searchByContent(
      /agent|plan|goal|strategy/i,
      {
        memoryTypes: ['context'],
        limit: 1000
      }
    ).filter(item => item.createdAt >= startTime);
    
    // Get feedback items
    const feedbackItems = Array.from(this.agentPerformance.entries())
      .map(([agentId, perf]) => ({
        agentId,
        performance: perf
      }));
    
    // Analyze thinking patterns
    const patterns = this.analyzeThinkingPatterns(contextItems);
    
    // Generate recommendations
    const recommendations = this.generateRecommendations(patterns, feedbackItems);
    
    return {
      timeframe,
      patterns,
      recommendations,
      agentPerformance: Object.fromEntries(this.agentPerformance)
    };
  }

  /**
   * Update agent performance metrics based on a message
   * 
   * @param message The message to analyze
   */
  private updateAgentPerformance(message: AgentMessage): void {
    const sender = message.sender;
    
    // Skip system messages
    if (sender === 'system' || !sender) {
      return;
    }
    
    // Get or create performance record
    if (!this.agentPerformance.has(sender)) {
      this.agentPerformance.set(sender, {
        successRate: 1.0,
        averageResponseTime: 0,
        errorRate: 0,
        lastUpdated: Date.now()
      });
    }
    
    const performance = this.agentPerformance.get(sender)!;
    
    // Update metrics based on message type
    if (message.type === AgentMessageType.RESPONSE) {
      // Update success rate (simple moving average)
      const isSuccess = !message.content.error;
      performance.successRate = performance.successRate * 0.9 + (isSuccess ? 0.1 : 0);
      
      // Update response time if correlation ID is available
      if (message.correlationId) {
        const requestMessage = memorySystem.searchByContent(
          message.correlationId,
          { limit: 1 }
        )[0];
        
        if (requestMessage) {
          const responseTime = message.timestamp - requestMessage.createdAt;
          performance.averageResponseTime = 
            performance.averageResponseTime * 0.9 + responseTime * 0.1;
        }
      }
    } else if (message.type === AgentMessageType.ERROR) {
      // Update error rate (simple moving average)
      performance.errorRate = performance.errorRate * 0.9 + 0.1;
    }
    
    performance.lastUpdated = Date.now();
  }

  /**
   * Check system performance and adjust strategies if needed
   */
  private checkSystemPerformance(): void {
    const now = Date.now();
    
    // Check each agent's performance
    for (const [agentId, performance] of this.agentPerformance.entries()) {
      // Skip recently updated agents
      if (now - performance.lastUpdated > this.PERFORMANCE_CHECK_INTERVAL * 2) {
        continue;
      }
      
      // Check for performance issues
      const hasLowSuccess = performance.successRate < this.LOW_SUCCESS_THRESHOLD;
      const hasHighError = performance.errorRate > this.HIGH_ERROR_THRESHOLD;
      const hasSlowResponse = performance.averageResponseTime > this.SLOW_RESPONSE_THRESHOLD;
      
      if (hasLowSuccess || hasHighError || hasSlowResponse) {
        // Determine appropriate strategy adjustment
        let strategy = '';
        const parameters: Record<string, any> = {};
        
        if (hasLowSuccess) {
          strategy = 'improve_success_rate';
          parameters.currentRate = performance.successRate;
          parameters.threshold = this.LOW_SUCCESS_THRESHOLD;
        } else if (hasHighError) {
          strategy = 'reduce_error_rate';
          parameters.currentRate = performance.errorRate;
          parameters.threshold = this.HIGH_ERROR_THRESHOLD;
        } else if (hasSlowResponse) {
          strategy = 'improve_response_time';
          parameters.currentTime = performance.averageResponseTime;
          parameters.threshold = this.SLOW_RESPONSE_THRESHOLD;
        }
        
        // Apply strategy adjustment
        this.sendStrategyAdjustment(agentId, strategy, parameters);
      }
    }
  }

  /**
   * Send a strategy adjustment message to an agent
   * 
   * @param agentId ID of the agent to adjust
   * @param strategy Strategy to apply
   * @param parameters Parameters for the strategy
   * @returns Promise that resolves with the response or null if no response
   */
  private async sendStrategyAdjustment(
    agentId: string,
    strategy: string,
    parameters: Record<string, any> = {}
  ): Promise<any> {
    return new Promise((resolve) => {
      const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Set up one-time listener for response
      const subscriptionId = agentEventBus.subscribe(
        this._id,
        {
          sender: agentId,
          type: AgentMessageType.RESPONSE
        },
        async (response) => {
          if (response.correlationId === messageId) {
            // Unsubscribe after receiving response
            agentEventBus.unsubscribe(subscriptionId);
            resolve(response.content);
          }
        }
      );
      
      // Send strategy adjustment message
      agentEventBus.publish({
        id: messageId,
        timestamp: Date.now(),
        sender: this._id,
        recipient: agentId,
        type: AgentMessageType.COMMAND,
        content: {
          command: 'adjust_strategy',
          strategy,
          parameters
        },
        priority: AgentMessagePriority.HIGH
      });
      
      // Set timeout to resolve with null if no response
      setTimeout(() => {
        agentEventBus.unsubscribe(subscriptionId);
        resolve(null);
      }, 10000); // 10 second timeout
    });
  }

  /**
   * Analyze thinking patterns from context items
   * 
   * @param contextItems Array of context memory items
   * @returns Analysis of thinking patterns
   */
  private analyzeThinkingPatterns(contextItems: any[]): any {
    // This is a simplified implementation
    // In a real system, this would use more sophisticated analysis
    
    // Count event types
    const eventTypeCounts: Record<string, number> = {};
    for (const item of contextItems) {
      const eventType = item.content.type;
      eventTypeCounts[eventType] = (eventTypeCounts[eventType] || 0) + 1;
    }
    
    // Identify common sequences
    const sequences: Record<string, number> = {};
    for (let i = 0; i < contextItems.length - 1; i++) {
      const current = contextItems[i].content.type;
      const next = contextItems[i + 1].content.type;
      const sequence = `${current} -> ${next}`;
      sequences[sequence] = (sequences[sequence] || 0) + 1;
    }
    
    // Calculate time between related events
    const timeBetweenEvents: Record<string, number[]> = {};
    for (let i = 0; i < contextItems.length - 1; i++) {
      const current = contextItems[i];
      
      // Look for related events (e.g., created -> updated)
      for (let j = i + 1; j < contextItems.length; j++) {
        const next = contextItems[j];
        
        if (
          current.content.type.includes('created') &&
          next.content.type.includes('updated') &&
          current.content.goalId === next.content.goalId
        ) {
          const key = `${current.content.type} -> ${next.content.type}`;
          const timeDiff = next.createdAt - current.createdAt;
          
          if (!timeBetweenEvents[key]) {
            timeBetweenEvents[key] = [];
          }
          
          timeBetweenEvents[key].push(timeDiff);
          break; // Only count first occurrence
        }
      }
    }
    
    // Calculate averages for time between events
    const averageTimeBetweenEvents: Record<string, number> = {};
    for (const [key, times] of Object.entries(timeBetweenEvents)) {
      if (times.length > 0) {
        const sum = times.reduce((a, b) => a + b, 0);
        averageTimeBetweenEvents[key] = sum / times.length;
      }
    }
    
    return {
      eventTypeCounts,
      commonSequences: Object.entries(sequences)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10),
      averageTimeBetweenEvents
    };
  }

  /**
   * Generate recommendations based on thinking patterns and agent performance
   * 
   * @param patterns Thinking patterns analysis
   * @param agentPerformance Agent performance metrics
   * @returns Array of recommendations
   */
  private generateRecommendations(
    patterns: any,
    agentPerformance: Array<{
      agentId: string;
      performance: {
        successRate: number;
        averageResponseTime: number;
        errorRate: number;
      };
    }>
  ): Array<{
    type: string;
    description: string;
    priority: 'low' | 'medium' | 'high';
    targetAgentId?: string;
  }> {
    const recommendations = [];
    
    // Check for low-performing agents
    for (const { agentId, performance } of agentPerformance) {
      if (performance.successRate < this.LOW_SUCCESS_THRESHOLD) {
        recommendations.push({
          type: 'agent_improvement',
          description: `Agent ${agentId} has low success rate (${(performance.successRate * 100).toFixed(1)}%). Consider reviewing its implementation or adjusting its strategy.`,
          priority: 'high',
          targetAgentId: agentId
        });
      }
      
      if (performance.errorRate > this.HIGH_ERROR_THRESHOLD) {
        recommendations.push({
          type: 'error_reduction',
          description: `Agent ${agentId} has high error rate (${(performance.errorRate * 100).toFixed(1)}%). Consider adding error handling or fallback mechanisms.`,
          priority: 'high',
          targetAgentId: agentId
        });
      }
      
      if (performance.averageResponseTime > this.SLOW_RESPONSE_THRESHOLD) {
        recommendations.push({
          type: 'performance_optimization',
          description: `Agent ${agentId} has slow response time (${performance.averageResponseTime.toFixed(0)}ms). Consider optimizing its operations or adding caching.`,
          priority: 'medium',
          targetAgentId: agentId
        });
      }
    }
    
    // Check for inefficient thinking patterns
    if (patterns.averageTimeBetweenEvents) {
      for (const [key, time] of Object.entries(patterns.averageTimeBetweenEvents)) {
        if (time > 5000) { // 5 seconds
          recommendations.push({
            type: 'process_optimization',
            description: `Long delay (${(time as number / 1000).toFixed(1)}s) between events: ${key}. Consider optimizing this process flow.`,
            priority: 'medium'
          });
        }
      }
    }
    
    return recommendations;
  }

  /**
   * Create a response message
   * 
   * @param requestMessage Original request message
   * @param content Response content
   * @returns Response message
   */
  private createResponseMessage(
    requestMessage: AgentMessage,
    content: any
  ): AgentMessage {
    return {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      sender: this._id,
      recipient: requestMessage.sender,
      type: AgentMessageType.RESPONSE,
      content,
      correlationId: requestMessage.id,
      priority: requestMessage.priority
    };
  }

  /**
   * Create an error message
   * 
   * @param requestMessage Original request message
   * @param errorMessage Error message
   * @returns Error message
   */
  private createErrorMessage(
    requestMessage: AgentMessage,
    errorMessage: string
  ): AgentMessage {
    return {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      sender: this._id,
      recipient: requestMessage.sender,
      type: AgentMessageType.ERROR,
      content: {
        error: errorMessage
      },
      correlationId: requestMessage.id,
      priority: requestMessage.priority
    };
  }
}

export const metaCognitionAgent = MetaCognitionAgent.getInstance();
