/**
 * SentienceAI Cognitive Kernel - Code Self-Editor
 * 
 * This module implements the Code Self-Editor:
 * - Uses code-specialized LLMs to rewrite inefficient or failing code paths
 * - Inserts or removes functionality based on learned goals
 * - Re-optimizes based on user success patterns
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal } from '../execution-journal';
import { AutonomousExperienceLogger, TaskComparison } from '../autonomous-experience-logger';

export interface CodeChangeRequest {
  id: string;
  timestamp: number;
  taskId: string;
  filePath: string;
  reason: string;
  type: 'fix' | 'optimize' | 'enhance' | 'refactor';
  priority: 'low' | 'medium' | 'high' | 'critical';
  context: {
    errorMessage?: string;
    stackTrace?: string;
    performance?: any;
    userFeedback?: any;
  };
}

export interface CodeChange {
  id: string;
  requestId: string;
  timestamp: number;
  filePath: string;
  originalCode: string;
  modifiedCode: string;
  diffSummary: string;
  changeReason: string;
  changeType: 'fix' | 'optimize' | 'enhance' | 'refactor';
  status: 'pending' | 'applied' | 'reverted' | 'failed';
  testResults?: any;
}

export class CodeSelfEditor extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private experienceLogger: AutonomousExperienceLogger;
  private changeRequests: Map<string, CodeChangeRequest> = new Map();
  private codeChanges: Map<string, CodeChange> = new Map();
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    experienceLogger?: AutonomousExperienceLogger
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.experienceLogger = experienceLogger || new AutonomousExperienceLogger();
  }

  /**
   * Creates a code change request
   */
  public async createChangeRequest(
    taskId: string,
    filePath: string,
    reason: string,
    type: 'fix' | 'optimize' | 'enhance' | 'refactor',
    priority: 'low' | 'medium' | 'high' | 'critical',
    context: any = {}
  ): Promise<CodeChangeRequest> {
    const request: CodeChangeRequest = {
      id: uuidv4(),
      timestamp: Date.now(),
      taskId,
      filePath,
      reason,
      type,
      priority,
      context
    };
    
    // Store in memory
    this.changeRequests.set(request.id, request);
    
    // Persist to storage
    await this.persistChangeRequest(request);
    
    this.emit('changeRequestCreated', request);
    return request;
  }

  /**
   * Persists a change request to storage
   */
  private async persistChangeRequest(request: CodeChangeRequest): Promise<void> {
    await this.memoryManager.storeMemory({
      id: request.id,
      type: MemoryType.LONG_TERM,
      key: `code_change_request:${request.taskId}:${request.id}`,
      value: request,
      metadata: {
        taskId: request.taskId,
        filePath: request.filePath,
        type: request.type,
        priority: request.priority
      },
      timestamp: request.timestamp
    });
  }

  /**
   * Processes a code change request
   */
  public async processChangeRequest(requestId: string): Promise<CodeChange | null> {
    const request = this.changeRequests.get(requestId);
    if (!request) {
      throw new Error(`Change request with ID ${requestId} not found`);
    }
    
    try {
      // Log the start of processing
      await this.executionJournal.logInfo(
        request.taskId,
        `Processing code change request: ${request.id}`,
        { request }
      );
      
      // Create a before snapshot
      const beforeSnapshot = await this.experienceLogger.createBeforeSnapshot(
        request.taskId,
        { changeRequest: request }
      );
      
      // Read the original code
      const originalCode = await this.readFile(request.filePath);
      
      // Generate the modified code
      const { modifiedCode, diffSummary } = await this.generateCodeChange(
        request,
        originalCode
      );
      
      // Create the code change
      const codeChange: CodeChange = {
        id: uuidv4(),
        requestId: request.id,
        timestamp: Date.now(),
        filePath: request.filePath,
        originalCode,
        modifiedCode,
        diffSummary,
        changeReason: request.reason,
        changeType: request.type,
        status: 'pending'
      };
      
      // Store in memory
      this.codeChanges.set(codeChange.id, codeChange);
      
      // Persist to storage
      await this.persistCodeChange(codeChange);
      
      // Apply the change
      const applied = await this.applyCodeChange(codeChange);
      
      if (applied) {
        // Update status
        codeChange.status = 'applied';
        
        // Create an after snapshot
        const afterSnapshot = await this.experienceLogger.createAfterSnapshot(
          request.taskId,
          { changeRequest: request, codeChange }
        );
        
        // Compare snapshots
        const comparison = await this.experienceLogger.compareSnapshots(
          beforeSnapshot,
          afterSnapshot
        );
        
        // Update the code change with test results
        codeChange.testResults = {
          comparison,
          metrics: comparison.metrics
        };
        
        // Update in memory
        this.codeChanges.set(codeChange.id, codeChange);
        
        // Update in storage
        await this.persistCodeChange(codeChange);
      } else {
        // Update status
        codeChange.status = 'failed';
        
        // Update in memory
        this.codeChanges.set(codeChange.id, codeChange);
        
        // Update in storage
        await this.persistCodeChange(codeChange);
      }
      
      this.emit('changeProcessed', codeChange);
      return codeChange;
    } catch (error) {
      // Log the error
      await this.executionJournal.logError(
        request.taskId,
        error
      );
      
      this.emit('changeProcessingFailed', {
        requestId,
        error
      });
      
      return null;
    }
  }

  /**
   * Reads a file
   */
  private async readFile(filePath: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
          reject(err);
          return;
        }
        resolve(data);
      });
    });
  }

  /**
   * Generates a code change
   */
  private async generateCodeChange(
    request: CodeChangeRequest,
    originalCode: string
  ): Promise<{ modifiedCode: string; diffSummary: string }> {
    // In a real implementation, this would use an LLM to generate the code change
    // For now, return a simple modification
    
    // This is a placeholder implementation
    let modifiedCode = originalCode;
    let diffSummary = 'No changes made';
    
    switch (request.type) {
      case 'fix':
        // Simple fix: add error handling
        if (originalCode.includes('try {') && !originalCode.includes('catch (')) {
          modifiedCode = originalCode.replace(
            'try {',
            'try {\n  // Added error handling\n'
          ) + '\n} catch (error) {\n  console.error("Error caught:", error);\n  throw error;\n}';
          diffSummary = 'Added error handling with try-catch block';
        }
        break;
        
      case 'optimize':
        // Simple optimization: add memoization comment
        if (originalCode.includes('function ') && !originalCode.includes('// Memoized')) {
          modifiedCode = originalCode.replace(
            'function ',
            '// Memoized for performance\nfunction '
          );
          diffSummary = 'Added memoization comment';
        }
        break;
        
      case 'enhance':
        // Simple enhancement: add logging
        if (!originalCode.includes('console.log(')) {
          modifiedCode = originalCode + '\n\n// Added logging\nconsole.log("Function executed successfully");\n';
          diffSummary = 'Added logging statement';
        }
        break;
        
      case 'refactor':
        // Simple refactor: add comment about refactoring
        modifiedCode = '// Refactored for better readability and maintainability\n' + originalCode;
        diffSummary = 'Added refactoring comment';
        break;
    }
    
    return { modifiedCode, diffSummary };
  }

  /**
   * Applies a code change
   */
  private async applyCodeChange(change: CodeChange): Promise<boolean> {
    try {
      // Write the modified code to the file
      await this.writeFile(change.filePath, change.modifiedCode);
      return true;
    } catch (error) {
      console.error('Error applying code change:', error);
      return false;
    }
  }

  /**
   * Writes a file
   */
  private async writeFile(filePath: string, content: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      fs.writeFile(filePath, content, 'utf8', (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }

  /**
   * Persists a code change to storage
   */
  private async persistCodeChange(change: CodeChange): Promise<void> {
    await this.memoryManager.storeMemory({
      id: change.id,
      type: MemoryType.LONG_TERM,
      key: `code_change:${change.requestId}:${change.id}`,
      value: change,
      metadata: {
        requestId: change.requestId,
        filePath: change.filePath,
        changeType: change.changeType,
        status: change.status
      },
      timestamp: change.timestamp
    });
  }

  /**
   * Reverts a code change
   */
  public async revertCodeChange(changeId: string): Promise<boolean> {
    const change = this.codeChanges.get(changeId);
    if (!change) {
      throw new Error(`Code change with ID ${changeId} not found`);
    }
    
    try {
      // Write the original code back to the file
      await this.writeFile(change.filePath, change.originalCode);
      
      // Update status
      change.status = 'reverted';
      
      // Update in memory
      this.codeChanges.set(change.id, change);
      
      // Update in storage
      await this.persistCodeChange(change);
      
      this.emit('changeReverted', change);
      return true;
    } catch (error) {
      console.error('Error reverting code change:', error);
      return false;
    }
  }

  /**
   * Gets all change requests
   */
  public getChangeRequests(): CodeChangeRequest[] {
    return Array.from(this.changeRequests.values());
  }

  /**
   * Gets all code changes
   */
  public getCodeChanges(): CodeChange[] {
    return Array.from(this.codeChanges.values());
  }

  /**
   * Gets a change request by ID
   */
  public getChangeRequest(requestId: string): CodeChangeRequest | undefined {
    return this.changeRequests.get(requestId);
  }

  /**
   * Gets a code change by ID
   */
  public getCodeChange(changeId: string): CodeChange | undefined {
    return this.codeChanges.get(changeId);
  }

  /**
   * Gets all code changes for a request
   */
  public getCodeChangesForRequest(requestId: string): CodeChange[] {
    return this.getCodeChanges().filter(change => change.requestId === requestId);
  }
}

export default CodeSelfEditor;
