/**
 * Core Module Index File
 * 
 * This file exports all components of the Autonomous Cognition Core.
 */

// Export all core types
export * from './types';

// Export core modules
export { agentEventBus } from './event-bus';
export { memorySystem } from './memory';
export { goalDecomposer } from './goal-decomposer';
export { feedbackLoop } from './feedback-loop';
export { universalPlanner } from './planner';
export { metaCognitionAgent } from './meta-cognition';
export { agentRegistry } from './agent-registry';

// Export test utilities
export { testCoreModules } from './integration-test';
