/**
 * SentienceAI Cognitive Kernel - Enhanced Code Self-Editor
 * 
 * This module implements the enhanced Code Self-Editor:
 * - Uses LLM integration for code generation and modification
 * - Implements versioning for code changes
 * - Adds code validation and testing
 * - Enables self-modification capabilities
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';
import { MemoryManager, MemoryType } from '../memory';
import { ExecutionJournal } from '../execution-journal';
import { AutonomousExperienceLogger, TaskComparison } from '../autonomous-experience-logger';
import { ModelRouter } from '../../modules/llm/model-router';
import { PromptCompiler } from '../supervisory/prompt-optimizer';

export interface CodeChangeRequest {
  id: string;
  timestamp: number;
  taskId: string;
  filePath: string;
  reason: string;
  type: 'fix' | 'optimize' | 'enhance' | 'refactor';
  priority: 'low' | 'medium' | 'high' | 'critical';
  context: {
    errorMessage?: string;
    stackTrace?: string;
    performance?: any;
    userFeedback?: any;
  };
}

export interface CodeChange {
  id: string;
  requestId: string;
  timestamp: number;
  filePath: string;
  originalCode: string;
  modifiedCode: string;
  diffSummary: string;
  changeReason: string;
  changeType: 'fix' | 'optimize' | 'enhance' | 'refactor';
  status: 'pending' | 'applied' | 'reverted' | 'failed';
  testResults?: any;
  version: number;
}

export interface CodeValidationResult {
  valid: boolean;
  syntaxErrors: string[];
  warnings: string[];
  suggestions: string[];
}

export class EnhancedCodeSelfEditor extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private experienceLogger: AutonomousExperienceLogger;
  private modelRouter: ModelRouter;
  private promptCompiler: PromptCompiler;
  private changeRequests: Map<string, CodeChangeRequest> = new Map();
  private codeChanges: Map<string, CodeChange> = new Map();
  private codeVersions: Map<string, CodeChange[]> = new Map();
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    experienceLogger?: AutonomousExperienceLogger,
    modelRouter?: ModelRouter,
    promptCompiler?: PromptCompiler
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.experienceLogger = experienceLogger || new AutonomousExperienceLogger();
    this.modelRouter = modelRouter || new ModelRouter();
    this.promptCompiler = promptCompiler || new PromptCompiler();
  }

  /**
   * Creates a code change request
   */
  public async createChangeRequest(
    taskId: string,
    filePath: string,
    reason: string,
    type: 'fix' | 'optimize' | 'enhance' | 'refactor',
    priority: 'low' | 'medium' | 'high' | 'critical',
    context: any = {}
  ): Promise<CodeChangeRequest> {
    const request: CodeChangeRequest = {
      id: uuidv4(),
      timestamp: Date.now(),
      taskId,
      filePath,
      reason,
      type,
      priority,
      context
    };
    
    // Store in memory
    this.changeRequests.set(request.id, request);
    
    // Persist to storage
    await this.persistChangeRequest(request);
    
    this.emit('changeRequestCreated', request);
    return request;
  }

  /**
   * Persists a change request to storage
   */
  private async persistChangeRequest(request: CodeChangeRequest): Promise<void> {
    await this.memoryManager.storeMemory({
      id: request.id,
      type: MemoryType.LONG_TERM,
      key: `code_change_request:${request.taskId}:${request.id}`,
      value: request,
      metadata: {
        taskId: request.taskId,
        filePath: request.filePath,
        type: request.type,
        priority: request.priority
      },
      timestamp: request.timestamp
    });
  }

  /**
   * Processes a code change request
   */
  public async processChangeRequest(requestId: string): Promise<CodeChange | null> {
    const request = this.changeRequests.get(requestId);
    if (!request) {
      throw new Error(`Change request with ID ${requestId} not found`);
    }
    
    try {
      // Log the start of processing
      await this.executionJournal.logInfo(
        request.taskId,
        `Processing code change request: ${request.id}`,
        { request }
      );
      
      // Create a before snapshot
      const beforeSnapshot = await this.experienceLogger.createBeforeSnapshot(
        request.taskId,
        { changeRequest: request }
      );
      
      // Read the original code
      const originalCode = await this.readFile(request.filePath);
      
      // Generate the modified code using LLM
      const { modifiedCode, diffSummary } = await this.generateCodeChangeWithLLM(
        request,
        originalCode
      );
      
      // Validate the generated code
      const validationResult = await this.validateCode(modifiedCode, request.filePath);
      
      if (!validationResult.valid) {
        this.executionJournal.logWarning(
          request.taskId,
          `Generated code failed validation: ${validationResult.syntaxErrors.join(', ')}`,
          { validationResult }
        );
        
        // Try to fix the code if there are syntax errors
        if (validationResult.syntaxErrors.length > 0) {
          const fixedResult = await this.fixCodeSyntax(
            modifiedCode,
            validationResult.syntaxErrors,
            request.filePath
          );
          
          if (fixedResult.success) {
            this.executionJournal.logInfo(
              request.taskId,
              'Successfully fixed code syntax issues',
              { fixedResult }
            );
            
            // Use the fixed code
            modifiedCode = fixedResult.fixedCode;
          } else {
            // If we couldn't fix the code, log the error and return null
            this.executionJournal.logError(
              request.taskId,
              'Failed to fix code syntax issues',
              { fixedResult }
            );
            
            this.emit('changeProcessingFailed', {
              requestId,
              error: 'Generated code has syntax errors that could not be fixed'
            });
            
            return null;
          }
        }
      }
      
      // Get the current version number for this file
      const currentVersion = this.getCurrentVersion(request.filePath);
      
      // Create the code change
      const codeChange: CodeChange = {
        id: uuidv4(),
        requestId: request.id,
        timestamp: Date.now(),
        filePath: request.filePath,
        originalCode,
        modifiedCode,
        diffSummary,
        changeReason: request.reason,
        changeType: request.type,
        status: 'pending',
        version: currentVersion + 1
      };
      
      // Store in memory
      this.codeChanges.set(codeChange.id, codeChange);
      
      // Add to version history
      if (!this.codeVersions.has(request.filePath)) {
        this.codeVersions.set(request.filePath, []);
      }
      this.codeVersions.get(request.filePath)?.push(codeChange);
      
      // Persist to storage
      await this.persistCodeChange(codeChange);
      
      // Apply the change
      const applied = await this.applyCodeChange(codeChange);
      
      if (applied) {
        // Update status
        codeChange.status = 'applied';
        
        // Create an after snapshot
        const afterSnapshot = await this.experienceLogger.createAfterSnapshot(
          request.taskId,
          { changeRequest: request, codeChange }
        );
        
        // Compare snapshots
        const comparison = await this.experienceLogger.compareSnapshots(
          beforeSnapshot,
          afterSnapshot
        );
        
        // Update the code change with test results
        codeChange.testResults = {
          comparison,
          metrics: comparison.metrics
        };
        
        // Update in memory
        this.codeChanges.set(codeChange.id, codeChange);
        
        // Update in storage
        await this.persistCodeChange(codeChange);
      } else {
        // Update status
        codeChange.status = 'failed';
        
        // Update in memory
        this.codeChanges.set(codeChange.id, codeChange);
        
        // Update in storage
        await this.persistCodeChange(codeChange);
      }
      
      this.emit('changeProcessed', codeChange);
      return codeChange;
    } catch (error) {
      // Log the error
      await this.executionJournal.logError(
        request.taskId,
        error
      );
      
      this.emit('changeProcessingFailed', {
        requestId,
        error
      });
      
      return null;
    }
  }

  /**
   * Reads a file
   */
  private async readFile(filePath: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
          reject(err);
          return;
        }
        resolve(data);
      });
    });
  }

  /**
   * Generates a code change using LLM
   */
  private async generateCodeChangeWithLLM(
    request: CodeChangeRequest,
    originalCode: string
  ): Promise<{ modifiedCode: string; diffSummary: string }> {
    try {
      // Construct the prompt for the LLM
      const prompt = await this.constructCodeChangePrompt(request, originalCode);
      
      // Get the appropriate model for code generation
      const model = await this.modelRouter.getModelForTask('code_generation');
      
      // Generate the code change
      const response = await model.generateResponse(prompt);
      
      // Extract the modified code and diff summary from the response
      const { modifiedCode, diffSummary } = this.parseCodeGenerationResponse(response, originalCode);
      
      return { modifiedCode, diffSummary };
    } catch (error) {
      this.executionJournal.logError(
        request.taskId,
        `Error generating code change with LLM: ${error.message}`,
        { error }
      );
      
      // Fallback to simple modification if LLM fails
      return this.generateSimpleCodeChange(request, originalCode);
    }
  }

  /**
   * Constructs a prompt for code change generation
   */
  private async constructCodeChangePrompt(
    request: CodeChangeRequest,
    originalCode: string
  ): Promise<string> {
    // Get file extension to determine language
    const fileExt = path.extname(request.filePath).toLowerCase();
    const language = this.getLanguageFromExtension(fileExt);
    
    // Get relevant examples from memory
    const examples = await this.getRelevantExamples(request.type, language);
    
    // Construct the base prompt
    let prompt = `You are an expert software developer tasked with ${request.type}ing code.
    
File path: ${request.filePath}
Language: ${language}
Task: ${request.type} the code
Reason: ${request.reason}

Original code:
\`\`\`${language}
${originalCode}
\`\`\`

`;

    // Add context information if available
    if (request.context) {
      prompt += 'Additional context:\n';
      
      if (request.context.errorMessage) {
        prompt += `Error message: ${request.context.errorMessage}\n`;
      }
      
      if (request.context.stackTrace) {
        prompt += `Stack trace:\n${request.context.stackTrace}\n`;
      }
      
      if (request.context.performance) {
        prompt += `Performance metrics: ${JSON.stringify(request.context.performance)}\n`;
      }
      
      if (request.context.userFeedback) {
        prompt += `User feedback: ${request.context.userFeedback}\n`;
      }
      
      prompt += '\n';
    }

    // Add specific instructions based on change type
    switch (request.type) {
      case 'fix':
        prompt += 'Fix the issues in the code while maintaining its functionality. Focus on correcting errors, handling edge cases, and improving robustness.\n';
        break;
      case 'optimize':
        prompt += 'Optimize the code for better performance while maintaining its functionality. Focus on reducing complexity, improving efficiency, and eliminating bottlenecks.\n';
        break;
      case 'enhance':
        prompt += 'Enhance the code with additional features or capabilities while maintaining compatibility with existing functionality. Focus on adding value and improving usability.\n';
        break;
      case 'refactor':
        prompt += 'Refactor the code to improve its structure and readability while maintaining its functionality. Focus on code organization, naming, and adherence to best practices.\n';
        break;
    }

    // Add examples if available
    if (examples.length > 0) {
      prompt += '\nHere are some examples of similar changes:\n';
      
      for (const example of examples) {
        prompt += `\nExample ${example.type} (${example.language}):\n`;
        prompt += `Before:\n\`\`\`${example.language}\n${example.before}\n\`\`\`\n`;
        prompt += `After:\n\`\`\`${example.language}\n${example.after}\n\`\`\`\n`;
        prompt += `Changes: ${example.changes}\n`;
      }
    }

    // Add output format instructions
    prompt += `
Please provide your response in the following format:

MODIFIED_CODE:
\`\`\`${language}
// Your modified code here
\`\`\`

CHANGES_SUMMARY:
// A concise summary of the changes you made and why
`;

    // Use the prompt compiler to optimize the prompt
    return this.promptCompiler.compilePrompt(prompt, 'code_generation');
  }

  /**
   * Parses the response from the code generation LLM
   */
  private parseCodeGenerationResponse(
    response: string,
    originalCode: string
  ): { modifiedCode: string; diffSummary: string } {
    try {
      // Extract the modified code
      const codeMatch = response.match(/MODIFIED_CODE:\s*```(?:\w+)?\s*([\s\S]*?)```/);
      const modifiedCode = codeMatch ? codeMatch[1].trim() : originalCode;
      
      // Extract the changes summary
      const summaryMatch = response.match(/CHANGES_SUMMARY:\s*([\s\S]*?)(?:$|MODIFIED_CODE)/);
      const diffSummary = summaryMatch ? summaryMatch[1].trim() : 'No summary provided';
      
      return { modifiedCode, diffSummary };
    } catch (error) {
      // If parsing fails, return the original code and a generic summary
      return {
        modifiedCode: originalCode,
        diffSummary: 'Failed to parse LLM response'
      };
    }
  }

  /**
   * Gets the programming language from file extension
   */
  private getLanguageFromExtension(extension: string): string {
    const languageMap: { [key: string]: string } = {
      '.js': 'javascript',
      '.ts': 'typescript',
      '.jsx': 'javascript',
      '.tsx': 'typescript',
      '.py': 'python',
      '.rb': 'ruby',
      '.java': 'java',
      '.c': 'c',
      '.cpp': 'cpp',
      '.cs': 'csharp',
      '.go': 'go',
      '.php': 'php',
      '.swift': 'swift',
      '.kt': 'kotlin',
      '.rs': 'rust',
      '.html': 'html',
      '.css': 'css',
      '.scss': 'scss',
      '.json': 'json',
      '.md': 'markdown',
      '.sh': 'bash'
    };
    
    return languageMap[extension] || 'plaintext';
  }

  /**
   * Gets relevant examples from memory
   */
  private async getRelevantExamples(
    changeType: string,
    language: string
  ): Promise<any[]> {
    try {
      // Query memory for similar code changes
      const memories = await this.memoryManager.searchMemories({
        type: MemoryType.LONG_TERM,
        query: `code_change:${changeType}:${language}`,
        limit: 3
      });
      
      // Format examples
      return memories.map(memory => ({
        type: memory.value.changeType,
        language,
        before: memory.value.originalCode,
        after: memory.value.modifiedCode,
        changes: memory.value.diffSummary
      }));
    } catch (error) {
      // Return empty array if memory search fails
      return [];
    }
  }

  /**
   * Generates a simple code change as fallback
   */
  private generateSimpleCodeChange(
    request: CodeChangeRequest,
    originalCode: string
  ): { modifiedCode: string; diffSummary: string } {
    // This is a fallback implementation when LLM generation fails
    let modifiedCode = originalCode;
    let diffSummary = 'Simple fallback modification';
    
    switch (request.type) {
      case 'fix':
        // Simple fix: add error handling
        if (originalCode.includes('try {') && !originalCode.includes('catch (')) {
          modifiedCode = originalCode.replace(
            'try {',
            'try {\n  // Added error handling\n'
          ) + '\n} catch (error) {\n  console.error("Error caught:", error);\n  throw error;\n}';
          diffSummary = 'Added error handling with try-catch block';
        }
        break;
        
      case 'optimize':
        // Simple optimization: add memoization comment
        if (originalCode.includes('function ') && !originalCode.includes('// Memoized')) {
          modifiedCode = originalCode.replace(
            'function ',
            '// Memoized for performance\nfunction '
          );
          diffSummary = 'Added memoization comment';
        }
        break;
        
      case 'enhance':
        // Simple enhancement: add logging
        if (!originalCode.includes('console.log(')) {
          modifiedCode = originalCode + '\n\n// Added logging\nconsole.log("Function executed successfully");\n';
          diffSummary = 'Added logging statement';
        }
        break;
        
      case 'refactor':
        // Simple refactor: add comment about refactoring
        modifiedCode = '// Refactored for better readability and maintainability\n' + originalCode;
        diffSummary = 'Added refactoring comment';
        break;
    }
    
    return { modifiedCode, diffSummary };
  }

  /**
   * Validates generated code
   */
  private async validateCode(
    code: string,
    filePath: string
  ): Promise<CodeValidationResult> {
    try {
      // Get file extension to determine language
      const fileExt = path.extname(filePath).toLowerCase();
      
      // Perform basic syntax validation based on language
      if (fileExt === '.js' || fileExt === '.ts' || fileExt === '.jsx' || fileExt === '.tsx') {
        // For JavaScript/TypeScript, try to parse the code
        try {
          // This is a simplified validation
          // In a real implementation, we would use a proper parser
          new Function(code);
          return {
            valid: true,
            syntaxErrors: [],
            warnings: [],
            suggestions: []
          };
        } catch (error) {
          return {
            valid: false,
            syntaxErrors: [error.message],
            warnings: [],
            suggestions: []
          };
        }
      } else if (fileExt === '.py') {
        // For Python, we would use a Python parser
        // This is a placeholder for demonstration
        return {
          valid: true,
          syntaxErrors: [],
          warnings: [],
          suggestions: []
        };
      } else {
        // For other languages, assume valid
        return {
          valid: true,
          syntaxErrors: [],
          warnings: [],
          suggestions: []
        };
      }
    } catch (error) {
      // If validation fails, return invalid result
      return {
        valid: false,
        syntaxErrors: [error.message],
        warnings: [],
        suggestions: []
      };
    }
  }

  /**
   * Fixes code syntax issues
   */
  private async fixCodeSyntax(
    code: string,
    errors: string[],
    filePath: string
  ): Promise<{ success: boolean; fixedCode: string }> {
    try {
      // Construct a prompt for the LLM to fix the code
      const fileExt = path.extname(filePath).toLowerCase();
      const language = this.getLanguageFromExtension(fileExt);
      
      const prompt = `You are an expert software developer tasked with fixing syntax errors in code.
      
Language: ${language}
File path: ${filePath}

The code has the following syntax errors:
${errors.join('\n')}

Original code with errors:
\`\`\`${language}
${code}
\`\`\`

Please fix the syntax errors and provide the corrected code. Only output the fixed code, nothing else.`;
      
      // Get the appropriate model for code fixing
      const model = await this.modelRouter.getModelForTask('code_fixing');
      
      // Generate the fixed code
      const fixedCode = await model.generateResponse(prompt);
      
      // Clean up the response to extract just the code
      const cleanedCode = this.extractCodeFromResponse(fixedCode, language);
      
      // Validate the fixed code
      const validationResult = await this.validateCode(cleanedCode, filePath);
      
      if (validationResult.valid) {
        return {
          success: true,
          fixedCode: cleanedCode
        };
      } else {
        return {
          success: false,
          fixedCode: code // Return original code if fixing failed
        };
      }
    } catch (error) {
      // If fixing fails, return failure
      return {
        success: false,
        fixedCode: code // Return original code if fixing failed
      };
    }
  }

  /**
   * Extracts code from LLM response
   */
  private extractCodeFromResponse(response: string, language: string): string {
    // Try to extract code from markdown code blocks
    const codeBlockRegex = new RegExp(`\`\`\`(?:${language})?\s*([\s\S]*?)\`\`\``, 'i');
    const match = response.match(codeBlockRegex);
    
    if (match && match[1]) {
      return match[1].trim();
    }
    
    // If no code block found, return the whole response
    return response.trim();
  }

  /**
   * Gets the current version number for a file
   */
  private getCurrentVersion(filePath: string): number {
    const versions = this.codeVersions.get(filePath);
    
    if (!versions || versions.length === 0) {
      return 0;
    }
    
    return Math.max(...versions.map(change => change.version));
  }

  /**
   * Applies a code change
   */
  private async applyCodeChange(change: CodeChange): Promise<boolean> {
    try {
      // Write the modified code to the file
      await this.writeFile(change.filePath, change.modifiedCode);
      return true;
    } catch (error) {
      console.error('Error applying code change:', error);
      return false;
    }
  }

  /**
   * Writes a file
   */
  private async writeFile(filePath: string, content: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      fs.writeFile(filePath, content, 'utf8', (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }

  /**
   * Persists a code change to storage
   */
  private async persistCodeChange(change: CodeChange): Promise<void> {
    await this.memoryManager.storeMemory({
      id: change.id,
      type: MemoryType.LONG_TERM,
      key: `code_change:${change.requestId}:${change.id}`,
      value: change,
      metadata: {
        requestId: change.requestId,
        filePath: change.filePath,
        changeType: change.changeType,
        status: change.status,
        version: change.version
      },
      timestamp: change.timestamp
    });
  }

  /**
   * Reverts a code change
   */
  public async revertCodeChange(changeId: string): Promise<boolean> {
    const change = this.codeChanges.get(changeId);
    if (!change) {
      throw new Error(`Code change with ID ${changeId} not found`);
    }
    
    try {
      // Write the original code back to the file
      await this.writeFile(change.filePath, change.originalCode);
      
      // Update status
      change.status = 'reverted';
      
      // Update in memory
      this.codeChanges.set(change.id, change);
      
      // Update in storage
      await this.persistCodeChange(change);
      
      this.emit('changeReverted', change);
      return true;
    } catch (error) {
      console.error('Error reverting code change:', error);
      return false;
    }
  }

  /**
   * Gets all versions of a file
   */
  public getFileVersions(filePath: string): CodeChange[] {
    const versions = this.codeVersions.get(filePath);
    
    if (!versions) {
      return [];
    }
    
    // Sort by version number
    return [...versions].sort((a, b) => a.version - b.version);
  }

  /**
   * Gets a specific version of a file
   */
  public async getFileVersion(filePath: string, version: number): Promise<string | null> {
    const versions = this.getFileVersions(filePath);
    
    const versionChange = versions.find(change => change.version === version);
    
    if (!versionChange) {
      return null;
    }
    
    return versionChange.modifiedCode;
  }

  /**
   * Restores a specific version of a file
   */
  public async restoreFileVersion(filePath: string, version: number): Promise<boolean> {
    const versionContent = await this.getFileVersion(filePath, version);
    
    if (!versionContent) {
      return false;
    }
    
    try {
      // Write the version content to the file
      await this.writeFile(filePath, versionContent);
      
      // Create a new change record for the restoration
      const currentVersion = this.getCurrentVersion(filePath);
      
      const restorationChange: CodeChange = {
        id: uuidv4(),
        requestId: 'version_restoration',
        timestamp: Date.now(),
        filePath,
        originalCode: await this.readFile(filePath),
        modifiedCode: versionContent,
        diffSummary: `Restored to version ${version}`,
        changeReason: `Version restoration to v${version}`,
        changeType: 'refactor',
        status: 'applied',
        version: currentVersion + 1
      };
      
      // Store in memory
      this.codeChanges.set(restorationChange.id, restorationChange);
      
      // Add to version history
      if (!this.codeVersions.has(filePath)) {
        this.codeVersions.set(filePath, []);
      }
      this.codeVersions.get(filePath)?.push(restorationChange);
      
      // Persist to storage
      await this.persistCodeChange(restorationChange);
      
      this.emit('versionRestored', {
        filePath,
        restoredVersion: version,
        newVersion: restorationChange.version
      });
      
      return true;
    } catch (error) {
      console.error('Error restoring file version:', error);
      return false;
    }
  }

  /**
   * Gets all change requests
   */
  public getChangeRequests(): CodeChangeRequest[] {
    return Array.from(this.changeRequests.values());
  }

  /**
   * Gets all code changes
   */
  public getCodeChanges(): CodeChange[] {
    return Array.from(this.codeChanges.values());
  }

  /**
   * Gets a change request by ID
   */
  public getChangeRequest(requestId: string): CodeChangeRequest | undefined {
    return this.changeRequests.get(requestId);
  }

  /**
   * Gets a code change by ID
   */
  public getCodeChange(changeId: string): CodeChange | undefined {
    return this.codeChanges.get(changeId);
  }

  /**
   * Gets all code changes for a request
   */
  public getCodeChangesForRequest(requestId: string): CodeChange[] {
    return this.getCodeChanges().filter(change => change.requestId === requestId);
  }
}

export default EnhancedCodeSelfEditor;
