/**
 * Feedback Loop Implementation for Autonomous Cognition Core
 * 
 * Provides adaptive learning from execution results to improve future planning.
 */

import { FeedbackItem } from './types';
import { memorySystem } from './memory';

/**
 * Adaptive Feedback Loop for the Autonomous Cognition Core
 * 
 * Collects and analyzes feedback from agent actions to improve future performance
 * through learning and adaptation.
 */
class FeedbackLoop {
  private static instance: FeedbackLoop;
  private feedback: Map<string, FeedbackItem> = new Map();
  
  // Configuration
  private readonly MAX_FEEDBACK_ITEMS = 10000;
  
  private constructor() {
    // Private constructor for singleton pattern
  }

  /**
   * Get the singleton instance of the feedback loop
   */
  public static getInstance(): FeedbackLoop {
    if (!FeedbackLoop.instance) {
      FeedbackLoop.instance = new FeedbackLoop();
    }
    return FeedbackLoop.instance;
  }

  /**
   * Record feedback for an agent action
   * 
   * @param agentId ID of the agent that performed the action
   * @param actionId ID of the action that was performed
   * @param success Whether the action was successful
   * @param score Score for the action (-100 to 100)
   * @param reason Reason for the feedback
   * @param metadata Additional metadata for the feedback
   * @returns The created feedback item
   */
  public recordFeedback(
    agentId: string,
    actionId: string,
    success: boolean,
    score: number,
    reason: string,
    metadata: Record<string, any> = {}
  ): FeedbackItem {
    // Ensure score is within valid range
    const normalizedScore = Math.max(-100, Math.min(100, score));
    
    const now = Date.now();
    const feedbackItem: FeedbackItem = {
      id: `feedback_${now}_${Math.random().toString(36).substr(2, 9)}`,
      agentId,
      actionId,
      success,
      score: normalizedScore,
      reason,
      createdAt: now,
      metadata
    };
    
    this.feedback.set(feedbackItem.id, feedbackItem);
    
    // Enforce maximum size by removing oldest items
    if (this.feedback.size > this.MAX_FEEDBACK_ITEMS) {
      const oldestKey = Array.from(this.feedback.keys())[0];
      this.feedback.delete(oldestKey);
    }
    
    // Store in memory system for learning
    const importance = Math.abs(normalizedScore) / 2; // 0-50 based on score magnitude
    memorySystem.storeLongTerm({
      type: 'experience',
      content: feedbackItem,
      tags: ['feedback', agentId, success ? 'success' : 'failure', actionId],
      importance: importance,
      createdAt: now,
      metadata: {}
    });
    
    return feedbackItem;
  }

  /**
   * Get feedback for a specific agent
   * 
   * @param agentId ID of the agent
   * @returns Array of feedback items for the agent
   */
  public getAgentFeedback(agentId: string): FeedbackItem[] {
    return Array.from(this.feedback.values())
      .filter(item => item.agentId === agentId);
  }

  /**
   * Get feedback for a specific action
   * 
   * @param actionId ID of the action
   * @returns Array of feedback items for the action
   */
  public getActionFeedback(actionId: string): FeedbackItem[] {
    return Array.from(this.feedback.values())
      .filter(item => item.actionId === actionId);
  }

  /**
   * Get agent performance metrics
   * 
   * @param agentId ID of the agent
   * @returns Performance metrics for the agent
   */
  public getAgentPerformance(agentId: string): {
    successRate: number;
    averageScore: number;
    totalActions: number;
  } {
    const agentFeedback = this.getAgentFeedback(agentId);
    const totalActions = agentFeedback.length;
    
    if (totalActions === 0) {
      return {
        successRate: 0,
        averageScore: 0,
        totalActions: 0
      };
    }
    
    const successfulActions = agentFeedback.filter(item => item.success).length;
    const totalScore = agentFeedback.reduce((sum, item) => sum + item.score, 0);
    
    return {
      successRate: successfulActions / totalActions,
      averageScore: totalScore / totalActions,
      totalActions
    };
  }

  /**
   * Get similar past actions to learn from
   * 
   * @param actionType Type of action
   * @param context Context of the action
   * @param limit Maximum number of similar actions to return
   * @returns Array of similar feedback items
   */
  public getSimilarActions(
    actionType: string,
    context: Record<string, any>,
    limit: number = 5
  ): FeedbackItem[] {
    // This is a simplified implementation
    // In a real system, this would use more sophisticated similarity metrics
    
    // Filter by action type from metadata
    const relevantFeedback = Array.from(this.feedback.values())
      .filter(item => item.metadata.actionType === actionType);
    
    // Sort by recency (more recent first)
    return relevantFeedback
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, limit);
  }

  /**
   * Get retry strategies for failed actions
   * 
   * @param actionType Type of action that failed
   * @param errorType Type of error encountered
   * @returns Array of potential retry strategies
   */
  public getRetryStrategies(
    actionType: string,
    errorType: string
  ): Array<{
    strategy: string;
    successRate: number;
    metadata: Record<string, any>;
  }> {
    // This is a simplified implementation
    // In a real system, this would analyze past retries and their outcomes
    
    // Find feedback items with retry information for this action and error type
    const relevantFeedback = Array.from(this.feedback.values())
      .filter(item => 
        item.metadata.actionType === actionType &&
        item.metadata.errorType === errorType &&
        item.metadata.retryStrategy
      );
    
    // Group by retry strategy
    const strategies = new Map<string, {
      strategy: string;
      successes: number;
      attempts: number;
      metadata: Record<string, any>;
    }>();
    
    for (const item of relevantFeedback) {
      const strategy = item.metadata.retryStrategy;
      
      if (!strategies.has(strategy)) {
        strategies.set(strategy, {
          strategy,
          successes: 0,
          attempts: 0,
          metadata: {}
        });
      }
      
      const data = strategies.get(strategy)!;
      data.attempts++;
      
      if (item.success) {
        data.successes++;
      }
      
      // Merge metadata (simplified)
      data.metadata = { ...data.metadata, ...item.metadata.strategyMetadata };
    }
    
    // Convert to array with success rates
    return Array.from(strategies.values())
      .map(data => ({
        strategy: data.strategy,
        successRate: data.attempts > 0 ? data.successes / data.attempts : 0,
        metadata: data.metadata
      }))
      .sort((a, b) => b.successRate - a.successRate);
  }
}

export const feedbackLoop = FeedbackLoop.getInstance();
