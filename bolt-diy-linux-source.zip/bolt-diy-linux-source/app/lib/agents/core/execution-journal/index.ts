/**
 * SentienceAI Cognitive Kernel - Execution Journal
 * 
 * This module implements the Execution Journal:
 * - Records every action, error, and success
 * - Provides introspective feedback
 * - Creates task snapshots for comparative evaluation
 */

import { EventEmitter } from 'events';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

export enum JournalEntryType {
  TASK_START = 'task_start',
  TASK_COMPLETION = 'task_completion',
  STATE_TRANSITION = 'state_transition',
  OBSERVATION = 'observation',
  PLAN = 'plan',
  ACTION = 'action',
  EVALUATION = 'evaluation',
  MODIFICATION = 'modification',
  LEARNING = 'learning',
  REPLAN = 'replan',
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info'
}

export interface JournalEntry {
  id: string;
  timestamp: number;
  type: JournalEntryType;
  taskId: string;
  data: any;
  metadata?: any;
}

export interface TaskSnapshot {
  id: string;
  taskId: string;
  timestamp: number;
  state: string;
  context: any;
  metrics: {
    executionTime: number;
    memoryUsage: number;
    successRate: number;
    errorCount: number;
    [key: string]: any;
  };
}

export class ExecutionJournal extends EventEmitter {
  private journalPath: string;
  private snapshotsPath: string;
  private initialized: boolean = false;
  private currentEntries: Map<string, JournalEntry[]> = new Map();
  private snapshots: Map<string, TaskSnapshot[]> = new Map();
  
  constructor(basePath?: string) {
    super();
    const dataPath = basePath || path.join(process.cwd(), 'data');
    this.journalPath = path.join(dataPath, 'journal');
    this.snapshotsPath = path.join(dataPath, 'snapshots');
  }

  /**
   * Initializes the execution journal
   */
  public async initialize(): Promise<void> {
    if (this.initialized) return;
    
    // Ensure directories exist
    if (!fs.existsSync(this.journalPath)) {
      fs.mkdirSync(this.journalPath, { recursive: true });
    }
    
    if (!fs.existsSync(this.snapshotsPath)) {
      fs.mkdirSync(this.snapshotsPath, { recursive: true });
    }
    
    this.initialized = true;
    this.emit('initialized');
  }

  /**
   * Creates and stores a journal entry
   */
  private async createEntry(
    type: JournalEntryType,
    taskId: string,
    data: any,
    metadata?: any
  ): Promise<JournalEntry> {
    if (!this.initialized) await this.initialize();
    
    const entry: JournalEntry = {
      id: uuidv4(),
      timestamp: Date.now(),
      type,
      taskId,
      data,
      metadata
    };
    
    // Store in memory
    if (!this.currentEntries.has(taskId)) {
      this.currentEntries.set(taskId, []);
    }
    this.currentEntries.get(taskId)!.push(entry);
    
    // Write to disk asynchronously
    this.persistEntry(entry).catch(err => {
      console.error('Failed to persist journal entry:', err);
    });
    
    this.emit('entryCreated', entry);
    return entry;
  }

  /**
   * Persists a journal entry to disk
   */
  private async persistEntry(entry: JournalEntry): Promise<void> {
    const taskDir = path.join(this.journalPath, entry.taskId);
    if (!fs.existsSync(taskDir)) {
      fs.mkdirSync(taskDir, { recursive: true });
    }
    
    const filePath = path.join(taskDir, `${entry.id}.json`);
    return new Promise<void>((resolve, reject) => {
      fs.writeFile(
        filePath,
        JSON.stringify(entry, null, 2),
        'utf8',
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          resolve();
        }
      );
    });
  }

  /**
   * Creates a task snapshot
   */
  public async createSnapshot(
    taskId: string,
    state: string,
    context: any
  ): Promise<TaskSnapshot> {
    if (!this.initialized) await this.initialize();
    
    // Calculate metrics
    const entries = this.currentEntries.get(taskId) || [];
    const errorCount = entries.filter(e => e.type === JournalEntryType.ERROR).length;
    const startEntry = entries.find(e => e.type === JournalEntryType.TASK_START);
    const executionTime = startEntry
      ? Date.now() - startEntry.timestamp
      : 0;
    
    const snapshot: TaskSnapshot = {
      id: uuidv4(),
      taskId,
      timestamp: Date.now(),
      state,
      context,
      metrics: {
        executionTime,
        memoryUsage: process.memoryUsage().heapUsed,
        successRate: entries.length > 0 ? (entries.length - errorCount) / entries.length : 1,
        errorCount
      }
    };
    
    // Store in memory
    if (!this.snapshots.has(taskId)) {
      this.snapshots.set(taskId, []);
    }
    this.snapshots.get(taskId)!.push(snapshot);
    
    // Write to disk asynchronously
    this.persistSnapshot(snapshot).catch(err => {
      console.error('Failed to persist snapshot:', err);
    });
    
    this.emit('snapshotCreated', snapshot);
    return snapshot;
  }

  /**
   * Persists a task snapshot to disk
   */
  private async persistSnapshot(snapshot: TaskSnapshot): Promise<void> {
    const taskDir = path.join(this.snapshotsPath, snapshot.taskId);
    if (!fs.existsSync(taskDir)) {
      fs.mkdirSync(taskDir, { recursive: true });
    }
    
    const filePath = path.join(taskDir, `${snapshot.id}.json`);
    return new Promise<void>((resolve, reject) => {
      fs.writeFile(
        filePath,
        JSON.stringify(snapshot, null, 2),
        'utf8',
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          resolve();
        }
      );
    });
  }

  /**
   * Logs the start of a task
   */
  public async logTaskStart(taskId: string, inputs: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.TASK_START, taskId, { inputs });
  }

  /**
   * Logs the completion of a task
   */
  public async logTaskCompletion(taskId: string, context: any): Promise<JournalEntry> {
    const entry = await this.createEntry(JournalEntryType.TASK_COMPLETION, taskId, { context });
    
    // Create a final snapshot
    await this.createSnapshot(taskId, 'completed', context);
    
    return entry;
  }

  /**
   * Logs a state transition
   */
  public async logStateTransition(
    taskId: string,
    fromState: string,
    toState: string
  ): Promise<JournalEntry> {
    return this.createEntry(
      JournalEntryType.STATE_TRANSITION,
      taskId,
      { fromState, toState }
    );
  }

  /**
   * Logs observations
   */
  public async logObservations(taskId: string, observations: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.OBSERVATION, taskId, { observations });
  }

  /**
   * Logs a plan
   */
  public async logPlan(taskId: string, plan: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.PLAN, taskId, { plan });
  }

  /**
   * Logs actions
   */
  public async logActions(taskId: string, actions: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.ACTION, taskId, { actions });
  }

  /**
   * Logs an evaluation
   */
  public async logEvaluation(taskId: string, evaluation: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.EVALUATION, taskId, { evaluation });
  }

  /**
   * Logs modifications
   */
  public async logModifications(taskId: string, modifications: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.MODIFICATION, taskId, { modifications });
  }

  /**
   * Logs learnings
   */
  public async logLearnings(taskId: string, learnings: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.LEARNING, taskId, { learnings });
  }

  /**
   * Logs a replan
   */
  public async logReplan(taskId: string, replan: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.REPLAN, taskId, { replan });
  }

  /**
   * Logs an error
   */
  public async logError(taskId: string, error: any): Promise<JournalEntry> {
    return this.createEntry(
      JournalEntryType.ERROR,
      taskId,
      {
        message: error.message || String(error),
        stack: error.stack,
        code: error.code
      }
    );
  }

  /**
   * Logs a warning
   */
  public async logWarning(taskId: string, message: string, data?: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.WARNING, taskId, { message, data });
  }

  /**
   * Logs an info message
   */
  public async logInfo(taskId: string, message: string, data?: any): Promise<JournalEntry> {
    return this.createEntry(JournalEntryType.INFO, taskId, { message, data });
  }

  /**
   * Gets all entries for a task
   */
  public getTaskEntries(taskId: string): JournalEntry[] {
    return this.currentEntries.get(taskId) || [];
  }

  /**
   * Gets all snapshots for a task
   */
  public getTaskSnapshots(taskId: string): TaskSnapshot[] {
    return this.snapshots.get(taskId) || [];
  }

  /**
   * Gets entries of a specific type for a task
   */
  public getTaskEntriesByType(taskId: string, type: JournalEntryType): JournalEntry[] {
    const entries = this.currentEntries.get(taskId) || [];
    return entries.filter(entry => entry.type === type);
  }

  /**
   * Compares two snapshots to analyze changes
   */
  public compareSnapshots(snapshot1: TaskSnapshot, snapshot2: TaskSnapshot): any {
    // This is a simplified implementation
    return {
      timeDifference: snapshot2.timestamp - snapshot1.timestamp,
      metricChanges: {
        executionTime: snapshot2.metrics.executionTime - snapshot1.metrics.executionTime,
        memoryUsage: snapshot2.metrics.memoryUsage - snapshot1.metrics.memoryUsage,
        successRate: snapshot2.metrics.successRate - snapshot1.metrics.successRate,
        errorCount: snapshot2.metrics.errorCount - snapshot1.metrics.errorCount
      },
      stateChange: snapshot1.state !== snapshot2.state
    };
  }
}

export default ExecutionJournal;
