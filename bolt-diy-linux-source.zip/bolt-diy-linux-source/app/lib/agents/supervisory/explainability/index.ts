/**
 * SentienceAI Cognitive Kernel - Explainability Agent
 * 
 * This module implements the Explainability Agent:
 * - Provides transparency into decision-making
 * - Generates human-readable explanations of system actions
 * - Creates audit trails for system modifications
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../../core/memory';
import { ExecutionJournal } from '../../core/execution-journal';
import { SharedMemoryBus, Message, MessageType } from '../../core/shared-memory-bus';

export interface Explanation {
  id: string;
  taskId: string;
  actionId: string;
  actionType: string;
  timestamp: number;
  explanation: string;
  reasoning: string[];
  alternatives: {
    action: string;
    reason: string;
    score: number;
  }[];
  metadata: any;
}

export interface AuditTrail {
  id: string;
  taskId: string;
  entries: {
    id: string;
    timestamp: number;
    actor: string;
    action: string;
    details: any;
    explanation?: string;
  }[];
  metadata: any;
}

export class ExplainabilityAgent extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private sharedMemoryBus: SharedMemoryBus;
  private explanations: Map<string, Explanation> = new Map();
  private auditTrails: Map<string, AuditTrail> = new Map();
  private subscriptions: string[] = [];
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    sharedMemoryBus?: SharedMemoryBus
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.sharedMemoryBus = sharedMemoryBus || SharedMemoryBus.getInstance();
    
    // Initialize subscriptions
    this.initializeSubscriptions();
  }

  /**
   * Initializes message bus subscriptions
   */
  private initializeSubscriptions(): void {
    // Subscribe to action execution events
    const actionSub = this.sharedMemoryBus.subscribe(
      'explainability',
      'action:executed',
      this.handleActionExecuted.bind(this)
    );
    this.subscriptions.push(actionSub.id);
    
    // Subscribe to code change events
    const codeSub = this.sharedMemoryBus.subscribe(
      'explainability',
      'code:changed',
      this.handleCodeChanged.bind(this)
    );
    this.subscriptions.push(codeSub.id);
    
    // Subscribe to explanation requests
    const explainSub = this.sharedMemoryBus.subscribe(
      'explainability',
      'explain:request',
      this.handleExplainRequest.bind(this)
    );
    this.subscriptions.push(explainSub.id);
    
    // Subscribe to audit trail requests
    const auditSub = this.sharedMemoryBus.subscribe(
      'explainability',
      'audit:request',
      this.handleAuditRequest.bind(this)
    );
    this.subscriptions.push(auditSub.id);
  }

  /**
   * Handles action executed events
   */
  private handleActionExecuted(message: Message): void {
    const { sender, payload } = message;
    
    // Generate explanation for the action
    this.explainAction(
      payload.taskId,
      payload.actionId,
      payload.actionType,
      payload.details
    );
    
    // Add to audit trail
    this.addAuditEntry(
      payload.taskId,
      sender,
      payload.actionType,
      payload.details
    );
  }

  /**
   * Handles code changed events
   */
  private handleCodeChanged(message: Message): void {
    const { sender, payload } = message;
    
    // Generate explanation for the code change
    const explanation = this.explainAction(
      payload.taskId,
      payload.changeId,
      'code_change',
      payload
    );
    
    // Add to audit trail with explanation
    this.addAuditEntry(
      payload.taskId,
      sender,
      'code_change',
      payload,
      explanation.explanation
    );
  }

  /**
   * Handles explanation requests
   */
  private handleExplainRequest(message: Message): void {
    const { payload, correlationId } = message;
    
    try {
      // Get explanation
      const explanation = this.getExplanation(payload.actionId);
      
      if (!explanation) {
        this.sharedMemoryBus.respond(message, 'explainability', null, {
          error: `Explanation for action ${payload.actionId} not found`
        });
        return;
      }
      
      this.sharedMemoryBus.respond(message, 'explainability', {
        explanation
      });
    } catch (error) {
      this.sharedMemoryBus.respond(message, 'explainability', null, {
        error: `Error retrieving explanation: ${error}`
      });
    }
  }

  /**
   * Handles audit trail requests
   */
  private handleAuditRequest(message: Message): void {
    const { payload, correlationId } = message;
    
    try {
      // Get audit trail
      const auditTrail = this.getAuditTrail(payload.taskId);
      
      if (!auditTrail) {
        this.sharedMemoryBus.respond(message, 'explainability', null, {
          error: `Audit trail for task ${payload.taskId} not found`
        });
        return;
      }
      
      this.sharedMemoryBus.respond(message, 'explainability', {
        auditTrail
      });
    } catch (error) {
      this.sharedMemoryBus.respond(message, 'explainability', null, {
        error: `Error retrieving audit trail: ${error}`
      });
    }
  }

  /**
   * Explains an action
   */
  public explainAction(
    taskId: string,
    actionId: string,
    actionType: string,
    details: any,
    metadata: any = {}
  ): Explanation {
    // Generate explanation
    const explanation = this.generateExplanation(actionType, details);
    
    // Generate reasoning
    const reasoning = this.generateReasoning(actionType, details);
    
    // Generate alternatives
    const alternatives = this.generateAlternatives(actionType, details);
    
    // Create explanation record
    const explanationRecord: Explanation = {
      id: uuidv4(),
      taskId,
      actionId,
      actionType,
      timestamp: Date.now(),
      explanation,
      reasoning,
      alternatives,
      metadata
    };
    
    // Store explanation
    this.explanations.set(actionId, explanationRecord);
    
    // Persist to storage
    this.persistExplanation(explanationRecord).catch(err => {
      console.error('Error persisting explanation:', err);
    });
    
    this.emit('explanationGenerated', explanationRecord);
    return explanationRecord;
  }

  /**
   * Generates an explanation for an action
   */
  private generateExplanation(actionType: string, details: any): string {
    // This is a simplified implementation
    // In a real system, this would use an LLM to generate explanations
    
    switch (actionType) {
      case 'code_change':
        return `The system modified code in ${details.filePath} to ${details.reason || 'improve functionality'}. This change ${details.improvement || 'enhances the system\'s capabilities'}.`;
        
      case 'workflow_execution':
        return `The system executed workflow "${details.name}" to accomplish ${details.purpose || 'a specific task'}. This workflow was chosen because it ${details.rationale || 'is the most appropriate for this situation'}.`;
        
      case 'decision':
        return `The system made a decision to ${details.decision} based on ${details.factors?.join(', ') || 'relevant factors'}. This decision aligns with ${details.alignment || 'user goals and system objectives'}.`;
        
      case 'skill_evolution':
        return `The system evolved skill "${details.skillName}" from version ${details.fromVersion} to ${details.toVersion} to ${details.reason || 'improve performance'}. This evolution ${details.improvement || 'enhances the system\'s capabilities'}.`;
        
      default:
        return `The system performed a ${actionType} action based on its programming and available information. This action was taken to achieve the system's objectives while maintaining alignment with user intent.`;
    }
  }

  /**
   * Generates reasoning for an action
   */
  private generateReasoning(actionType: string, details: any): string[] {
    // This is a simplified implementation
    // In a real system, this would use an LLM to generate reasoning
    
    switch (actionType) {
      case 'code_change':
        return [
          `The original code had ${details.issue || 'room for improvement'}.`,
          `The change addresses this by ${details.solution || 'implementing a better approach'}.`,
          `This approach was chosen because ${details.rationale || 'it is more efficient and robust'}.`
        ];
        
      case 'workflow_execution':
        return [
          `The task required ${details.requirements || 'specific capabilities'}.`,
          `This workflow provides ${details.capabilities || 'the necessary functionality'}.`,
          `Alternative workflows were considered but ${details.comparison || 'this one was most appropriate'}.`
        ];
        
      case 'decision':
        return [
          `The decision was based on ${details.evidence || 'available evidence'}.`,
          `The system considered ${details.considerations || 'multiple factors'}.`,
          `The chosen option maximizes ${details.optimization || 'effectiveness while minimizing risks'}.`
        ];
        
      case 'skill_evolution':
        return [
          `The previous version had ${details.limitations || 'performance limitations'}.`,
          `The new version improves ${details.improvements || 'key aspects of functionality'}.`,
          `This evolution was triggered by ${details.trigger || 'performance metrics falling below thresholds'}.`
        ];
        
      default:
        return [
          `The action was taken based on system objectives and user intent.`,
          `The system evaluated available options and selected the most appropriate one.`,
          `The action aligns with system goals while respecting constraints.`
        ];
    }
  }

  /**
   * Generates alternatives for an action
   */
  private generateAlternatives(actionType: string, details: any): any[] {
    // This is a simplified implementation
    // In a real system, this would use an LLM to generate alternatives
    
    switch (actionType) {
      case 'code_change':
        return [
          {
            action: 'Leave code unchanged',
            reason: 'The existing code was functional, though suboptimal.',
            score: 0.3
          },
          {
            action: 'Implement a different solution approach',
            reason: 'An alternative implementation was considered but deemed less efficient.',
            score: 0.6
          }
        ];
        
      case 'workflow_execution':
        return [
          {
            action: 'Use a simpler workflow',
            reason: 'A simpler workflow would be faster but less comprehensive.',
            score: 0.4
          },
          {
            action: 'Create a custom workflow for this specific task',
            reason: 'A custom workflow would be more tailored but take longer to develop.',
            score: 0.7
          }
        ];
        
      case 'decision':
        return [
          {
            action: 'Choose the safer option',
            reason: 'A more conservative approach would have lower risk but also lower potential benefit.',
            score: 0.5
          },
          {
            action: 'Defer the decision',
            reason: 'Waiting for more information could improve decision quality but delay progress.',
            score: 0.2
          }
        ];
        
      case 'skill_evolution':
        return [
          {
            action: 'Make incremental improvements',
            reason: 'Smaller changes would be safer but provide less improvement.',
            score: 0.6
          },
          {
            action: 'Replace with entirely new implementation',
            reason: 'A complete rewrite would be more disruptive but potentially more innovative.',
            score: 0.4
          }
        ];
        
      default:
        return [
          {
            action: 'Take no action',
            reason: 'The system could have waited for more information or user input.',
            score: 0.2
          },
          {
            action: 'Take a different approach',
            reason: 'Alternative approaches were considered but deemed less suitable.',
            score: 0.5
          }
        ];
    }
  }

  /**
   * Persists an explanation to storage
   */
  private async persistExplanation(explanation: Explanation): Promise<void> {
    await this.memoryManager.storeMemory({
      id: explanation.id,
      type: MemoryType.LONG_TERM,
      key: `explanation:${explanation.actionId}`,
      value: explanation,
      metadata: {
        taskId: explanation.taskId,
        actionId: explanation.actionId,
        actionType: explanation.actionType
      },
      timestamp: explanation.timestamp
    });
  }

  /**
   * Adds an entry to the audit trail
   */
  public addAuditEntry(
    taskId: string,
    actor: string,
    action: string,
    details: any,
    explanation?: string
  ): void {
    // Get or create audit trail
    let auditTrail = this.auditTrails.get(taskId);
    
    if (!auditTrail) {
      auditTrail = {
        id: uuidv4(),
        taskId,
        entries: [],
        metadata: {}
      };
      this.auditTrails.set(taskId, auditTrail);
    }
    
    // Create entry
    const entry = {
      id: uuidv4(),
      timestamp: Date.now(),
      actor,
      action,
      details,
      explanation
    };
    
    // Add to audit trail
    auditTrail.entries.push(entry);
    
    // Persist to storage
    this.persistAuditTrail(auditTrail).catch(err => {
      console.error('Error persisting audit trail:', err);
    });
    
    this.emit('auditEntryAdded', entry, auditTrail);
  }

  /**
   * Persists an audit trail to storage
   */
  private async persistAuditTrail(auditTrail: AuditTrail): Promise<void> {
    await this.memoryManager.storeMemory({
      id: auditTrail.id,
      type: MemoryType.LONG_TERM,
      key: `audit_trail:${auditTrail.taskId}`,
      value: auditTrail,
      metadata: {
        taskId: auditTrail.taskId,
        entryCount: auditTrail.entries.length
      },
      timestamp: Date.now()
    });
  }

  /**
   * Gets an explanation by action ID
   */
  public getExplanation(actionId: string): Explanation | undefined {
    return this.explanations.get(actionId);
  }

  /**
   * Gets an audit trail by task ID
   */
  public getAuditTrail(taskId: string): AuditTrail | undefined {
    return this.auditTrails.get(taskId);
  }

  /**
   * Gets all explanations
   */
  public getExplanations(): Explanation[] {
    return Array.from(this.explanations.values());
  }

  /**
   * Gets all audit trails
   */
  public getAuditTrails(): AuditTrail[] {
    return Array.from(this.auditTrails.values());
  }

  /**
   * Generates a human-readable explanation for a specific action
   */
  public generateHumanReadableExplanation(actionId: string): string {
    const explanation = this.explanations.get(actionId);
    if (!explanation) {
      return 'No explanation available for this action.';
    }
    
    let text = `## Explanation for ${explanation.actionType}\n\n`;
    text += `${explanation.explanation}\n\n`;
    
    text += '### Reasoning\n\n';
    for (const reason of explanation.reasoning) {
      text += `- ${reason}\n`;
    }
    
    text += '\n### Alternatives Considered\n\n';
    for (const alt of explanation.alternatives) {
      text += `- **${alt.action}** (confidence: ${Math.round(alt.score * 100)}%): ${alt.reason}\n`;
    }
    
    return text;
  }

  /**
   * Generates a human-readable audit trail for a task
   */
  public generateHumanReadableAuditTrail(taskId: string): string {
    const auditTrail = this.auditTrails.get(taskId);
    if (!auditTrail) {
      return 'No audit trail available for this task.';
    }
    
    let text = `# Audit Trail for Task ${taskId}\n\n`;
    
    // Sort entries by timestamp
    const sortedEntries = [...auditTrail.entries].sort((a, b) => a.timestamp - b.timestamp);
    
    for (const entry of sortedEntries) {
      const date = new Date(entry.timestamp).toISOString();
      text += `## ${date} - ${entry.action}\n\n`;
      text += `Actor: ${entry.actor}\n\n`;
      
      if (entry.explanation) {
        text += `Explanation: ${entry.explanation}\n\n`;
      }
      
      text += `Details: ${JSON.stringify(entry.details, null, 2)}\n\n`;
      text += '---\n\n';
    }
    
    return text;
  }
}

export default ExplainabilityAgent;
