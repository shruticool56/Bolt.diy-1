/**
 * SentienceAI Cognitive Kernel - User Preference Learner
 * 
 * This module implements the User Preference Learner:
 * - Continuously refines system tone, interface choices, and behavioral patterns
 * - Learns from explicit and implicit feedback
 * - Maintains user preference profiles
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../../core/memory';
import { FeedbackInterpreterAgent, FeedbackType, FeedbackSignal } from '../feedback-interpreter';

export interface PreferenceCategory {
  id: string;
  name: string;
  description: string;
  possibleValues: string[];
  defaultValue: string;
}

export interface UserPreference {
  id: string;
  userId: string;
  categoryId: string;
  value: string;
  confidence: number; // 0-1 confidence score
  lastUpdated: number;
  history: {
    value: string;
    confidence: number;
    timestamp: number;
    source: string;
  }[];
}

export interface PreferenceProfile {
  id: string;
  userId: string;
  preferences: UserPreference[];
  lastUpdated: number;
}

export class UserPreferenceLearner extends EventEmitter {
  private memoryManager: MemoryManager;
  private feedbackInterpreter: FeedbackInterpreterAgent;
  private preferenceCategories: PreferenceCategory[] = [];
  private userProfiles: Map<string, PreferenceProfile> = new Map();
  
  constructor(
    memoryManager?: MemoryManager,
    feedbackInterpreter?: FeedbackInterpreterAgent
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.feedbackInterpreter = feedbackInterpreter || new FeedbackInterpreterAgent();
    
    // Initialize default preference categories
    this.initializeDefaultCategories();
    
    // Listen for feedback signals
    this.feedbackInterpreter.on('feedbackInterpreted', this.handleFeedback.bind(this));
  }

  /**
   * Initializes default preference categories
   */
  private initializeDefaultCategories(): void {
    this.preferenceCategories = [
      {
        id: 'communication_style',
        name: 'Communication Style',
        description: 'Preferred style of communication',
        possibleValues: [
          'formal', 'casual', 'technical', 'simple',
          'detailed', 'concise', 'friendly', 'professional'
        ],
        defaultValue: 'professional'
      },
      {
        id: 'response_length',
        name: 'Response Length',
        description: 'Preferred length of responses',
        possibleValues: [
          'very_short', 'short', 'medium', 'long', 'very_long'
        ],
        defaultValue: 'medium'
      },
      {
        id: 'code_style',
        name: 'Code Style',
        description: 'Preferred style for code',
        possibleValues: [
          'minimal', 'commented', 'heavily_commented',
          'functional', 'object_oriented', 'procedural'
        ],
        defaultValue: 'commented'
      },
      {
        id: 'explanation_depth',
        name: 'Explanation Depth',
        description: 'Preferred depth of explanations',
        possibleValues: [
          'minimal', 'basic', 'detailed', 'comprehensive', 'expert'
        ],
        defaultValue: 'detailed'
      },
      {
        id: 'interface_density',
        name: 'Interface Density',
        description: 'Preferred density of UI elements',
        possibleValues: [
          'minimal', 'low', 'medium', 'high', 'dense'
        ],
        defaultValue: 'medium'
      },
      {
        id: 'color_scheme',
        name: 'Color Scheme',
        description: 'Preferred color scheme',
        possibleValues: [
          'light', 'dark', 'high_contrast', 'muted', 'vibrant'
        ],
        defaultValue: 'light'
      },
      {
        id: 'proactivity',
        name: 'Proactivity Level',
        description: 'Preferred level of proactive suggestions',
        possibleValues: [
          'none', 'low', 'medium', 'high', 'very_high'
        ],
        defaultValue: 'medium'
      },
      {
        id: 'error_handling',
        name: 'Error Handling',
        description: 'Preferred approach to error handling',
        possibleValues: [
          'minimal', 'informative', 'detailed', 'guided_resolution'
        ],
        defaultValue: 'informative'
      }
    ];
  }

  /**
   * Handles feedback signals to update preferences
   */
  private async handleFeedback(feedback: FeedbackSignal): Promise<void> {
    // Extract user ID from feedback metadata or use a default
    const userId = feedback.metadata.userId || 'default_user';
    
    // Get or create user profile
    let profile = await this.getUserProfile(userId);
    if (!profile) {
      profile = await this.createUserProfile(userId);
    }
    
    // Analyze feedback for preference indicators
    const preferenceUpdates = await this.extractPreferencesFromFeedback(feedback);
    
    // Apply updates to profile
    if (preferenceUpdates.length > 0) {
      await this.updateUserPreferences(userId, preferenceUpdates);
      
      this.emit('preferencesUpdated', {
        userId,
        updates: preferenceUpdates
      });
    }
  }

  /**
   * Extracts preference indicators from feedback
   */
  private async extractPreferencesFromFeedback(
    feedback: FeedbackSignal
  ): Promise<{ categoryId: string; value: string; confidence: number; source: string }[]> {
    const updates: { categoryId: string; value: string; confidence: number; source: string }[] = [];
    
    // This is a simplified implementation
    // In a real system, this would use more sophisticated NLP and pattern matching
    
    const content = feedback.content.toLowerCase();
    
    // Check for communication style preferences
    if (content.includes('formal') || content.includes('professional')) {
      updates.push({
        categoryId: 'communication_style',
        value: content.includes('formal') ? 'formal' : 'professional',
        confidence: 0.7,
        source: `feedback:${feedback.id}`
      });
    } else if (content.includes('casual') || content.includes('friendly')) {
      updates.push({
        categoryId: 'communication_style',
        value: content.includes('casual') ? 'casual' : 'friendly',
        confidence: 0.7,
        source: `feedback:${feedback.id}`
      });
    }
    
    // Check for response length preferences
    if (content.includes('shorter') || content.includes('too long')) {
      updates.push({
        categoryId: 'response_length',
        value: 'short',
        confidence: 0.6,
        source: `feedback:${feedback.id}`
      });
    } else if (content.includes('longer') || content.includes('more detail')) {
      updates.push({
        categoryId: 'response_length',
        value: 'long',
        confidence: 0.6,
        source: `feedback:${feedback.id}`
      });
    }
    
    // Check for explanation depth preferences
    if (content.includes('explain more') || content.includes('more explanation')) {
      updates.push({
        categoryId: 'explanation_depth',
        value: 'detailed',
        confidence: 0.7,
        source: `feedback:${feedback.id}`
      });
    } else if (content.includes('explain less') || content.includes('too detailed')) {
      updates.push({
        categoryId: 'explanation_depth',
        value: 'basic',
        confidence: 0.7,
        source: `feedback:${feedback.id}`
      });
    }
    
    // Infer preferences from feedback type
    if (feedback.type === FeedbackType.EXPLICIT_POSITIVE) {
      // If user is happy with current behavior, no need to change preferences
    } else if (feedback.type === FeedbackType.EXPLICIT_NEGATIVE) {
      // Negative feedback might indicate need for more detailed explanations
      if (!updates.some(u => u.categoryId === 'explanation_depth')) {
        updates.push({
          categoryId: 'explanation_depth',
          value: 'detailed',
          confidence: 0.5,
          source: `feedback_type:${feedback.type}`
        });
      }
    }
    
    return updates;
  }

  /**
   * Creates a new user profile
   */
  public async createUserProfile(userId: string): Promise<PreferenceProfile> {
    // Create default preferences for each category
    const preferences: UserPreference[] = this.preferenceCategories.map(category => ({
      id: uuidv4(),
      userId,
      categoryId: category.id,
      value: category.defaultValue,
      confidence: 0.5, // Medium confidence for defaults
      lastUpdated: Date.now(),
      history: [
        {
          value: category.defaultValue,
          confidence: 0.5,
          timestamp: Date.now(),
          source: 'default'
        }
      ]
    }));
    
    const profile: PreferenceProfile = {
      id: uuidv4(),
      userId,
      preferences,
      lastUpdated: Date.now()
    };
    
    // Store in memory
    this.userProfiles.set(userId, profile);
    
    // Persist to storage
    await this.persistUserProfile(profile);
    
    this.emit('profileCreated', profile);
    return profile;
  }

  /**
   * Gets a user profile
   */
  public async getUserProfile(userId: string): Promise<PreferenceProfile | null> {
    // Check in-memory cache first
    if (this.userProfiles.has(userId)) {
      return this.userProfiles.get(userId) || null;
    }
    
    // Try to load from storage
    try {
      const memories = await this.memoryManager.queryMemory({
        key: `preference_profile:${userId}`,
        limit: 1
      });
      
      if (memories.length > 0) {
        const profile = memories[0].value as PreferenceProfile;
        this.userProfiles.set(userId, profile);
        return profile;
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
    
    return null;
  }

  /**
   * Updates user preferences
   */
  public async updateUserPreferences(
    userId: string,
    updates: { categoryId: string; value: string; confidence: number; source: string }[]
  ): Promise<PreferenceProfile> {
    // Get current profile
    let profile = await this.getUserProfile(userId);
    if (!profile) {
      profile = await this.createUserProfile(userId);
    }
    
    // Apply updates
    for (const update of updates) {
      const { categoryId, value, confidence, source } = update;
      
      // Find the preference to update
      const preferenceIndex = profile.preferences.findIndex(p => p.categoryId === categoryId);
      
      if (preferenceIndex >= 0) {
        const preference = profile.preferences[preferenceIndex];
        
        // Only update if new confidence is higher or equal
        if (confidence >= preference.confidence) {
          // Add to history
          preference.history.push({
            value,
            confidence,
            timestamp: Date.now(),
            source
          });
          
          // Update current value
          preference.value = value;
          preference.confidence = confidence;
          preference.lastUpdated = Date.now();
          
          // Update in profile
          profile.preferences[preferenceIndex] = preference;
        }
      } else {
        // Category not found, create new preference
        const category = this.preferenceCategories.find(c => c.id === categoryId);
        if (category) {
          const newPreference: UserPreference = {
            id: uuidv4(),
            userId,
            categoryId,
            value,
            confidence,
            lastUpdated: Date.now(),
            history: [
              {
                value,
                confidence,
                timestamp: Date.now(),
                source
              }
            ]
          };
          
          profile.preferences.push(newPreference);
        }
      }
    }
    
    // Update last updated timestamp
    profile.lastUpdated = Date.now();
    
    // Update in-memory cache
    this.userProfiles.set(userId, profile);
    
    // Persist to storage
    await this.persistUserProfile(profile);
    
    this.emit('profileUpdated', profile);
    return profile;
  }

  /**
   * Persists a user profile to storage
   */
  private async persistUserProfile(profile: PreferenceProfile): Promise<void> {
    await this.memoryManager.storeMemory({
      id: `preference_profile:${profile.userId}`,
      type: MemoryType.LONG_TERM,
      key: `preference_profile:${profile.userId}`,
      value: profile,
      metadata: {
        userId: profile.userId,
        lastUpdated: profile.lastUpdated
      },
      timestamp: Date.now()
    });
  }

  /**
   * Gets a specific user preference
   */
  public async getUserPreference(
    userId: string,
    categoryId: string
  ): Promise<UserPreference | null> {
    const profile = await this.getUserProfile(userId);
    if (!profile) return null;
    
    const preference = profile.preferences.find(p => p.categoryId === categoryId);
    return preference || null;
  }

  /**
   * Gets all preference categories
   */
  public getPreferenceCategories(): PreferenceCategory[] {
    return [...this.preferenceCategories];
  }

  /**
   * Adds a custom preference category
   */
  public addPreferenceCategory(category: PreferenceCategory): void {
    // Check if category with this ID already exists
    const existingIndex = this.preferenceCategories.findIndex(c => c.id === category.id);
    
    if (existingIndex >= 0) {
      // Replace existing category
      this.preferenceCategories[existingIndex] = category;
    } else {
      // Add new category
      this.preferenceCategories.push(category);
    }
    
    this.emit('categoryAdded', category);
  }

  /**
   * Removes a preference category
   */
  public removePreferenceCategory(categoryId: string): boolean {
    const initialLength = this.preferenceCategories.length;
    this.preferenceCategories = this.preferenceCategories.filter(c => c.id !== categoryId);
    
    const removed = this.preferenceCategories.length < initialLength;
    if (removed) {
      this.emit('categoryRemoved', categoryId);
    }
    
    return removed;
  }
}

export default UserPreferenceLearner;
