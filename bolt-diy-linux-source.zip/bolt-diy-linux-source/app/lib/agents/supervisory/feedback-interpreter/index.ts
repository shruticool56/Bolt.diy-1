/**
 * SentienceAI Cognitive Kernel - Feedback Interpreter Agent
 * 
 * This module implements the Feedback Interpreter Agent:
 * - Translates user inputs into structured prompts
 * - Detects patterns in implicit feedback
 * - Provides structured learning signals
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../../core/memory';
import { ExecutionJournal, JournalEntryType } from '../../core/execution-journal';

export enum FeedbackType {
  EXPLICIT_POSITIVE = 'explicit_positive',
  EXPLICIT_NEGATIVE = 'explicit_negative',
  EXPLICIT_NEUTRAL = 'explicit_neutral',
  IMPLICIT_POSITIVE = 'implicit_positive',
  IMPLICIT_NEGATIVE = 'implicit_negative',
  IMPLICIT_NEUTRAL = 'implicit_neutral',
  SUGGESTION = 'suggestion',
  CORRECTION = 'correction',
  QUESTION = 'question'
}

export interface FeedbackSignal {
  id: string;
  timestamp: number;
  taskId: string;
  type: FeedbackType;
  content: string;
  structuredContent?: any;
  metadata: any;
  confidence: number; // 0-1 confidence score
}

export interface FeedbackPattern {
  id: string;
  name: string;
  description: string;
  indicators: string[];
  type: FeedbackType;
  confidence: number;
}

export class FeedbackInterpreterAgent extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private feedbackPatterns: FeedbackPattern[] = [];
  
  constructor(memoryManager?: MemoryManager, executionJournal?: ExecutionJournal) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    
    // Initialize default feedback patterns
    this.initializeDefaultPatterns();
  }

  /**
   * Initializes default feedback patterns
   */
  private initializeDefaultPatterns(): void {
    this.feedbackPatterns = [
      {
        id: 'explicit_positive_1',
        name: 'Explicit Positive Feedback',
        description: 'Direct positive feedback from user',
        indicators: [
          'good', 'great', 'excellent', 'perfect', 'amazing', 'awesome',
          'well done', 'nice job', 'thank you', 'thanks', 'helpful',
          'appreciate', 'like it', 'love it', 'thumbs up', '👍', '❤️'
        ],
        type: FeedbackType.EXPLICIT_POSITIVE,
        confidence: 0.9
      },
      {
        id: 'explicit_negative_1',
        name: 'Explicit Negative Feedback',
        description: 'Direct negative feedback from user',
        indicators: [
          'bad', 'poor', 'terrible', 'awful', 'wrong', 'incorrect',
          'not good', 'not helpful', 'useless', 'disappointed',
          'dislike', 'hate it', 'thumbs down', '👎', '❌'
        ],
        type: FeedbackType.EXPLICIT_NEGATIVE,
        confidence: 0.9
      },
      {
        id: 'explicit_neutral_1',
        name: 'Explicit Neutral Feedback',
        description: 'Direct neutral feedback from user',
        indicators: [
          'ok', 'okay', 'fine', 'alright', 'acceptable',
          'neutral', 'so-so', 'meh', 'not bad', 'not great'
        ],
        type: FeedbackType.EXPLICIT_NEUTRAL,
        confidence: 0.7
      },
      {
        id: 'implicit_positive_1',
        name: 'Implicit Positive - Quick Response',
        description: 'User responds quickly after receiving output',
        indicators: ['response_time_ms<3000'],
        type: FeedbackType.IMPLICIT_POSITIVE,
        confidence: 0.6
      },
      {
        id: 'implicit_negative_1',
        name: 'Implicit Negative - Retry',
        description: 'User retries the same command or request',
        indicators: ['retry', 'repeat_command', 'similar_request'],
        type: FeedbackType.IMPLICIT_NEGATIVE,
        confidence: 0.7
      },
      {
        id: 'implicit_negative_2',
        name: 'Implicit Negative - Error',
        description: 'System error occurred during execution',
        indicators: ['error', 'exception', 'crash', 'timeout'],
        type: FeedbackType.IMPLICIT_NEGATIVE,
        confidence: 0.8
      },
      {
        id: 'suggestion_1',
        name: 'User Suggestion',
        description: 'User suggests an improvement or alternative',
        indicators: [
          'suggest', 'suggestion', 'recommend', 'recommendation',
          'try', 'maybe', 'perhaps', 'instead', 'alternatively',
          'could you', 'would it be better'
        ],
        type: FeedbackType.SUGGESTION,
        confidence: 0.7
      },
      {
        id: 'correction_1',
        name: 'User Correction',
        description: 'User corrects the system output',
        indicators: [
          'correction', 'correct', 'fix', 'fixed', 'actually',
          'not quite', 'not exactly', 'should be', 'meant to',
          'I meant', 'I wanted'
        ],
        type: FeedbackType.CORRECTION,
        confidence: 0.8
      },
      {
        id: 'question_1',
        name: 'User Question',
        description: 'User asks a question about the output',
        indicators: [
          'why', 'how', 'what', 'when', 'where', 'who',
          'which', 'whose', 'whom', 'can you explain',
          'could you clarify', 'I don\'t understand'
        ],
        type: FeedbackType.QUESTION,
        confidence: 0.8
      }
    ];
  }

  /**
   * Interprets user input as feedback
   */
  public async interpretFeedback(
    taskId: string,
    userInput: string,
    context: any = {}
  ): Promise<FeedbackSignal> {
    // Create a base feedback signal
    const feedbackSignal: FeedbackSignal = {
      id: uuidv4(),
      timestamp: Date.now(),
      taskId,
      type: FeedbackType.EXPLICIT_NEUTRAL, // Default type
      content: userInput,
      metadata: {
        ...context,
        originalInput: userInput
      },
      confidence: 0.5 // Default confidence
    };
    
    // Analyze the input for explicit feedback patterns
    const explicitFeedback = this.detectExplicitFeedback(userInput);
    if (explicitFeedback) {
      feedbackSignal.type = explicitFeedback.type;
      feedbackSignal.confidence = explicitFeedback.confidence;
      feedbackSignal.metadata.patternId = explicitFeedback.id;
      feedbackSignal.metadata.patternName = explicitFeedback.name;
    }
    
    // Analyze for implicit feedback if no strong explicit feedback was found
    if (feedbackSignal.confidence < 0.7) {
      const implicitFeedback = await this.detectImplicitFeedback(taskId, context);
      if (implicitFeedback && implicitFeedback.confidence > feedbackSignal.confidence) {
        feedbackSignal.type = implicitFeedback.type;
        feedbackSignal.confidence = implicitFeedback.confidence;
        feedbackSignal.metadata.patternId = implicitFeedback.id;
        feedbackSignal.metadata.patternName = implicitFeedback.name;
        feedbackSignal.metadata.implicitDetection = true;
      }
    }
    
    // Structure the content based on the feedback type
    feedbackSignal.structuredContent = await this.structureFeedbackContent(
      userInput,
      feedbackSignal.type
    );
    
    // Store the feedback signal in memory
    await this.storeFeedbackSignal(feedbackSignal);
    
    // Log the feedback interpretation
    await this.executionJournal.logInfo(
      taskId,
      `Feedback interpreted: ${feedbackSignal.type}`,
      { feedbackSignal }
    );
    
    this.emit('feedbackInterpreted', feedbackSignal);
    return feedbackSignal;
  }

  /**
   * Detects explicit feedback patterns in user input
   */
  private detectExplicitFeedback(
    userInput: string
  ): FeedbackPattern | null {
    const normalizedInput = userInput.toLowerCase();
    
    // Find matching patterns
    const matchingPatterns = this.feedbackPatterns
      .filter(pattern => 
        pattern.type.startsWith('explicit_') &&
        pattern.indicators.some(indicator => 
          normalizedInput.includes(indicator.toLowerCase())
        )
      )
      .sort((a, b) => b.confidence - a.confidence);
    
    return matchingPatterns.length > 0 ? matchingPatterns[0] : null;
  }

  /**
   * Detects implicit feedback based on context and system state
   */
  private async detectImplicitFeedback(
    taskId: string,
    context: any
  ): Promise<FeedbackPattern | null> {
    // Get relevant journal entries
    const entries = this.executionJournal.getTaskEntries(taskId);
    
    // Check for errors
    const hasErrors = entries.some(entry => entry.type === JournalEntryType.ERROR);
    if (hasErrors) {
      return this.feedbackPatterns.find(p => p.id === 'implicit_negative_2') || null;
    }
    
    // Check for repeated similar requests
    const recentRequests = await this.getRecentUserRequests(taskId);
    const isSimilarRequest = this.detectSimilarRequests(recentRequests);
    if (isSimilarRequest) {
      return this.feedbackPatterns.find(p => p.id === 'implicit_negative_1') || null;
    }
    
    // Check response time if available
    if (context.responseTimeMs && context.responseTimeMs < 3000) {
      return this.feedbackPatterns.find(p => p.id === 'implicit_positive_1') || null;
    }
    
    return null;
  }

  /**
   * Gets recent user requests for a task
   */
  private async getRecentUserRequests(taskId: string): Promise<string[]> {
    // In a real implementation, this would retrieve actual user requests
    // For now, return an empty array
    return [];
  }

  /**
   * Detects if there are similar requests in the recent history
   */
  private detectSimilarRequests(requests: string[]): boolean {
    // In a real implementation, this would use semantic similarity
    // For now, return false
    return false;
  }

  /**
   * Structures feedback content based on type
   */
  private async structureFeedbackContent(
    content: string,
    type: FeedbackType
  ): Promise<any> {
    // In a real implementation, this would use an LLM to structure the content
    // For now, return a simple structure
    
    switch (type) {
      case FeedbackType.EXPLICIT_POSITIVE:
      case FeedbackType.IMPLICIT_POSITIVE:
        return {
          sentiment: 'positive',
          aspects: [],
          actionable: false
        };
        
      case FeedbackType.EXPLICIT_NEGATIVE:
      case FeedbackType.IMPLICIT_NEGATIVE:
        return {
          sentiment: 'negative',
          aspects: [],
          actionable: true
        };
        
      case FeedbackType.SUGGESTION:
        return {
          sentiment: 'neutral',
          suggestion: content,
          actionable: true
        };
        
      case FeedbackType.CORRECTION:
        return {
          sentiment: 'neutral',
          correction: content,
          actionable: true
        };
        
      case FeedbackType.QUESTION:
        return {
          sentiment: 'neutral',
          question: content,
          actionable: true
        };
        
      default:
        return {
          sentiment: 'neutral',
          content,
          actionable: false
        };
    }
  }

  /**
   * Stores a feedback signal in memory
   */
  private async storeFeedbackSignal(signal: FeedbackSignal): Promise<void> {
    await this.memoryManager.storeMemory({
      id: signal.id,
      type: MemoryType.LONG_TERM,
      key: `feedback:${signal.taskId}:${signal.id}`,
      value: signal,
      metadata: {
        feedbackType: signal.type,
        confidence: signal.confidence,
        taskId: signal.taskId
      },
      timestamp: signal.timestamp
    });
  }

  /**
   * Gets all feedback signals for a task
   */
  public async getTaskFeedback(taskId: string): Promise<FeedbackSignal[]> {
    const memories = await this.memoryManager.queryMemory({
      keyPattern: `feedback:${taskId}:%`,
      sortBy: 'timestamp',
      sortDirection: 'asc'
    });
    
    return memories.map(memory => memory.value as FeedbackSignal);
  }

  /**
   * Adds a custom feedback pattern
   */
  public addFeedbackPattern(pattern: FeedbackPattern): void {
    // Check if pattern with this ID already exists
    const existingIndex = this.feedbackPatterns.findIndex(p => p.id === pattern.id);
    
    if (existingIndex >= 0) {
      // Replace existing pattern
      this.feedbackPatterns[existingIndex] = pattern;
    } else {
      // Add new pattern
      this.feedbackPatterns.push(pattern);
    }
    
    this.emit('patternAdded', pattern);
  }

  /**
   * Removes a feedback pattern
   */
  public removeFeedbackPattern(patternId: string): boolean {
    const initialLength = this.feedbackPatterns.length;
    this.feedbackPatterns = this.feedbackPatterns.filter(p => p.id !== patternId);
    
    const removed = this.feedbackPatterns.length < initialLength;
    if (removed) {
      this.emit('patternRemoved', patternId);
    }
    
    return removed;
  }

  /**
   * Gets all feedback patterns
   */
  public getFeedbackPatterns(): FeedbackPattern[] {
    return [...this.feedbackPatterns];
  }
}

export default FeedbackInterpreterAgent;
