/**
 * SentienceAI Cognitive Kernel - Safety & Ethics Guardrails
 * 
 * This module implements the Safety & Ethics Guardrails:
 * - Prevents harmful code modifications
 * - Ensures ethical decision boundaries
 * - Maintains alignment with user intent
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../../core/memory';
import { ExecutionJournal } from '../../core/execution-journal';
import { SharedMemoryBus, Message, MessageType } from '../../core/shared-memory-bus';

export enum RiskLevel {
  NONE = 'none',
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export enum GuardrailType {
  CODE_SAFETY = 'code_safety',
  DATA_PRIVACY = 'data_privacy',
  ETHICAL_BOUNDARY = 'ethical_boundary',
  USER_ALIGNMENT = 'user_alignment',
  SYSTEM_INTEGRITY = 'system_integrity'
}

export interface Guardrail {
  id: string;
  name: string;
  description: string;
  type: GuardrailType;
  rules: {
    id: string;
    description: string;
    pattern: string; // Regex pattern or rule expression
    riskLevel: RiskLevel;
    action: 'block' | 'warn' | 'log';
    message: string;
    enabled: boolean;
  }[];
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
  metadata: any;
}

export interface GuardrailCheck {
  id: string;
  guardrailId: string;
  ruleId: string;
  content: string;
  contentType: 'code' | 'prompt' | 'data' | 'action';
  result: 'pass' | 'warn' | 'block';
  riskLevel: RiskLevel;
  message: string;
  timestamp: number;
  metadata: any;
}

export interface SafetyReport {
  id: string;
  taskId: string;
  checks: GuardrailCheck[];
  summary: {
    totalChecks: number;
    passed: number;
    warned: number;
    blocked: number;
    highestRiskLevel: RiskLevel;
  };
  timestamp: number;
  metadata: any;
}

export class SafetyGuardrails extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private sharedMemoryBus: SharedMemoryBus;
  private guardrails: Map<string, Guardrail> = new Map();
  private checks: Map<string, GuardrailCheck[]> = new Map();
  private reports: Map<string, SafetyReport> = new Map();
  private subscriptions: string[] = [];
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    sharedMemoryBus?: SharedMemoryBus
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.sharedMemoryBus = sharedMemoryBus || SharedMemoryBus.getInstance();
    
    // Initialize default guardrails
    this.initializeDefaultGuardrails();
    
    // Initialize subscriptions
    this.initializeSubscriptions();
  }

  /**
   * Initializes default guardrails
   */
  private initializeDefaultGuardrails(): void {
    // Code Safety Guardrail
    this.createGuardrail(
      'Code Safety',
      'Prevents potentially harmful code modifications',
      GuardrailType.CODE_SAFETY,
      [
        {
          id: uuidv4(),
          description: 'Prevent system command execution',
          pattern: '(eval|exec|spawn|fork|execFile|spawnSync|execSync)',
          riskLevel: RiskLevel.HIGH,
          action: 'block',
          message: 'System command execution is not allowed',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent file system operations',
          pattern: '(fs\\.unlink|fs\\.rmdir|fs\\.rm|fs\\.delete)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'File system deletion operations should be used with caution',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent network access',
          pattern: '(http\\.request|https\\.request|net\\.connect|net\\.createConnection)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'Network operations should be used with caution',
          enabled: true
        }
      ]
    );
    
    // Data Privacy Guardrail
    this.createGuardrail(
      'Data Privacy',
      'Ensures sensitive data is handled properly',
      GuardrailType.DATA_PRIVACY,
      [
        {
          id: uuidv4(),
          description: 'Prevent PII exposure',
          pattern: '(password|secret|token|key|credential|api_key|apikey)',
          riskLevel: RiskLevel.HIGH,
          action: 'block',
          message: 'Potential exposure of sensitive information',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent data exfiltration',
          pattern: '(upload|send|post|put|fetch|axios\\.post|axios\\.put)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'Data transfer operations should be used with caution',
          enabled: true
        }
      ]
    );
    
    // Ethical Boundary Guardrail
    this.createGuardrail(
      'Ethical Boundaries',
      'Ensures ethical decision boundaries',
      GuardrailType.ETHICAL_BOUNDARY,
      [
        {
          id: uuidv4(),
          description: 'Prevent harmful content generation',
          pattern: '(harm|attack|exploit|vulnerability|hack|crack|steal)',
          riskLevel: RiskLevel.HIGH,
          action: 'block',
          message: 'Content may violate ethical guidelines',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent deceptive behavior',
          pattern: '(deceive|trick|manipulate|mislead|fake|impersonate)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'Content may be deceptive or manipulative',
          enabled: true
        }
      ]
    );
    
    // User Alignment Guardrail
    this.createGuardrail(
      'User Alignment',
      'Maintains alignment with user intent',
      GuardrailType.USER_ALIGNMENT,
      [
        {
          id: uuidv4(),
          description: 'Ensure user consent',
          pattern: '(without permission|without consent|without approval)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'Action may not align with user intent',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent autonomous decisions',
          pattern: '(decide|choose|select|determine|autonomous)',
          riskLevel: RiskLevel.LOW,
          action: 'log',
          message: 'Action involves autonomous decision making',
          enabled: true
        }
      ]
    );
    
    // System Integrity Guardrail
    this.createGuardrail(
      'System Integrity',
      'Protects system integrity',
      GuardrailType.SYSTEM_INTEGRITY,
      [
        {
          id: uuidv4(),
          description: 'Prevent system modification',
          pattern: '(modify system|change system|alter system|system configuration)',
          riskLevel: RiskLevel.HIGH,
          action: 'block',
          message: 'System modification is not allowed',
          enabled: true
        },
        {
          id: uuidv4(),
          description: 'Prevent resource exhaustion',
          pattern: '(while\\s*\\(true\\)|for\\s*\\(;;\\)|infinite loop)',
          riskLevel: RiskLevel.MEDIUM,
          action: 'warn',
          message: 'Potential resource exhaustion',
          enabled: true
        }
      ]
    );
  }

  /**
   * Initializes message bus subscriptions
   */
  private initializeSubscriptions(): void {
    // Subscribe to code change requests
    const codeChangeSub = this.sharedMemoryBus.subscribe(
      'safety-guardrails',
      'code:change-request',
      this.handleCodeChangeRequest.bind(this)
    );
    this.subscriptions.push(codeChangeSub.id);
    
    // Subscribe to prompt execution requests
    const promptSub = this.sharedMemoryBus.subscribe(
      'safety-guardrails',
      'prompt:execute',
      this.handlePromptExecution.bind(this)
    );
    this.subscriptions.push(promptSub.id);
    
    // Subscribe to data access requests
    const dataSub = this.sharedMemoryBus.subscribe(
      'safety-guardrails',
      'data:access',
      this.handleDataAccess.bind(this)
    );
    this.subscriptions.push(dataSub.id);
    
    // Subscribe to action execution requests
    const actionSub = this.sharedMemoryBus.subscribe(
      'safety-guardrails',
      'action:execute',
      this.handleActionExecution.bind(this)
    );
    this.subscriptions.push(actionSub.id);
  }

  /**
   * Handles code change requests
   */
  private handleCodeChangeRequest(message: Message): void {
    const { sender, payload, correlationId } = message;
    
    // Check code against guardrails
    const checkResult = this.checkContent(
      payload.code,
      'code',
      payload.taskId,
      { sender, changeRequest: payload }
    );
    
    // Respond based on check result
    if (checkResult.result === 'block') {
      this.sharedMemoryBus.respond(message, 'safety-guardrails', null, {
        error: checkResult.message,
        checkId: checkResult.id,
        riskLevel: checkResult.riskLevel
      });
    } else {
      // If warned, include warning in response
      const warning = checkResult.result === 'warn' ? checkResult.message : undefined;
      
      this.sharedMemoryBus.respond(message, 'safety-guardrails', {
        approved: true,
        warning,
        checkId: checkResult.id
      });
    }
  }

  /**
   * Handles prompt execution requests
   */
  private handlePromptExecution(message: Message): void {
    const { sender, payload, correlationId } = message;
    
    // Check prompt against guardrails
    const checkResult = this.checkContent(
      payload.prompt,
      'prompt',
      payload.taskId,
      { sender, promptRequest: payload }
    );
    
    // Respond based on check result
    if (checkResult.result === 'block') {
      this.sharedMemoryBus.respond(message, 'safety-guardrails', null, {
        error: checkResult.message,
        checkId: checkResult.id,
        riskLevel: checkResult.riskLevel
      });
    } else {
      // If warned, include warning in response
      const warning = checkResult.result === 'warn' ? checkResult.message : undefined;
      
      this.sharedMemoryBus.respond(message, 'safety-guardrails', {
        approved: true,
        warning,
        checkId: checkResult.id
      });
    }
  }

  /**
   * Handles data access requests
   */
  private handleDataAccess(message: Message): void {
    const { sender, payload, correlationId } = message;
    
    // Check data access against guardrails
    const checkResult = this.checkContent(
      JSON.stringify(payload),
      'data',
      payload.taskId,
      { sender, dataRequest: payload }
    );
    
    // Respond based on check result
    if (checkResult.result === 'block') {
      this.sharedMemoryBus.respond(message, 'safety-guardrails', null, {
        error: checkResult.message,
        checkId: checkResult.id,
        riskLevel: checkResult.riskLevel
      });
    } else {
      // If warned, include warning in response
      const warning = checkResult.result === 'warn' ? checkResult.message : undefined;
      
      this.sharedMemoryBus.respond(message, 'safety-guardrails', {
        approved: true,
        warning,
        checkId: checkResult.id
      });
    }
  }

  /**
   * Handles action execution requests
   */
  private handleActionExecution(message: Message): void {
    const { sender, payload, correlationId } = message;
    
    // Check action against guardrails
    const checkResult = this.checkContent(
      JSON.stringify(payload),
      'action',
      payload.taskId,
      { sender, actionRequest: payload }
    );
    
    // Respond based on check result
    if (checkResult.result === 'block') {
      this.sharedMemoryBus.respond(message, 'safety-guardrails', null, {
        error: checkResult.message,
        checkId: checkResult.id,
        riskLevel: checkResult.riskLevel
      });
    } else {
      // If warned, include warning in response
      const warning = checkResult.result === 'warn' ? checkResult.message : undefined;
      
      this.sharedMemoryBus.respond(message, 'safety-guardrails', {
        approved: true,
        warning,
        checkId: checkResult.id
      });
    }
  }

  /**
   * Creates a guardrail
   */
  public createGuardrail(
    name: string,
    description: string,
    type: GuardrailType,
    rules: any[],
    metadata: any = {}
  ): Guardrail {
    const guardrail: Guardrail = {
      id: uuidv4(),
      name,
      description,
      type,
      rules,
      enabled: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      metadata
    };
    
    this.guardrails.set(guardrail.id, guardrail);
    this.emit('guardrailCreated', guardrail);
    
    return guardrail;
  }

  /**
   * Checks content against guardrails
   */
  public checkContent(
    content: string,
    contentType: 'code' | 'prompt' | 'data' | 'action',
    taskId: string = 'system',
    metadata: any = {}
  ): GuardrailCheck {
    // Get all enabled guardrails
    const enabledGuardrails = Array.from(this.guardrails.values())
      .filter(g => g.enabled);
    
    // Check against each guardrail
    let highestRiskLevel = RiskLevel.NONE;
    let blockingRule: any = null;
    let warningRule: any = null;
    
    for (const guardrail of enabledGuardrails) {
      // Get enabled rules
      const enabledRules = guardrail.rules.filter(r => r.enabled);
      
      for (const rule of enabledRules) {
        // Check if content matches rule pattern
        const regex = new RegExp(rule.pattern, 'i');
        if (regex.test(content)) {
          // Update highest risk level
          if (this.getRiskLevelValue(rule.riskLevel) > this.getRiskLevelValue(highestRiskLevel)) {
            highestRiskLevel = rule.riskLevel;
          }
          
          // Store blocking or warning rule
          if (rule.action === 'block' && (!blockingRule || this.getRiskLevelValue(rule.riskLevel) > this.getRiskLevelValue(blockingRule.riskLevel))) {
            blockingRule = { ...rule, guardrailId: guardrail.id };
          } else if (rule.action === 'warn' && (!warningRule || this.getRiskLevelValue(rule.riskLevel) > this.getRiskLevelValue(warningRule.riskLevel))) {
            warningRule = { ...rule, guardrailId: guardrail.id };
          }
          
          // Log the match
          this.executionJournal.logInfo(
            taskId,
            `Guardrail rule matched: ${rule.description}`,
            { guardrail, rule, content: content.substring(0, 100) }
          );
        }
      }
    }
    
    // Determine result
    let result: 'pass' | 'warn' | 'block' = 'pass';
    let ruleId = '';
    let guardrailId = '';
    let message = '';
    
    if (blockingRule) {
      result = 'block';
      ruleId = blockingRule.id;
      guardrailId = blockingRule.guardrailId;
      message = blockingRule.message;
    } else if (warningRule) {
      result = 'warn';
      ruleId = warningRule.id;
      guardrailId = warningRule.guardrailId;
      message = warningRule.message;
    }
    
    // Create check record
    const check: GuardrailCheck = {
      id: uuidv4(),
      guardrailId,
      ruleId,
      content: content.substring(0, 1000), // Limit content size
      contentType,
      result,
      riskLevel: highestRiskLevel,
      message,
      timestamp: Date.now(),
      metadata
    };
    
    // Store check
    if (!this.checks.has(taskId)) {
      this.checks.set(taskId, []);
    }
    this.checks.get(taskId)!.push(check);
    
    // Update safety report
    this.updateSafetyReport(taskId);
    
    // Emit event
    this.emit('contentChecked', check);
    
    return check;
  }

  /**
   * Gets the numeric value of a risk level
   */
  private getRiskLevelValue(level: RiskLevel): number {
    switch (level) {
      case RiskLevel.NONE:
        return 0;
      case RiskLevel.LOW:
        return 1;
      case RiskLevel.MEDIUM:
        return 2;
      case RiskLevel.HIGH:
        return 3;
      case RiskLevel.CRITICAL:
        return 4;
      default:
        return 0;
    }
  }

  /**
   * Updates the safety report for a task
   */
  private updateSafetyReport(taskId: string): void {
    const taskChecks = this.checks.get(taskId) || [];
    
    // Calculate summary
    const totalChecks = taskChecks.length;
    const passed = taskChecks.filter(c => c.result === 'pass').length;
    const warned = taskChecks.filter(c => c.result === 'warn').length;
    const blocked = taskChecks.filter(c => c.result === 'block').length;
    
    // Determine highest risk level
    let highestRiskLevel = RiskLevel.NONE;
    for (const check of taskChecks) {
      if (this.getRiskLevelValue(check.riskLevel) > this.getRiskLevelValue(highestRiskLevel)) {
        highestRiskLevel = check.riskLevel;
      }
    }
    
    // Create or update report
    const report: SafetyReport = {
      id: this.reports.has(taskId) ? this.reports.get(taskId)!.id : uuidv4(),
      taskId,
      checks: taskChecks,
      summary: {
        totalChecks,
        passed,
        warned,
        blocked,
        highestRiskLevel
      },
      timestamp: Date.now(),
      metadata: {}
    };
    
    this.reports.set(taskId, report);
    this.emit('safetyReportUpdated', report);
  }

  /**
   * Gets all guardrails
   */
  public getGuardrails(): Guardrail[] {
    return Array.from(this.guardrails.values());
  }

  /**
   * Gets a guardrail by ID
   */
  public getGuardrail(guardrailId: string): Guardrail | undefined {
    return this.guardrails.get(guardrailId);
  }

  /**
   * Updates a guardrail
   */
  public updateGuardrail(
    guardrailId: string,
    updates: Partial<Guardrail>
  ): Guardrail | null {
    const guardrail = this.guardrails.get(guardrailId);
    if (!guardrail) {
      return null;
    }
    
    // Apply updates
    const updatedGuardrail = {
      ...guardrail,
      ...updates,
      id: guardrail.id, // Ensure ID doesn't change
      updatedAt: Date.now()
    };
    
    this.guardrails.set(guardrailId, updatedGuardrail);
    this.emit('guardrailUpdated', updatedGuardrail);
    
    return updatedGuardrail;
  }

  /**
   * Enables or disables a guardrail
   */
  public setGuardrailEnabled(guardrailId: string, enabled: boolean): boolean {
    const guardrail = this.guardrails.get(guardrailId);
    if (!guardrail) {
      return false;
    }
    
    guardrail.enabled = enabled;
    guardrail.updatedAt = Date.now();
    
    this.guardrails.set(guardrailId, guardrail);
    this.emit('guardrailEnabledChanged', guardrail);
    
    return true;
  }

  /**
   * Gets checks for a task
   */
  public getTaskChecks(taskId: string): GuardrailCheck[] {
    return this.checks.get(taskId) || [];
  }

  /**
   * Gets the safety report for a task
   */
  public getTaskSafetyReport(taskId: string): SafetyReport | null {
    return this.reports.get(taskId) || null;
  }

  /**
   * Gets all safety reports
   */
  public getSafetyReports(): SafetyReport[] {
    return Array.from(this.reports.values());
  }
}

export default SafetyGuardrails;
