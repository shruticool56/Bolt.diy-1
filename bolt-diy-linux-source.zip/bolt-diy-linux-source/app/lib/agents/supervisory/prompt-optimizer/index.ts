/**
 * SentienceAI Cognitive Kernel - Prompt Optimizer Agent
 * 
 * This module implements the Prompt Optimizer Agent:
 * - Tunes prompts over time using reinforcement signals
 * - Tracks performance improvements
 * - Adapts based on task success rates and human feedback
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { MemoryManager, MemoryType } from '../../core/memory';
import { ExecutionJournal } from '../../core/execution-journal';
import { FeedbackInterpreterAgent, FeedbackType } from '../feedback-interpreter';

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  template: string;
  variables: string[];
  usage: string;
  category: string;
  version: number;
  createdAt: number;
  updatedAt: number;
  metadata: any;
}

export interface PromptVariation {
  id: string;
  templateId: string;
  template: string;
  variables: string[];
  performance: {
    successRate: number;
    averageLatency: number;
    userSatisfaction: number;
    sampleSize: number;
  };
  createdAt: number;
  isActive: boolean;
  metadata: any;
}

export interface PromptExecution {
  id: string;
  variationId: string;
  filledPrompt: string;
  variables: Record<string, any>;
  result: any;
  success: boolean;
  latency: number;
  feedback?: {
    type: FeedbackType;
    content: string;
    score: number;
  };
  timestamp: number;
  metadata: any;
}

export interface OptimizationExperiment {
  id: string;
  templateId: string;
  status: 'running' | 'completed' | 'failed';
  variations: string[]; // Variation IDs
  startTime: number;
  endTime?: number;
  winningVariationId?: string;
  metrics: {
    totalExecutions: number;
    executionsPerVariation: Record<string, number>;
    successRates: Record<string, number>;
    averageLatencies: Record<string, number>;
    userSatisfaction: Record<string, number>;
  };
  metadata: any;
}

export class PromptOptimizerAgent extends EventEmitter {
  private memoryManager: MemoryManager;
  private executionJournal: ExecutionJournal;
  private feedbackInterpreter: FeedbackInterpreterAgent;
  private templates: Map<string, PromptTemplate> = new Map();
  private variations: Map<string, PromptVariation> = new Map();
  private executions: Map<string, PromptExecution> = new Map();
  private experiments: Map<string, OptimizationExperiment> = new Map();
  
  constructor(
    memoryManager?: MemoryManager,
    executionJournal?: ExecutionJournal,
    feedbackInterpreter?: FeedbackInterpreterAgent
  ) {
    super();
    this.memoryManager = memoryManager || new MemoryManager();
    this.executionJournal = executionJournal || new ExecutionJournal();
    this.feedbackInterpreter = feedbackInterpreter || new FeedbackInterpreterAgent();
    
    // Listen for feedback signals
    this.feedbackInterpreter.on('feedbackInterpreted', this.handleFeedback.bind(this));
  }

  /**
   * Creates a prompt template
   */
  public createTemplate(
    name: string,
    description: string,
    template: string,
    usage: string,
    category: string,
    metadata: any = {}
  ): PromptTemplate {
    // Extract variables from template
    const variables = this.extractVariables(template);
    
    const promptTemplate: PromptTemplate = {
      id: uuidv4(),
      name,
      description,
      template,
      variables,
      usage,
      category,
      version: 1,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      metadata
    };
    
    this.templates.set(promptTemplate.id, promptTemplate);
    
    // Create initial variation
    this.createVariation(promptTemplate.id, template, metadata);
    
    this.emit('templateCreated', promptTemplate);
    return promptTemplate;
  }

  /**
   * Extracts variables from a template
   */
  private extractVariables(template: string): string[] {
    const variableRegex = /\{\{([^}]+)\}\}/g;
    const variables: string[] = [];
    let match;
    
    while ((match = variableRegex.exec(template)) !== null) {
      variables.push(match[1].trim());
    }
    
    return [...new Set(variables)]; // Remove duplicates
  }

  /**
   * Creates a variation of a template
   */
  public createVariation(
    templateId: string,
    template: string,
    metadata: any = {}
  ): PromptVariation {
    const promptTemplate = this.templates.get(templateId);
    if (!promptTemplate) {
      throw new Error(`Template with ID ${templateId} not found`);
    }
    
    // Extract variables from template
    const variables = this.extractVariables(template);
    
    const variation: PromptVariation = {
      id: uuidv4(),
      templateId,
      template,
      variables,
      performance: {
        successRate: 0,
        averageLatency: 0,
        userSatisfaction: 0,
        sampleSize: 0
      },
      createdAt: Date.now(),
      isActive: true,
      metadata
    };
    
    this.variations.set(variation.id, variation);
    this.emit('variationCreated', variation);
    
    return variation;
  }

  /**
   * Gets the best variation for a template
   */
  public getBestVariation(templateId: string): PromptVariation | null {
    const templateVariations = Array.from(this.variations.values())
      .filter(v => v.templateId === templateId && v.isActive);
    
    if (templateVariations.length === 0) {
      return null;
    }
    
    // Sort by success rate, then by user satisfaction
    return templateVariations.sort((a, b) => {
      if (a.performance.successRate !== b.performance.successRate) {
        return b.performance.successRate - a.performance.successRate;
      }
      return b.performance.userSatisfaction - a.performance.userSatisfaction;
    })[0];
  }

  /**
   * Fills a prompt template with variables
   */
  public fillPrompt(
    templateId: string,
    variables: Record<string, any>
  ): { filledPrompt: string; variationId: string } {
    // Get the best variation
    const variation = this.getBestVariation(templateId);
    if (!variation) {
      throw new Error(`No active variations found for template ${templateId}`);
    }
    
    // Fill the template
    let filledPrompt = variation.template;
    
    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'g');
      filledPrompt = filledPrompt.replace(regex, String(value));
    }
    
    return {
      filledPrompt,
      variationId: variation.id
    };
  }

  /**
   * Records a prompt execution
   */
  public recordExecution(
    variationId: string,
    filledPrompt: string,
    variables: Record<string, any>,
    result: any,
    success: boolean,
    latency: number,
    metadata: any = {}
  ): PromptExecution {
    const execution: PromptExecution = {
      id: uuidv4(),
      variationId,
      filledPrompt,
      variables,
      result,
      success,
      latency,
      timestamp: Date.now(),
      metadata
    };
    
    this.executions.set(execution.id, execution);
    
    // Update variation performance
    this.updateVariationPerformance(variationId);
    
    // Update experiment metrics if part of an experiment
    const experiment = this.findExperimentForVariation(variationId);
    if (experiment) {
      this.updateExperimentMetrics(experiment.id);
    }
    
    this.emit('executionRecorded', execution);
    return execution;
  }

  /**
   * Updates a variation's performance metrics
   */
  private updateVariationPerformance(variationId: string): void {
    const variation = this.variations.get(variationId);
    if (!variation) {
      return;
    }
    
    // Get all executions for this variation
    const executions = Array.from(this.executions.values())
      .filter(e => e.variationId === variationId);
    
    if (executions.length === 0) {
      return;
    }
    
    // Calculate metrics
    const successCount = executions.filter(e => e.success).length;
    const successRate = successCount / executions.length;
    
    const totalLatency = executions.reduce((sum, e) => sum + e.latency, 0);
    const averageLatency = totalLatency / executions.length;
    
    const feedbackExecutions = executions.filter(e => e.feedback);
    const totalSatisfaction = feedbackExecutions.reduce(
      (sum, e) => sum + (e.feedback?.score || 0),
      0
    );
    const userSatisfaction = feedbackExecutions.length > 0
      ? totalSatisfaction / feedbackExecutions.length
      : variation.performance.userSatisfaction;
    
    // Update variation
    variation.performance = {
      successRate,
      averageLatency,
      userSatisfaction,
      sampleSize: executions.length
    };
    
    this.variations.set(variationId, variation);
    this.emit('variationPerformanceUpdated', variation);
  }

  /**
   * Finds an experiment that includes a variation
   */
  private findExperimentForVariation(variationId: string): OptimizationExperiment | null {
    for (const experiment of this.experiments.values()) {
      if (experiment.status === 'running' && experiment.variations.includes(variationId)) {
        return experiment;
      }
    }
    return null;
  }

  /**
   * Handles feedback signals
   */
  private handleFeedback(feedback: any): void {
    // Extract execution ID from metadata if available
    const executionId = feedback.metadata?.executionId;
    if (!executionId) {
      return;
    }
    
    const execution = this.executions.get(executionId);
    if (!execution) {
      return;
    }
    
    // Calculate feedback score
    let score = 0;
    switch (feedback.type) {
      case FeedbackType.EXPLICIT_POSITIVE:
        score = 1.0;
        break;
      case FeedbackType.IMPLICIT_POSITIVE:
        score = 0.8;
        break;
      case FeedbackType.EXPLICIT_NEUTRAL:
        score = 0.5;
        break;
      case FeedbackType.IMPLICIT_NEUTRAL:
        score = 0.5;
        break;
      case FeedbackType.EXPLICIT_NEGATIVE:
        score = 0.0;
        break;
      case FeedbackType.IMPLICIT_NEGATIVE:
        score = 0.2;
        break;
      default:
        score = 0.5;
    }
    
    // Update execution with feedback
    execution.feedback = {
      type: feedback.type,
      content: feedback.content,
      score
    };
    
    this.executions.set(executionId, execution);
    
    // Update variation performance
    this.updateVariationPerformance(execution.variationId);
    
    // Update experiment metrics if part of an experiment
    const experiment = this.findExperimentForVariation(execution.variationId);
    if (experiment) {
      this.updateExperimentMetrics(experiment.id);
    }
    
    this.emit('feedbackRecorded', execution);
  }

  /**
   * Starts an optimization experiment
   */
  public startExperiment(
    templateId: string,
    variationCount: number = 3,
    metadata: any = {}
  ): OptimizationExperiment {
    const template = this.templates.get(templateId);
    if (!template) {
      throw new Error(`Template with ID ${templateId} not found`);
    }
    
    // Get existing variations
    const existingVariations = Array.from(this.variations.values())
      .filter(v => v.templateId === templateId && v.isActive);
    
    // Create additional variations if needed
    const variations = [...existingVariations];
    
    while (variations.length < variationCount) {
      const newVariation = this.generateVariation(template);
      variations.push(newVariation);
    }
    
    // Create experiment
    const experiment: OptimizationExperiment = {
      id: uuidv4(),
      templateId,
      status: 'running',
      variations: variations.map(v => v.id),
      startTime: Date.now(),
      metrics: {
        totalExecutions: 0,
        executionsPerVariation: {},
        successRates: {},
        averageLatencies: {},
        userSatisfaction: {}
      },
      metadata
    };
    
    // Initialize metrics
    for (const variationId of experiment.variations) {
      experiment.metrics.executionsPerVariation[variationId] = 0;
      experiment.metrics.successRates[variationId] = 0;
      experiment.metrics.averageLatencies[variationId] = 0;
      experiment.metrics.userSatisfaction[variationId] = 0;
    }
    
    this.experiments.set(experiment.id, experiment);
    this.emit('experimentStarted', experiment);
    
    return experiment;
  }

  /**
   * Generates a new variation of a template
   */
  private generateVariation(template: PromptTemplate): PromptVariation {
    // In a real implementation, this would use an LLM to generate variations
    // For now, create a simple variation
    
    const originalTemplate = template.template;
    
    // Add some variations to the template
    const variations = [
      `I want you to act as an expert in ${template.category}.\n${originalTemplate}`,
      `As a highly knowledgeable ${template.category} specialist, ${originalTemplate}`,
      `Using your expertise in ${template.category}, please ${originalTemplate}`
    ];
    
    const randomVariation = variations[Math.floor(Math.random() * variations.length)];
    
    return this.createVariation(
      template.id,
      randomVariation,
      { generated: true }
    );
  }

  /**
   * Updates experiment metrics
   */
  private updateExperimentMetrics(experimentId: string): void {
    const experiment = this.experiments.get(experimentId);
    if (!experiment || experiment.status !== 'running') {
      return;
    }
    
    let totalExecutions = 0;
    
    // Update metrics for each variation
    for (const variationId of experiment.variations) {
      const variation = this.variations.get(variationId);
      if (!variation) continue;
      
      // Get executions for this variation
      const executions = Array.from(this.executions.values())
        .filter(e => e.variationId === variationId && e.timestamp >= experiment.startTime);
      
      const executionCount = executions.length;
      totalExecutions += executionCount;
      
      experiment.metrics.executionsPerVariation[variationId] = executionCount;
      experiment.metrics.successRates[variationId] = variation.performance.successRate;
      experiment.metrics.averageLatencies[variationId] = variation.performance.averageLatency;
      experiment.metrics.userSatisfaction[variationId] = variation.performance.userSatisfaction;
    }
    
    experiment.metrics.totalExecutions = totalExecutions;
    
    // Check if experiment should be completed
    if (totalExecutions >= 100) {
      this.completeExperiment(experimentId);
    } else {
      this.experiments.set(experimentId, experiment);
      this.emit('experimentUpdated', experiment);
    }
  }

  /**
   * Completes an experiment
   */
  public completeExperiment(experimentId: string): OptimizationExperiment {
    const experiment = this.experiments.get(experimentId);
    if (!experiment) {
      throw new Error(`Experiment with ID ${experimentId} not found`);
    }
    
    if (experiment.status === 'completed') {
      return experiment;
    }
    
    // Determine the winning variation
    const variationIds = experiment.variations;
    let bestVariationId = variationIds[0];
    let bestScore = 0;
    
    for (const variationId of variationIds) {
      // Calculate a combined score
      const successRate = experiment.metrics.successRates[variationId] || 0;
      const userSatisfaction = experiment.metrics.userSatisfaction[variationId] || 0;
      const latencyScore = experiment.metrics.averageLatencies[variationId]
        ? 1 / (1 + experiment.metrics.averageLatencies[variationId] / 1000)
        : 0;
      
      const score = (successRate * 0.5) + (userSatisfaction * 0.3) + (latencyScore * 0.2);
      
      if (score > bestScore) {
        bestScore = score;
        bestVariationId = variationId;
      }
    }
    
    // Update experiment
    experiment.status = 'completed';
    experiment.endTime = Date.now();
    experiment.winningVariationId = bestVariationId;
    
    this.experiments.set(experimentId, experiment);
    
    // Update template with winning variation
    this.updateTemplateWithWinningVariation(experiment.templateId, bestVariationId);
    
    this.emit('experimentCompleted', experiment);
    return experiment;
  }

  /**
   * Updates a template with the winning variation
   */
  private updateTemplateWithWinningVariation(
    templateId: string,
    winningVariationId: string
  ): void {
    const template = this.templates.get(templateId);
    const winningVariation = this.variations.get(winningVariationId);
    
    if (!template || !winningVariation) {
      return;
    }
    
    // Update template
    template.template = winningVariation.template;
    template.variables = winningVariation.variables;
    template.version += 1;
    template.updatedAt = Date.now();
    
    this.templates.set(templateId, template);
    this.emit('templateUpdated', template);
  }

  /**
   * Gets all templates
   */
  public getTemplates(): PromptTemplate[] {
    return Array.from(this.templates.values());
  }

  /**
   * Gets a template by ID
   */
  public getTemplate(templateId: string): PromptTemplate | undefined {
    return this.templates.get(templateId);
  }

  /**
   * Gets all variations for a template
   */
  public getTemplateVariations(templateId: string): PromptVariation[] {
    return Array.from(this.variations.values())
      .filter(v => v.templateId === templateId);
  }

  /**
   * Gets all experiments
   */
  public getExperiments(): OptimizationExperiment[] {
    return Array.from(this.experiments.values());
  }

  /**
   * Gets an experiment by ID
   */
  public getExperiment(experimentId: string): OptimizationExperiment | undefined {
    return this.experiments.get(experimentId);
  }

  /**
   * Gets experiments for a template
   */
  public getTemplateExperiments(templateId: string): OptimizationExperiment[] {
    return Array.from(this.experiments.values())
      .filter(e => e.templateId === templateId);
  }
}

export default PromptOptimizerAgent;
