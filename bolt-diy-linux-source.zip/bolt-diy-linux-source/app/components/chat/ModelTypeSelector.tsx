import React, { useState, useEffect } from 'react';
import { classNames } from '~/utils/classNames';
import { motion } from 'framer-motion';

type ModelType = 'cloud' | 'local';

interface ModelTypeSelectorProps {
  selectedType: ModelType;
  onTypeChange: (type: ModelType) => void;
  className?: string;
}

export const ModelTypeSelector: React.FC<ModelTypeSelectorProps> = ({
  selectedType,
  onTypeChange,
  className,
}) => {
  return (
    <div className={classNames('flex items-center space-x-2', className)}>
      <div className="flex items-center p-1 bg-bolt-elements-background-depth-2 rounded-lg">
        <button
          type="button"
          onClick={() => onTypeChange('cloud')}
          className={classNames(
            'px-3 py-1 text-xs rounded-md transition-all duration-200',
            selectedType === 'cloud'
              ? 'bg-bolt-elements-background-depth-3 text-bolt-elements-textPrimary shadow-sm'
              : 'text-bolt-elements-textSecondary hover:text-bolt-elements-textPrimary'
          )}
        >
          <div className="flex items-center gap-1.5">
            <div className="i-ph:cloud text-sm" />
            <span>Cloud</span>
          </div>
        </button>
        <button
          type="button"
          onClick={() => onTypeChange('local')}
          className={classNames(
            'px-3 py-1 text-xs rounded-md transition-all duration-200',
            selectedType === 'local'
              ? 'bg-bolt-elements-background-depth-3 text-bolt-elements-textPrimary shadow-sm'
              : 'text-bolt-elements-textSecondary hover:text-bolt-elements-textPrimary'
          )}
        >
          <div className="flex items-center gap-1.5">
            <div className="i-ph:desktop text-sm" />
            <span>Local</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default ModelTypeSelector;
